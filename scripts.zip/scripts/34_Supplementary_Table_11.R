#===============================================================================
# Supplementary Table 11: Solar rebound effect estimation using PSM-DID
#
# Description:
# This script estimates the solar rebound effect using the propensity score
# matched sample in a difference-in-differences framework. It implements
# Equation (1) from Supplementary Note 16:
#
#   ln(EC_it) = α_i^y + δ_y^m + β(Treat_i × Post_it) + X_it'γ + W_it'θ + ε_it
#
# Three specifications are estimated:
#   Column (1): Baseline with household-year and year-by-month FE only
#   Column (2): Adds household-level time-varying controls
#   Column (3): Further adds weather controls
#
#===============================================================================

library(tidyverse)
library(fixest)
library(officer)
library(flextable)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root   <- "D:/rooftop"
path_models <- file.path(path_root, "models")
path_output <- file.path(path_root, "Tables")
path_survey <- file.path(path_root, "survey")

#-------------------------------------------------------------------------------
# 2. LOAD MATCHED PANEL DATA
#-------------------------------------------------------------------------------

matched_panel <- readRDS(file.path(path_survey, "matched_survey_panel_data.RDS"))

#-------------------------------------------------------------------------------
# 3. PREPARE REGRESSION VARIABLES
#-------------------------------------------------------------------------------

regression_data <- matched_panel %>%
  mutate(
    log_consumption = log(monthly_elec_consumption),
    treat_post      = treatment * post_adoption,
    household_year  = paste(household_id, year, sep = "_"),
    income_yuan     = monthly_income,
    temp_avg_sq     = temp_avg^2
  ) %>%
  filter(!is.na(log_consumption) & !is.na(treat_post))

#-------------------------------------------------------------------------------
# 4. COLUMN (1): BASELINE SPECIFICATION - FE ONLY
#-------------------------------------------------------------------------------

col1_psm <- feols(
  log_consumption ~ treat_post | household_year + year^month,
  data    = regression_data,
  cluster = ~household_id,
  weights = ~weights
)

saveRDS(col1_psm, file.path(path_models, "supp_table11_col1.RDS"))

#-------------------------------------------------------------------------------
# 5. COLUMN (2): ADD HOUSEHOLD CONTROLS
#-------------------------------------------------------------------------------

col2_psm <- feols(
  log_consumption ~ treat_post + household_size + income_yuan | 
    household_year + year^month,
  data    = regression_data,
  cluster = ~household_id,
  weights = ~weights
)

saveRDS(col2_psm, file.path(path_models, "supp_table11_col2.RDS"))

#-------------------------------------------------------------------------------
# 6. COLUMN (3): ADD WEATHER CONTROLS (PREFERRED SPECIFICATION)
#-------------------------------------------------------------------------------

col3_psm <- feols(
  log_consumption ~ treat_post + household_size + income_yuan + 
    temp_avg + temp_avg_sq | household_year + year^month,
  data    = regression_data,
  cluster = ~household_id,
  weights = ~weights
)

saveRDS(col3_psm, file.path(path_models, "supp_table11_col3.RDS"))

#-------------------------------------------------------------------------------
# 7. TABLE GENERATION
#-------------------------------------------------------------------------------

models <- list(
  readRDS(file.path(path_models, "supp_table11_col1.RDS")),
  readRDS(file.path(path_models, "supp_table11_col2.RDS")),
  readRDS(file.path(path_models, "supp_table11_col3.RDS"))
)

#-------------------------------------------------------------------------------
# 8. EXTRACT COEFFICIENTS WITH SIGNIFICANCE STARS
#-------------------------------------------------------------------------------

get_coef <- function(model, varname) {
  coef_tbl <- summary(model)$coefficients
  if (!varname %in% rownames(coef_tbl)) return(c("", ""))
  
  est  <- coef_tbl[varname, "Estimate"]
  se   <- coef_tbl[varname, "Std. Error"]
  pval <- coef_tbl[varname, "Pr(>|t|)"]
  
  stars <- case_when(
    pval < 0.01 ~ "***", 
    pval < 0.05 ~ "**", 
    pval < 0.10 ~ "*", 
    TRUE ~ ""
  )
  
  c(sprintf("%.3f%s", est, stars), sprintf("(%.3f)", se))
}

#-------------------------------------------------------------------------------
# 9. BUILD TABLE DATA
#-------------------------------------------------------------------------------

tbl_data <- tibble(Variable = character())

# Main coefficient: Treat_i × Post_it
coef_row <- c("Treat_i × Post_it", "", "", "")
se_row   <- c("", "", "", "")

for (col_idx in 1:3) {
  result <- get_coef(models[[col_idx]], "treat_post")
  coef_row[col_idx + 1] <- result[1]
  se_row[col_idx + 1]   <- result[2]
}

tbl_data <- tbl_data %>%
  bind_rows(tibble(
    Variable = coef_row[1],
    `(1)` = coef_row[2],
    `(2)` = coef_row[3],
    `(3)` = coef_row[4]
  )) %>%
  bind_rows(tibble(
    Variable = se_row[1],
    `(1)` = se_row[2],
    `(2)` = se_row[3],
    `(3)` = se_row[4]
  ))

# Add observations
tbl_data <- tbl_data %>%
  bind_rows(tibble(
    Variable = "Obs.",
    `(1)` = format(nobs(models[[1]]), big.mark = ","),
    `(2)` = format(nobs(models[[2]]), big.mark = ","),
    `(3)` = format(nobs(models[[3]]), big.mark = ",")
  ))

# Add control specifications
controls_specs <- tribble(
  ~Variable,                 ~`(1)`, ~`(2)`, ~`(3)`,
  "Household controls",      "",     "✓",    "✓",
  "Weather controls",        "",     "",     "✓",
  "Household-by-year FE",    "✓",    "✓",    "✓",
  "Year-by-month FE",        "✓",    "✓",    "✓"
)

tbl_data <- tbl_data %>% bind_rows(controls_specs)

#-------------------------------------------------------------------------------
# 10. FORMAT TABLE WITH FLEXTABLE
#-------------------------------------------------------------------------------

ft <- flextable(tbl_data) %>%
  set_header_labels(
    Variable = "Variable",
    `(1)` = "(1)",
    `(2)` = "(2)",
    `(3)` = "(3)"
  ) %>%
  width(j = 1, width = 3.0) %>%
  width(j = 2:4, width = 1.5) %>%
  align(j = 2:4, align = "center", part = "all") %>%
  align(j = 1, align = "left", part = "body") %>%
  bold(part = "header") %>%
  padding(i = which(tbl_data$Variable == ""), j = 1, padding.left = 20) %>%
  hline_top(border = fp_border(width = 2), part = "header") %>%
  hline_bottom(border = fp_border(width = 2), part = "header") %>%
  hline(i = 2, border = fp_border(width = 1)) %>%
  hline_bottom(border = fp_border(width = 2), part = "body") %>%
  fontsize(size = 10, part = "all") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  set_caption(
    caption = as_paragraph(
      as_b("Supplementary Table 11. "),
      "Solar rebound effect estimation using PSM-DID"
    ),
    align_with_table = FALSE
  )


#-------------------------------------------------------------------------------
# 11. EXPORT TO WORD
#-------------------------------------------------------------------------------

doc <- read_docx() %>%
  body_add_flextable(value = ft)

output_path <- file.path(path_output, "Supplementary_Table_11.docx")
print(doc, target = output_path)

#===============================================================================
# END OF SCRIPT
#===============================================================================
