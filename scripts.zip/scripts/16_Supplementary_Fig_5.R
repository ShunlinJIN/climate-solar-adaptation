#===============================================================================
# Supplementary Fig. 5: Electricity generation and grid exchange patterns of 
# average RRPV-BS adopter
#
# Description:
# This script generates a stacked area chart to visualize the monthly average
# electricity dynamics of RRPV-BS households.
#
#===============================================================================

library(dplyr)
library(ggplot2)
library(lubridate)
library(tidyr)
library(ggprism)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root  <- "D:/rooftop"
path_data  <- file.path(path_root, "electricity")
output_dir <- file.path(path_root, "Fig")

rrpv_bs_data <- readRDS(file.path(path_data, "rrpv_bs_electricity_panel.RDS"))

#-------------------------------------------------------------------------------
# 2. DATA PREPARATION FOR PLOTTING
#-------------------------------------------------------------------------------

# Create a month variable (as Date) for aggregation
rrpv_bs_data <- rrpv_bs_data %>%
  mutate(Month = floor_date(as.Date(time), "month"))

# Monthly averages per household, then average across households
monthly_avg_data <- rrpv_bs_data %>%
  group_by(Month, household_id) %>%
  summarise(
    avg_consumption_from_battery = mean(consumption_from_battery_kwh, na.rm = TRUE),
    avg_battery_charge           = mean(battery_charge_kwh,          na.rm = TRUE),
    avg_battery_remaining        = mean(battery_remaining_kwh,       na.rm = TRUE),
    avg_consumption_from_grid    = mean(consumption_from_grid_kwh,   na.rm = TRUE),
    avg_grid_export              = mean(grid_export_kwh,             na.rm = TRUE),
    avg_consumption_from_pv      = mean(consumption_from_pv_kwh,     na.rm = TRUE),
    .groups = "drop"
  ) %>%
  group_by(Month) %>%
  summarise(
    `Battery to Consumption` = mean(avg_consumption_from_battery, na.rm = TRUE),
    `PV to Battery`          = mean(avg_battery_charge,           na.rm = TRUE),
    `Battery Remaining`      = mean(avg_battery_remaining,        na.rm = TRUE),
    `Grid to Consumption`    = mean(avg_consumption_from_grid,    na.rm = TRUE),
    `PV to Grid`             = mean(avg_grid_export,              na.rm = TRUE),
    `Direct Consumption`     = mean(avg_consumption_from_pv,      na.rm = TRUE),
    .groups = "drop"
  )

monthly_avg_long <- monthly_avg_data %>%
  pivot_longer(
    cols      = -Month,
    names_to  = "Type",
    values_to = "Average_Value"
  ) %>%
  mutate(
    Type = factor(
      Type,
      levels = c(
        "Direct Consumption",
        "PV to Grid",
        "Grid to Consumption",
        "Battery Remaining",
        "PV to Battery",
        "Battery to Consumption"
      )
    )
  )

#-------------------------------------------------------------------------------
# 3. CREATE AND SAVE THE PLOT
#-------------------------------------------------------------------------------

color_palette <- c(
  "Battery to Consumption" = "tan3",
  "PV to Battery"          = "sienna",
  "Battery Remaining"      = "mediumaquamarine",
  "Grid to Consumption"    = "green4",
  "PV to Grid"             = "skyblue",
  "Direct Consumption"     = "steelblue"
)

plot_supp_fig5 <- ggplot(monthly_avg_long, aes(x = Month, y = Average_Value, fill = Type)) +
  geom_area(position = "stack", alpha = 0.7) +
  scale_y_continuous(
    name   = "Average Household Electricity Dynamics (kWh)",
    limits = c(0, 40),
    breaks = seq(0, 40, by = 10),
    guide  = "prism_offset"
  ) +
  scale_x_date(
    date_labels = "%Y-%m",
    date_breaks = "4 months",
    name        = "Time",
    limits      = c(as.Date("2018-06-01"), as.Date("2020-12-31"))
  ) +
  scale_fill_manual(values = color_palette) +
  theme_prism() +
  theme(
    axis.text       = element_text(size = 10, face = "plain"),
    axis.title      = element_text(size = 12, face = "plain"),
    axis.ticks      = element_line(linewidth = 0.5),
    axis.line       = element_line(linewidth = 0.5),
    axis.text.x     = element_text(angle = 0, hjust = 0.5),
    legend.position = "top",
    legend.title    = element_blank()
  )

# PDF
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_5.pdf"),
  plot = plot_supp_fig5,
  width = 8, height = 6, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_5.png"),
  plot = plot_supp_fig5,
  width = 8, height = 6, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)


#===============================================================================
# END OF SCRIPT
#===============================================================================
