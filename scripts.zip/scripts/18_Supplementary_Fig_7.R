#===============================================================================
# Supplementary Figures 7a & 7b: Placebo test of power rationing on 
# RRPV-BS and RRPV-only adoption
#
# Description:
# This script conducts a placebo event study by artificially assigning the outage policy
# to a fictitious implementation date in September 2020, one year before the actual event.
# Panel (a) estimates dynamic effects on RRPV-BS adoption,
# Panel (b) estimates the effects on RRPV-only adoption.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(fixest)
library(ggplot2)
library(ggprism)
library(patchwork)
library(lubridate)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root  <- "D:/rooftop"
path_data  <- file.path(path_root, "adoption")
output_dir <- file.path(path_root, "Fig")

# Load county-month adoption panel used for Equations (1)–(8)
data_adoption <- readRDS(file.path(path_data, "rrpv_analysis_panel.RDS"))

# Text size parameters
text_size_axis_text   <- 18
text_size_axis_title  <- 20
text_size_legend_text <- 18
text_size_plot_tag    <- 22

# Common plotting theme
common_plot_theme_base <- function() {
  theme_prism() +
    theme(
      axis.text        = element_text(size = text_size_axis_text,  face = "plain", color = "black"),
      axis.title       = element_text(size = text_size_axis_title, face = "plain", color = "black"),
      axis.ticks       = element_line(linewidth = 0.5, color = "black"),
      axis.line        = element_line(linewidth = 0.5, color = "black"),
      legend.position  = "top",
      legend.text      = element_text(size = text_size_legend_text, color = "black"),
      legend.title     = element_blank(),
      plot.title       = element_text(hjust = 0.5),
      plot.tag.position = "topleft",
      plot.tag         = element_text(face = "bold", size = text_size_plot_tag)
    )
}

# Helper: extract coefficients and confidence intervals
extract_coef_ci <- function(model, vars) {
  coefs <- coef(model)[vars]
  ci    <- confint(model, level = 0.95)[vars, ]
  data.frame(
    variable = vars,
    coef     = coefs,
    lower_ci = ci[, 1],
    upper_ci = ci[, 2],
    row.names = NULL
  )
}

#-------------------------------------------------------------------------------
# 2. PLACEBO EVENT STUDY SETUP
#-------------------------------------------------------------------------------

data_for_placebo <- data_adoption %>%
  filter(time <= as.Date("2021-08-31")) %>%
  mutate(
    placebo_start     = as.Date("2020-09-01"),  # placebo start date
    months_to_placebo = if_else(
      outage_dummy == 1,
      as.numeric(interval(placebo_start, time) %/% months(1)),
      NA_real_
    )
  )

# Create event dummies for placebo test: leads -8:-2 and lags 0:8 (omitting -1)
event_range <- c(-8:-2, 0:8)

for (k in event_range) {
  var_name <- paste0("event_placebo_", k)
  data_for_placebo[[var_name]] <- if_else(
    data_for_placebo$months_to_placebo == k,
    1, 0,
    missing = 0
  )
}

#-------------------------------------------------------------------------------
# 3. PLACEBO REGRESSIONS (PANELS a AND b)
#-------------------------------------------------------------------------------

# RRPV-BS adoption (Panel a)
placebo_eq7a_rrpv_bs <- feols(
  log_install_bs ~
    `event_placebo_-8` + `event_placebo_-7` + `event_placebo_-6` + `event_placebo_-5` +
    `event_placebo_-4` + `event_placebo_-3` + `event_placebo_-2` +
    `event_placebo_0`  + `event_placebo_1`  + `event_placebo_2`  + `event_placebo_3` +
    `event_placebo_4`  + `event_placebo_5`  + `event_placebo_6`  + `event_placebo_7` + `event_placebo_8` +
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg    + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg   + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg   + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data    = data_for_placebo,
  cluster = ~county_id
)

# RRPV-only adoption (Panel b)
placebo_eq7b_rrpv_only <- feols(
  log_install ~
    `event_placebo_-8` + `event_placebo_-7` + `event_placebo_-6` + `event_placebo_-5` +
    `event_placebo_-4` + `event_placebo_-3` + `event_placebo_-2` +
    `event_placebo_0`  + `event_placebo_1`  + `event_placebo_2`  + `event_placebo_3` +
    `event_placebo_4`  + `event_placebo_5`  + `event_placebo_6`  + `event_placebo_7` + `event_placebo_8` +
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg    + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg   + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg   + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data    = data_for_placebo,
  cluster = ~county_id
)

#-------------------------------------------------------------------------------
# 4. COEFFICIENTS FOR PLOTTING
#-------------------------------------------------------------------------------

event_var_names <- paste0("event_placebo_", event_range)

placebo_data_7a <- extract_coef_ci(placebo_eq7a_rrpv_bs, event_var_names)
placebo_data_7b <- extract_coef_ci(placebo_eq7b_rrpv_only, event_var_names)

placebo_data_7a$event_month <- factor(event_range, levels = event_range)
placebo_data_7b$event_month <- factor(event_range, levels = event_range)

#-------------------------------------------------------------------------------
# 5. PLOTTING PANELS (a) AND (b)
#-------------------------------------------------------------------------------

# Panel (a): RRPV-BS placebo event-study
p_7a <- ggplot(placebo_data_7a, aes(x = event_month, y = coef, group = 1)) +
  geom_ribbon(
    aes(ymin = lower_ci, ymax = upper_ci, fill = "95% CI"),
    alpha = 0.5
  ) +
  geom_line(
    aes(color = "Estimated coefficients"),
    linewidth = 1
  ) +
  geom_point(
    aes(color = "Estimated coefficients"),
    size = 3
  ) +
  geom_hline(
    yintercept = 0,
    linetype   = "dashed",
    color      = "black"
  ) +
  scale_y_continuous(
    name   = "Estimated coefficients",
    breaks = seq(-0.02, 0.04, by = 0.01),
    limits = c(-0.02, 0.04),
    guide  = "prism_offset"
  ) +
  scale_x_discrete(
    expand = expansion(mult = c(0.06, 0.06))
  ) +
  xlab("Months before and after placebo event") +
  scale_color_manual(
    name   = NULL,
    values = c("Estimated coefficients" = "springgreen4")
  ) +
  scale_fill_manual(
    name   = NULL,
    values = c("95% CI" = "aquamarine2")
  ) +
  common_plot_theme_base() +
  labs(tag = "a")

# Panel (b): RRPV-only placebo event-study
p_7b <- ggplot(placebo_data_7b, aes(x = event_month, y = coef, group = 1)) +
  geom_ribbon(
    aes(ymin = lower_ci, ymax = upper_ci, fill = "95% CI"),
    alpha = 0.5
  ) +
  geom_line(
    aes(color = "Estimated coefficients"),
    linewidth = 1
  ) +
  geom_point(
    aes(color = "Estimated coefficients"),
    size = 3
  ) +
  geom_hline(
    yintercept = 0,
    linetype   = "dashed",
    color      = "black"
  ) +
  scale_y_continuous(
    name   = "Estimated coefficients",
    breaks = seq(-0.02, 0.04, by = 0.01),
    limits = c(-0.02, 0.04),
    guide  = "prism_offset"
  ) +
  scale_x_discrete(
    expand = expansion(mult = c(0.06, 0.06))
  ) +
  xlab("Months before and after placebo event") +
  scale_color_manual(
    name   = NULL,
    values = c("Estimated coefficients" = "springgreen4")
  ) +
  scale_fill_manual(
    name   = NULL,
    values = c("95% CI" = "aquamarine2")
  ) +
  common_plot_theme_base() +
  labs(tag = "b")

#-------------------------------------------------------------------------------
# 6. COMBINE AND SAVE
#-------------------------------------------------------------------------------

supp_fig7 <- p_7a | p_7b

# PNG
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_7.png"),
  plot = supp_fig7,
  width = 12, height = 6, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)

# PDF
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_7.pdf"),
  plot = supp_fig7,
  width = 12, height = 6, units = "in",
  device = cairo_pdf
)


#===============================================================================
# END OF SCRIPT
#===============================================================================
