#===============================================================================
# Figure 5: Earnings from Solar and Battery Adoptions
#
# Description: This script generates Figure 5 (panels a-f) using calculated
# economic return data. All values are extracted from previously saved
# model results and summary statistics.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(ggplot2)
library(dplyr)
library(tidyr)
library(patchwork)
library(cowplot)

# --- Paths ---
path_root   <- "D:/rooftop"
path_output <- file.path(path_root, "return/results")
output_dir  <- "D:/rooftop/Fig"


# --- Load Data ---
data_panel_a <- readRDS(file.path(path_output, "fig5_panel_a_data.RDS"))
data_panel_b <- readRDS(file.path(path_output, "fig5_panel_b_data.RDS"))
data_panel_c <- readRDS(file.path(path_output, "fig5_panel_c_data.RDS"))
data_panel_d <- readRDS(file.path(path_output, "fig5_panel_d_data.RDS"))
data_panel_e <- readRDS(file.path(path_output, "fig5_panel_e_data.RDS"))
data_panel_f <- readRDS(file.path(path_output, "fig5_panel_f_data.RDS"))

# --- Color Scheme ---
color_rrpv <- "#FF6B35"
color_rrpv_bs <- "#004E89"
color_sales <- "#F4A261"
color_savings <- "#2A9D8F"
color_gross <- "#E76F51"
color_net <- "#264653"
color_achieved <- "#457B9D"

# --- Common Theme ---
my_custom_theme <- theme_minimal(base_size = 20) +
  theme(
    panel.background = element_rect(fill = "white", colour = NA),
    plot.background = element_rect(fill = "white", colour = NA),
    axis.text = element_text(size = 16, face = "plain", color = "black"),
    axis.title = element_text(size = 18, face = "plain", color = "black"),
    axis.line = element_line(size = 0.6, color = "black"),
    axis.ticks = element_line(size = 0.6, color = "black"),
    axis.ticks.length = unit(0.2, "cm"),
    panel.border = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text.x = element_text(angle = 0, hjust = 0.5, vjust = 0.5, margin = margin(t = 6)),
    axis.text.y = element_text(margin = margin(r = 6)),
    plot.margin = margin(t = 12, r = 12, b = 12, l = 12),
    legend.position = "bottom",
    legend.title = element_text(size = 18, face = "plain", color = "black"),
    legend.text = element_text(size = 16, face = "plain", color = "black"),
    legend.background = element_rect(fill = "white", colour = NA),
    legend.key = element_rect(fill = "white", colour = NA),
    plot.title = element_text(hjust = 0.5, face = "plain", size = 22, color = "black"),
    strip.text = element_text(size = 18, face = "plain", color = "black")
  )

label_size_unified <- 6.5


#===============================================================================
# Panel a: Overall Economic Return
#===============================================================================

df_panel_a <- data_panel_a %>%
  pivot_longer(
    cols = c(Total_Gross_Return_Per_kWp, Net_Earnings_Per_kWp),
    names_to = "Metric_Type",
    values_to = "Value"
  ) %>%
  mutate(
    Metric_Type = factor(Metric_Type, 
                         levels = c("Total_Gross_Return_Per_kWp", "Net_Earnings_Per_kWp"),
                         labels = c("Total Gross Return", "Net Return")),
    System = factor(System, levels = c("RRPV Adopters", "RRPV-BS Adopters")),
    Value = round(Value, 0)
  )

panel_a_colors <- c("Total Gross Return" = color_gross, "Net Return" = color_net)

plot_a <- ggplot(df_panel_a, aes(x = System, y = Value, fill = Metric_Type)) +
  geom_col(position = position_dodge(width = 0.7), width = 0.6) +
  geom_text(aes(label = Value),
            position = position_dodge(width = 0.7),
            vjust = -0.5, size = label_size_unified, color = "black", fontface = "plain") +
  scale_fill_manual(values = panel_a_colors, name = "Return Type") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
  scale_x_discrete(expand = expansion(add = c(0.6, 0.6))) +
  labs(
    title = "Overall Economic Return",
    x = NULL,
    y = "Annual Return per kWp ($/kWp)"
  ) +
  my_custom_theme +
  theme(legend.position = "bottom")

ggsave(file.path(output_dir, "Fig_5a.pdf"), plot = plot_a, width = 8, height = 6)
ggsave(file.path(output_dir, "Fig_5a.png"), plot = plot_a, width = 8, height = 6, dpi = 1200)


#===============================================================================
# Panel b: Return Composition
#===============================================================================

df_panel_b <- data_panel_b %>%
  pivot_longer(
    cols = c(Sales_Return_Pct, Bill_Savings_Pct),
    names_to = "Component",
    values_to = "Percentage"
  ) %>%
  mutate(
    Component = factor(Component,
                       levels = c("Sales_Return_Pct", "Bill_Savings_Pct"),
                       labels = c("Sales Return", "Bill Savings")),
    System = factor(System, levels = c("RRPV Adopters", "RRPV-BS Adopters")),
    Percentage = round(Percentage, 0)
  )

panel_b_colors <- c("Sales Return" = color_sales, "Bill Savings" = color_savings)

plot_b <- ggplot(df_panel_b, aes(x = System, y = Percentage, fill = Component)) +
  geom_col(position = position_dodge(width = 0.7), width = 0.6) +
  geom_text(aes(label = paste0(Percentage, "%")),
            position = position_dodge(width = 0.7),
            vjust = -0.5, size = label_size_unified, color = "black", fontface = "plain") +
  scale_fill_manual(values = panel_b_colors, name = "Return Component") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.15)), limits = c(0, 100)) +
  scale_x_discrete(expand = expansion(add = c(0.6, 0.6))) +
  labs(
    title = "Return Composition",
    x = NULL,
    y = "Percentage (%)"
  ) +
  my_custom_theme +
  theme(legend.position = "bottom")

ggsave(file.path(output_dir, "Fig_5b.pdf"), plot = plot_b, width = 8, height = 6)
ggsave(file.path(output_dir, "Fig_5b.png"), plot = plot_b, width = 8, height = 6, dpi = 1200)


#===============================================================================
# Panel c: Self-Sufficiency and Economic Viability
#===============================================================================

df_panel_c <- data_panel_c %>%
  pivot_longer(
    cols = c(Self_Sufficiency, Economic_Viability),
    names_to = "Metric",
    values_to = "Percentage"
  ) %>%
  mutate(
    Metric = factor(Metric, 
                    levels = c("Self_Sufficiency", "Economic_Viability"),
                    labels = c("Self-Sufficiency", "Economic Viability")),
    System = factor(System, levels = c("RRPV Adopters", "RRPV-BS Adopters")),
    Percentage = round(Percentage, 0)
  )

plot_c <- ggplot(df_panel_c, aes(x = System, y = Percentage)) +
  geom_col(fill = color_achieved, width = 0.6) +
  geom_text(
    aes(label = paste0(Percentage, "%")),
    position = position_nudge(y = 0),
    vjust = -0.5,
    size = label_size_unified, color = "black") +
  facet_wrap(~ Metric, ncol = 2, strip.position = "bottom") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05)), limits = c(0, 100)) +
  scale_x_discrete(expand = expansion(add = c(0.4, 0.4))) +
  labs(
    title = "Self-Sufficiency and Economic Viability",
    x = NULL,
    y = "Percentage (%)"
  ) +
  my_custom_theme +
  theme(
    legend.position = "none",
    strip.text = element_text(size = 16, face = "plain", color = "black"),
    strip.placement = "outside",
    strip.background = element_blank(),
    panel.spacing = unit(1.5, "lines"),
    axis.text.x = element_text(size = 12, angle = 0, hjust = 0.5),
    plot.title = element_text(hjust = 0.5),
    plot.margin = margin(t = 12, r = 12, b = 35, l = 12)
  )

ggsave(file.path(output_dir, "Fig_5c.pdf"), plot = plot_c, width = 10, height = 6)
ggsave(file.path(output_dir, "Fig_5c.png"), plot = plot_c, width = 10, height = 6, dpi = 1200)


#===============================================================================
# Panel d: RRPV by Temperature Zone
#===============================================================================

df_panel_d <- data_panel_d %>%
  mutate(
    Sales_Return = round(Sales_Return, 0),
    Bill_Savings = round(Bill_Savings, 0),
    Total = Sales_Return + Bill_Savings,
    temp_zone = factor(temp_zone, levels = c("Cool", "Mild", "Hot"))
  ) %>%
  pivot_longer(
    cols = c(Sales_Return, Bill_Savings),
    names_to = "Component",
    values_to = "Value"
  ) %>%
  mutate(
    Component = factor(Component, 
                       levels = c("Sales_Return", "Bill_Savings"),
                       labels = c("Sales Return", "Bill Savings"))
  )

plot_d <- ggplot(df_panel_d, aes(x = temp_zone, y = Value, fill = Component)) +
  geom_col(position = "stack", width = 0.6) +
  geom_text(aes(label = Value),
            position = position_stack(vjust = 0.5), size = label_size_unified, color = "white", fontface = "plain") +
  geom_text(data = df_panel_d %>% 
              select(temp_zone, Total) %>% 
              distinct(),
            aes(x = temp_zone, y = Total, label = Total),
            vjust = -0.5, size = label_size_unified, color = "black", fontface = "plain", inherit.aes = FALSE) +
  scale_fill_manual(values = c("Sales Return" = color_sales, "Bill Savings" = color_savings),
                    name = "Return Component") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
  scale_x_discrete(expand = expansion(add = c(0.6, 0.6))) +
  labs(
    title = "RRPV Adopters - Return by Temp Zone",
    x = "Temperature Zone",
    y = "Annual Return per kWp ($/kWp)"
  ) +
  my_custom_theme +
  theme(plot.title = element_text(hjust = 0.5, face = "plain", size = 22, color = "black"))

ggsave(file.path(output_dir, "Fig_5d.pdf"), plot = plot_d, width = 8, height = 6)
ggsave(file.path(output_dir, "Fig_5d.png"), plot = plot_d, width = 8, height = 6, dpi = 1200)


#===============================================================================
# Panel e: RRPV-BS by Temperature Zone
#===============================================================================

df_panel_e <- data_panel_e %>%
  mutate(
    Sales_Return = round(Sales_Return, 0),
    Bill_Savings = round(Bill_Savings, 0),
    Total = Sales_Return + Bill_Savings,
    temp_zone = factor(temp_zone, levels = c("Cool", "Mild", "Hot"))
  ) %>%
  pivot_longer(
    cols = c(Sales_Return, Bill_Savings),
    names_to = "Component",
    values_to = "Value"
  ) %>%
  mutate(
    Component = factor(Component, 
                       levels = c("Sales_Return", "Bill_Savings"),
                       labels = c("Sales Return", "Bill Savings"))
  )

plot_e <- ggplot(df_panel_e, aes(x = temp_zone, y = Value, fill = Component)) +
  geom_col(position = "stack", width = 0.6) +
  geom_text(aes(label = Value),
            position = position_stack(vjust = 0.5), size = label_size_unified, color = "white", fontface = "plain") +
  geom_text(data = df_panel_e %>% 
              select(temp_zone, Total) %>% 
              distinct(),
            aes(x = temp_zone, y = Total, label = Total),
            vjust = -0.5, size = label_size_unified, color = "black", fontface = "plain", inherit.aes = FALSE) +
  scale_fill_manual(values = c("Sales Return" = color_sales, "Bill Savings" = color_savings),
                    name = "Return Component") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
  scale_x_discrete(expand = expansion(add = c(0.6, 0.6))) +
  labs(
    title = "RRPV-BS Adopters - Return by Temp Zone",
    x = "Temperature Zone",
    y = "Annual Return per kWp ($/kWp)"
  ) +
  my_custom_theme +
  theme(plot.title = element_text(hjust = 0.5, face = "plain", size = 22, color = "black"))

ggsave(file.path(output_dir, "Fig_5e.pdf"), plot = plot_e, width = 8, height = 6)
ggsave(file.path(output_dir, "Fig_5e.png"), plot = plot_e, width = 8, height = 6, dpi = 1200)


#===============================================================================
# Panel f: Self-Sufficiency by Temperature Zone
#===============================================================================

df_panel_f <- data_panel_f %>%
  mutate(
    Self_Sufficiency_Rate = round(Self_Sufficiency_Rate, 0),
    System = factor(System, levels = c("RRPV Adopters", "RRPV-BS Adopters")),
    temp_zone = factor(temp_zone, levels = c("Cool", "Mild", "Hot"))
  )

plot_f <- ggplot(df_panel_f, aes(x = temp_zone, y = Self_Sufficiency_Rate, fill = System)) +
  geom_col(position = position_dodge(width = 0.7), width = 0.6) +
  geom_text(aes(label = paste0(Self_Sufficiency_Rate, "%"), group = System),
            position = position_dodge(width = 0.7), vjust = -0.5, size = label_size_unified, color = "black", fontface = "plain") +
  scale_fill_manual(values = c("RRPV Adopters" = color_rrpv, 
                               "RRPV-BS Adopters" = color_rrpv_bs), 
                    name = "System Type") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.15)), limits = c(0, 110)) +
  scale_x_discrete(expand = expansion(add = c(0.6, 0.6))) +
  labs(
    title = 'Self-Sufficiency by Temp Zone',
    x = "Temperature Zone",
    y = "Self-Sufficiency (%)"
  ) +
  my_custom_theme +
  theme(
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.justification = "center",
    plot.title = element_text(hjust = 0.5, face = "plain", size = 22, color = "black")
  )

ggsave(file.path(output_dir, "Fig_5f.pdf"), plot = plot_f, width = 8, height = 6)
ggsave(file.path(output_dir, "Fig_5f.png"), plot = plot_f, width = 8, height = 6, dpi = 1200)


#===============================================================================
# COMBINE AND SAVE FIGURE 5
#===============================================================================

main_panels_grid <- plot_grid(
  plot_a, plot_b, plot_c,
  plot_d, plot_e, plot_f,
  ncol = 3,
  nrow = 2,
  labels = c("a", "b", "c", "d", "e", "f"),
  align = "hv",
  axis = "tb",
  label_size = 22,
  rel_heights = c(1, 1)
)

# PDF
ggsave(
  filename = file.path(output_dir, "Figure_5.pdf"),
  plot = main_panels_grid,
  width = 24, height = 16, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Figure_5.png"),
  plot = main_panels_grid,
  width = 24, height = 16, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)


#===============================================================================
# END OF SCRIPT
#===============================================================================
