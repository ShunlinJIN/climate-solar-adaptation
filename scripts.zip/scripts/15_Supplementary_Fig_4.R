#===============================================================================
# Supplementary Fig. 4: Distribution of battery storage capacity among RRPV-BS adopters
#
# Description:
# This script generates a bar chart showing the distribution of battery storage
# capacity among RRPV-BS adopters.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(dplyr)
library(ggplot2)
library(ggprism)
library(readr)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root  <- "D:/rooftop"
path_data  <- file.path(path_root, "electricity")
output_dir <- file.path(path_root, "Fig")

rrpv_bs_data <- readRDS(file.path(path_data, "rrpv_bs_electricity_panel.RDS"))

#-------------------------------------------------------------------------------
# 2. DATA PREPARATION FOR PLOTTING
#-------------------------------------------------------------------------------

# Calculate Battery Capacity Distribution
capacity_stats <- rrpv_bs_data %>%
  distinct(household_id, battery_capacity_kwh) %>%
  group_by(battery_capacity_kwh) %>%
  summarise(count = n(), .groups = 'drop') %>%
  mutate(percentage = count / sum(count) * 100)

#-------------------------------------------------------------------------------
# 3. CREATE AND SAVE THE PLOT
#-------------------------------------------------------------------------------

plot_supp_fig4 <- ggplot(capacity_stats, aes(x = factor(battery_capacity_kwh), y = percentage)) +
  geom_bar(stat = "identity", fill = "blue", alpha = 0.8) +
  geom_text(
    aes(label = sprintf("%.1f%%\n(n=%d)", percentage, count)), 
    vjust = -0.3,
    size = 3,
    color = "black"
  ) +
  scale_y_continuous(
    name = "Percentage (%)",
    expand = expansion(mult = c(0, 0.1)),
    guide = "prism_offset"
  ) +
  scale_x_discrete(
    name = "Battery Capacity (kWh)",
    expand = expansion(add = c(0.6, 0.6))
  ) +
  theme_prism() +
  theme(
    axis.text       = element_text(size = 10, face = "plain"),
    axis.title      = element_text(size = 12, face = "plain"),
    axis.line       = element_line(linewidth = 0.5),
    axis.ticks      = element_line(linewidth = 0.5),
    axis.text.x     = element_text(angle = 0, hjust = 0.5, vjust = 0.5),
    legend.position = "none",
    plot.margin     = margin(10, 10, 10, 10),
    panel.border    = element_blank()
  )

# PDF
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_4.pdf"),
  plot = plot_supp_fig4,
  width = 10, height = 6, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_4.png"),
  plot = plot_supp_fig4,
  width = 10, height = 6, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)


#===============================================================================
# END OF SCRIPT
#===============================================================================
