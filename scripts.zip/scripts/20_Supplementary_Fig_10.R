#===============================================================================
# Supplementary Fig. 10: Distribution of daily generation-to-consumption ratios
# Panels:
#   a) RRPV-only adopters
#   b) RRPV-BS adopters
#
# Description:
# This figure presents the empirical distribution of the daily generation-to-
# consumption ratio at the household-day level, separately for RRPV-only adopters
# and RRPV-BS adopters.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(ggprism)
library(cowplot)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root     <- "D:/rooftop"
path_electric <- file.path(path_root, "electricity")
output_dir    <- file.path(path_root, "Fig")

# Text size parameters
text_size_axis_text  <- 10
text_size_axis_title <- 11
text_size_plot_tag   <- 14

# Common plotting theme
common_plot_theme <- function() {
  theme_prism() +
    theme(
      axis.text        = element_text(size = text_size_axis_text,  face = "plain", color = "black"),
      axis.title       = element_text(size = text_size_axis_title, face = "plain", color = "black"),
      axis.ticks       = element_line(linewidth = 0.5, color = "black"),
      axis.line        = element_line(linewidth = 0.5, color = "black"),
      panel.grid       = element_blank(),
      plot.tag.position = "topleft",
      plot.tag         = element_text(face = "bold", size = text_size_plot_tag)
    )
}

#-------------------------------------------------------------------------------
# 2. LOAD HOUSEHOLD-DAY ELECTRICITY PANEL
#-------------------------------------------------------------------------------

# RRPV-only
rrpv_data <- readRDS(file.path(path_electric, "rrpv_electricity_panel.RDS"))

# RRPV-BS
rrpv_bs_data <- readRDS(file.path(path_electric, "rrpv_bs_electricity_panel.RDS"))

#-------------------------------------------------------------------------------
# 3. COMPUTE DAILY GENERATION-TO-CONSUMPTION RATIOS
#-------------------------------------------------------------------------------

# RRPV
daily_ratios_rrpv <- rrpv_data %>%
  mutate(
    ratio = total_generation_kwh / pmax(total_consumption_kwh, 0.001)
  ) %>%
  filter(!is.na(ratio), ratio <= 50)

density_rrpv     <- density(daily_ratios_rrpv$ratio, na.rm = TRUE)
max_density_rrpv <- max(density_rrpv$y)

# RRPV-BS
daily_ratios_rrpv_bs <- rrpv_bs_data %>%
  mutate(
    ratio = total_generation_kwh / pmax(total_consumption_kwh, 0.001)
  ) %>%
  filter(!is.na(ratio), ratio <= 50)

density_rrpv_bs     <- density(daily_ratios_rrpv_bs$ratio, na.rm = TRUE)
max_density_rrpv_bs <- max(density_rrpv_bs$y)

#-------------------------------------------------------------------------------
# 4. PLOTTING PANELS (a) AND (b)
#-------------------------------------------------------------------------------

# Panel (a): RRPV-only adopters
p10_a <- ggplot(daily_ratios_rrpv, aes(x = ratio)) +
  geom_histogram(
    aes(y = after_stat(density)),
    bins  = 50,
    fill  = "lightblue",
    color = "black",
    alpha = 0.7
  ) +
  geom_density(
    color     = "darkblue",
    linewidth = 1.2
  ) +
  geom_vline(
    xintercept = 1,
    linetype   = "dashed",
    color      = "red",
    linewidth  = 1
  ) +
  annotate(
    "text",
    x        = 1,
    y        = max_density_rrpv * 0.9,
    label    = "Generation = Consumption",
    color    = "red",
    fontface = "bold",
    hjust    = -0.1,
    size     = 3.5
  ) +
  scale_y_continuous(name = "Density") +
  scale_x_continuous(name = "Generation/Consumption ratio (RRPV-only adopters)") +
  common_plot_theme() +
  labs(tag = "a")

# Panel (b): RRPV-BS adopters
p10_b <- ggplot(daily_ratios_rrpv_bs, aes(x = ratio)) +
  geom_histogram(
    aes(y = after_stat(density)),
    bins  = 50,
    fill  = "lightblue",
    color = "black",
    alpha = 0.7
  ) +
  geom_density(
    color     = "darkblue",
    linewidth = 1.2
  ) +
  geom_vline(
    xintercept = 1,
    linetype   = "dashed",
    color      = "red",
    linewidth  = 1
  ) +
  annotate(
    "text",
    x        = 1,
    y        = max_density_rrpv_bs * 0.9,
    label    = "Generation = Consumption",
    color    = "red",
    fontface = "bold",
    hjust    = -0.1,
    size     = 3.5
  ) +
  scale_y_continuous(name = "Density") +
  scale_x_continuous(name = "Generation/Consumption ratio (RRPV-BS adopters)") +
  common_plot_theme() +
  labs(tag = "b")

#-------------------------------------------------------------------------------
# 5. COMBINE AND SAVE
#-------------------------------------------------------------------------------

p10_combined <- plot_grid(
  p10_a, p10_b,
  ncol = 2,
  align = "hv"
)

# PDF
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_10.pdf"),
  plot = p10_combined,
  width = 10, height = 6, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_10.png"),
  plot = p10_combined,
  width = 10, height = 6, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)



#===============================================================================
# END OF SCRIPT
#===============================================================================
