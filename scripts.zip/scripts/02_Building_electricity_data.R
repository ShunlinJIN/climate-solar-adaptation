#===============================================================================
# Electricity Consumption and Generation Data Integration Script 
# (RRPV & RRPV-BS & Non-adopters)
#
# Description: This script constructs a household-day panel dataset for analyzing 
#              electricity consumption and generation patterns. It integrates
#              generation/consumption records, pricing, weather, and controls
#              to prepare datasets for the distributed lag model (Equation 8), 
#              economic return calculations and optimal system size estimation.
#
#===============================================================================

library(tidyverse)
library(lubridate)

# --- Paths ---
path_root   <- "D:/rooftop"
path_output <- file.path(path_root, "electricity")

# --- Constants ---
DATE_START <- as.Date("2018-06-01")
DATE_END   <- as.Date("2020-12-31")

#-------------------------------------------------------------------------------
# 1. LOAD RAW DATA
#-------------------------------------------------------------------------------

# Household Electricity Data
rrpv_elec_raw    <- readRDS(file.path(path_root, "rrpv_daily_electricity.RDS"))
rrpv_bs_elec_raw <- readRDS(file.path(path_root, "rrpv_bs_daily_electricity.RDS"))
control_elec_raw <- readRDS(file.path(path_root, "control_household_electricity.RDS"))

# Covariates
pricing_data  <- readRDS(file.path(path_root, "electricity_pricing_daily.RDS"))
weather_daily <- readRDS(file.path(path_root, "weather_daily_county.RDS"))
calendar_data <- readRDS(file.path(path_root, "calendar_holidays.RDS"))
income_annual <- readRDS(file.path(path_root, "income_annual.RDS"))

#-------------------------------------------------------------------------------
# 2. PROCESS RRPV HOUSEHOLD DATA
#-------------------------------------------------------------------------------

rrpv_elec <- rrpv_elec_raw %>%
  mutate(
    household_id = as.character(household_id),
    county_id = as.character(county_code),
    time = as.Date(date)
  ) %>%
  filter(time >= DATE_START & time <= DATE_END) %>%
  select(
    household_id, 
    county_id, 
    time,
    install_capacity_kwp = install_capacity,
    total_generation_kwh = pv_generation,
    total_consumption_kwh = total_consumption,
    self_consumption_kwh = pv_self_consumption,
    grid_import_kwh = grid_purchase,
    grid_export_kwh = grid_export
  )

#-------------------------------------------------------------------------------
# 3. PROCESS RRPV-BS HOUSEHOLD DATA
#-------------------------------------------------------------------------------

rrpv_bs_elec <- rrpv_bs_elec_raw %>%
  mutate(
    household_id = as.character(household_id),
    county_id = as.character(county_code),
    time = as.Date(date)
  ) %>%
  filter(time >= DATE_START & time <= DATE_END) %>%
  select(
    household_id, 
    county_id, 
    time,
    install_capacity_kwp = install_capacity,
    battery_capacity_kwh = battery_capacity,
    total_generation_kwh = pv_generation,
    total_consumption_kwh = total_consumption,
    consumption_from_pv_kwh = consumption_pv,
    consumption_from_battery_kwh = consumption_battery,
    consumption_from_grid_kwh = consumption_grid,
    battery_charge_kwh = battery_input,
    battery_remaining_kwh = battery_end_charge,
    grid_export_kwh = grid_export
  )

#-------------------------------------------------------------------------------
# 4. PROCESS CONTROL VARIABLES
#-------------------------------------------------------------------------------

# Pricing Data
pricing_clean <- pricing_data %>%
  mutate(
    county_id = as.character(county_code),
    time = as.Date(date)
  ) %>%
  select(
    county_id, 
    time,
    retail_price_yuan_kwh = retail_price,
    feedin_tariff_yuan_kwh = feedin_tariff
  )

# Weather Data (Quadratic terms included for non-linear effects)
weather_clean <- weather_daily %>%
  mutate(
    county_id = as.character(county_code),
    time = as.Date(date)
  ) %>%
  filter(time >= DATE_START & time <= DATE_END) %>%
  select(
    county_id, 
    time,
    temp_avg_celsius = temp_avg_daily,
    sunshine_hours_daily_avg = sunshine_duration,
    rainfall_mm_daily_avg = precipitation,
    humidity_pct_daily_avg = relative_humidity,
    windspeed_ms_daily_avg = wind_speed
  ) %>%
  mutate(
    temp_avg_celsius_sq = temp_avg_celsius^2,
    sunshine_hours_daily_avg_sq = sunshine_hours_daily_avg^2,
    rainfall_mm_daily_avg_sq = rainfall_mm_daily_avg^2,
    humidity_pct_daily_avg_sq = humidity_pct_daily_avg^2,
    windspeed_ms_daily_avg_sq = windspeed_ms_daily_avg^2
  )

# Calendar Data
calendar_clean <- calendar_data %>%
  mutate(
    time = as.Date(date),
    is_holiday = if_else(is_national_holiday == 1, 1, 0),
    is_weekend = if_else(day_of_week %in% c("Saturday", "Sunday"), 1, 0)
  ) %>%
  select(time, is_holiday, is_weekend)

# Income Data
income_clean <- income_annual %>%
  mutate(county_id = as.character(county_code)) %>%
  select(county_id, year, income_per_capita)

#-------------------------------------------------------------------------------
# 5. CREATE INCOME DECILES
#-------------------------------------------------------------------------------

# Create income deciles based on pre-study period (2015-2017) average per capita disposable income
income_deciles <- income_clean %>%
  filter(year >= 2015 & year <= 2017) %>%
  group_by(county_id) %>%
  summarise(avg_income_pre_study = mean(income_per_capita, na.rm = TRUE), .groups = "drop") %>%
  mutate(income_decile = ntile(avg_income_pre_study, 10)) %>%
  select(county_id, income_decile)

#-------------------------------------------------------------------------------
# 6. MERGE DATA AND CREATE FINAL PANELS
#-------------------------------------------------------------------------------
create_final_panel <- function(base_data) {
  base_data %>%
    left_join(pricing_clean, by = c("county_id", "time")) %>%
    left_join(weather_clean, by = c("county_id", "time")) %>%
    left_join(calendar_clean, by = "time") %>%
    mutate(year = year(time)) %>%
    left_join(income_clean, by = c("county_id", "year")) %>%
    left_join(income_deciles, by = "county_id") %>%
    mutate(
      month = month(time),
      is_holiday = replace_na(is_holiday, 0),
      is_weekend = replace_na(is_weekend, 0)
    )
}

# Apply to RRPV and RRPV-BS
rrpv_panel_clean    <- create_final_panel(rrpv_elec)
rrpv_bs_panel_clean <- create_final_panel(rrpv_bs_elec)

# Process non-adopters
control_panel_clean <- control_elec_raw %>%
  mutate(
    household_id = as.character(household_id),
    county_id = as.character(county_code),
    time = as.Date(date)
  ) %>%
  filter(time >= DATE_START & time <= DATE_END) %>%
  select(
    household_id, 
    county_id, 
    time, 
    total_consumption_kwh = total_consumption
  ) %>%
  mutate(
    total_generation_kwh = 0,
    install_capacity_kwp = 0
  ) %>%
  create_final_panel()

#-------------------------------------------------------------------------------
# 7. SAVE FINAL DATASETS
#-------------------------------------------------------------------------------

saveRDS(rrpv_panel_clean, file.path(path_output, "rrpv_electricity_panel.RDS"))
saveRDS(rrpv_bs_panel_clean, file.path(path_output, "rrpv_bs_electricity_panel.RDS"))
saveRDS(control_panel_clean, file.path(path_output, "control_electricity_panel.RDS"))

#===============================================================================
# END OF SCRIPT
#===============================================================================
