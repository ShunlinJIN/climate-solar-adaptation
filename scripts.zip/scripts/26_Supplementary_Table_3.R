#===============================================================================
# Supplementary Table 3: Household characteristics and energy use in survey data
#
# Description:
# This script creates a comprehensive descriptive statistics table comparing
# RRPV adopters and non-adopters using survey data. The table includes:
# - Panel A: RRPV adopters (energy consumption, system characteristics)
# - Panel B: RRPV non-adopters (energy consumption)
# - Panel C: Full sample demographic information
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(gt)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root   <- "D:/rooftop"
path_survey <- file.path(path_root, "survey")
output_dir  <- file.path(path_root, "Tables")

#-------------------------------------------------------------------------------
# 2. LOAD SURVEY DATA
#-------------------------------------------------------------------------------

survey_data <- readRDS(file.path(path_survey, "survey_panel_data.RDS"))

#-------------------------------------------------------------------------------
# 3. DEFINE VARIABLES AT OBSERVATION LEVEL
#-------------------------------------------------------------------------------

survey_data2 <- survey_data %>%
  mutate(
    monthly_elec_consumption = Monthly_Electricity_Consumption_kWh,
    monthly_elec_expenditure = monthly_elec_expenditure_yuan,
    pv_capacity              = pv_capacity_kW,
    pv_cost                  = pv_cost_yuan,
    monthly_generation       = monthly_solar_generation,
    monthly_revenue          = Monthly_Revenue_RMB,
    self_consumption         = Solar_Self_Consumption_kWh,
    hh_head_male             = ifelse(!is.na(Male_Head_Age), 1, 0),
    hh_head_age              = ifelse(!is.na(Male_Head_Age), Male_Head_Age, Female_Head_Age),
    hh_head_education        = ifelse(!is.na(Male_head_education_level_years),
                                      Male_head_education_level_years,
                                      Female_head_education_level_years),
    household_size           = Household_Size,
    monthly_income           = Monthly_Per_Capita_Household_Income * Household_Size,
    roof_area                = Roof_Area
  )

#-------------------------------------------------------------------------------
# 4. AGGREGATE TO HOUSEHOLD-LEVEL AVERAGES OVER ALL WAVES
#-------------------------------------------------------------------------------

household_level <- survey_data2 %>%
  group_by(household_id) %>%
  summarise(
    rrpv_adopter             = max(treatment, na.rm = TRUE),
    monthly_elec_consumption = mean(monthly_elec_consumption, na.rm = TRUE),
    monthly_elec_expenditure = mean(monthly_elec_expenditure, na.rm = TRUE),
    pv_capacity              = mean(pv_capacity,              na.rm = TRUE),
    pv_cost                  = mean(pv_cost,                  na.rm = TRUE),
    monthly_generation       = mean(monthly_generation,       na.rm = TRUE),
    monthly_revenue          = mean(monthly_revenue,          na.rm = TRUE),
    self_consumption         = mean(self_consumption,         na.rm = TRUE),
    hh_head_male             = mean(hh_head_male,             na.rm = TRUE),
    hh_head_age              = mean(hh_head_age,              na.rm = TRUE),
    hh_head_education        = mean(hh_head_education,        na.rm = TRUE),
    household_size           = mean(household_size,           na.rm = TRUE),
    monthly_income           = mean(monthly_income,           na.rm = TRUE),
    roof_area                = mean(roof_area,                na.rm = TRUE)
  ) %>%
  ungroup()

#-------------------------------------------------------------------------------
# 5. BUILD PANEL A – RRPV ADOPTERS
#-------------------------------------------------------------------------------

panel_a_data <- household_level %>% filter(rrpv_adopter == 1)

panel_a_summary <- data.frame(
  Variable = c(
    "Energy consumption characteristics",
    "Total electricity consumption (kWh/month)",
    "Electricity expenditure (RMB/month)",
    
    "Solar system characteristics",
    "Installed PV capacity (kW)",
    "Purchase and installation cost (RMB)",
    "Monthly electricity generation (kWh/month)",
    "Monthly electricity sales revenue (RMB/month)",
    "Monthly self-consumed PV electricity (kWh/month)"
  ),
  Mean = c(
    NA,
    mean(panel_a_data$monthly_elec_consumption, na.rm = TRUE),
    mean(panel_a_data$monthly_elec_expenditure, na.rm = TRUE),
    
    NA,
    mean(panel_a_data$pv_capacity,        na.rm = TRUE),
    mean(panel_a_data$pv_cost,            na.rm = TRUE),
    mean(panel_a_data$monthly_generation, na.rm = TRUE),
    mean(panel_a_data$monthly_revenue,    na.rm = TRUE),
    mean(panel_a_data$self_consumption,   na.rm = TRUE)
  ),
  SD = c(
    NA,
    sd(panel_a_data$monthly_elec_consumption, na.rm = TRUE),
    sd(panel_a_data$monthly_elec_expenditure, na.rm = TRUE),
    
    NA,
    sd(panel_a_data$pv_capacity,        na.rm = TRUE),
    sd(panel_a_data$pv_cost,            na.rm = TRUE),
    sd(panel_a_data$monthly_generation, na.rm = TRUE),
    sd(panel_a_data$monthly_revenue,    na.rm = TRUE),
    sd(panel_a_data$self_consumption,   na.rm = TRUE)
  )
)

#-------------------------------------------------------------------------------
# 6. BUILD PANEL B – RRPV NON-ADOPTERS
#-------------------------------------------------------------------------------

panel_b_data <- household_level %>% filter(rrpv_adopter == 0)

panel_b_summary <- data.frame(
  Variable = c(
    "Energy consumption characteristics",
    "Total electricity consumption (kWh/month)",
    "Electricity expenditure (RMB/month)"
  ),
  Mean = c(
    NA,
    mean(panel_b_data$monthly_elec_consumption, na.rm = TRUE),
    mean(panel_b_data$monthly_elec_expenditure, na.rm = TRUE)
  ),
  SD = c(
    NA,
    sd(panel_b_data$monthly_elec_consumption, na.rm = TRUE),
    sd(panel_b_data$monthly_elec_expenditure, na.rm = TRUE)
  )
)

#-------------------------------------------------------------------------------
# 7. BUILD PANEL C – FULL SAMPLE DEMOGRAPHICS
#-------------------------------------------------------------------------------

panel_c_data <- household_level

panel_c_summary <- data.frame(
  Variable = c(
    "Household head gender (male=1)",
    "Household head age (years)",
    "Household head education level (years)",
    "Household size (persons)",
    "Monthly household income (RMB/month)",
    "Available roof area (m2)"
  ),
  Mean = c(
    mean(panel_c_data$hh_head_male,      na.rm = TRUE),
    mean(panel_c_data$hh_head_age,       na.rm = TRUE),
    mean(panel_c_data$hh_head_education, na.rm = TRUE),
    mean(panel_c_data$household_size,    na.rm = TRUE),
    mean(panel_c_data$monthly_income,    na.rm = TRUE),
    mean(panel_c_data$roof_area,         na.rm = TRUE)
  ),
  SD = c(
    sd(panel_c_data$hh_head_male,      na.rm = TRUE),
    sd(panel_c_data$hh_head_age,       na.rm = TRUE),
    sd(panel_c_data$hh_head_education, na.rm = TRUE),
    sd(panel_c_data$household_size,    na.rm = TRUE),
    sd(panel_c_data$monthly_income,    na.rm = TRUE),
    sd(panel_c_data$roof_area,         na.rm = TRUE)
  )
)

#-------------------------------------------------------------------------------
# 8. COMBINE PANELS INTO SUPPLEMENTARY TABLE 3 DATASET
#-------------------------------------------------------------------------------

supp_table_3_data <- bind_rows(
  data.frame(
    Variable = paste0("Panel A: Adopters (N=", format(nrow(panel_a_data), big.mark=","), ")"),
    Mean    = NA,
    SD      = NA
  ),
  panel_a_summary,
  data.frame(
    Variable = paste0("Panel B: Non-adopters (N=", format(nrow(panel_b_data), big.mark=","), ")"),
    Mean    = NA,
    SD      = NA
  ),
  panel_b_summary,
  data.frame(
    Variable = paste0("Panel C: Demographic information (full sample, N=", format(nrow(panel_c_data), big.mark=","), ")"),
    Mean    = NA,
    SD      = NA
  ),
  panel_c_summary
)

#-------------------------------------------------------------------------------
# 9. FORMAT SUPPLEMENTARY TABLE 3 WITH GT
#-------------------------------------------------------------------------------

gt_table <- supp_table_3_data %>%
  gt() %>%
  fmt_number(columns = c(Mean, SD), decimals = 2) %>%
  sub_missing(columns = everything(), missing_text = "") %>% 
  cols_label(
    Variable = "Variable",
    Mean     = "Mean",
    SD       = "SD"
  ) %>%
  tab_style(
    style = list(
      cell_text(weight = "bold"),
      cell_fill(color = "#f7f7f7")
    ),
    locations = cells_body(
      rows = startsWith(Variable, "Panel")
    )
  ) %>%
  tab_style(
    style = cell_text(style = "italic", indent = px(10)),
    locations = cells_body(
      rows = is.na(Mean) & !startsWith(Variable, "Panel")
    )
  ) %>%
  tab_style(
    style = cell_text(indent = px(20)),
    locations = cells_body(
      rows = !is.na(Mean)
    )
  ) %>%
  tab_header(
    title = md("**Supplementary Table 3:** Household characteristics and energy use in survey data")
  ) %>%
  tab_options(
    table.font.size                 = px(12),
    heading.title.font.size         = px(14),
    column_labels.font.weight       = "bold",
    table.border.top.style          = "solid",
    table.border.top.width          = px(2),
    table.border.top.color          = "black",
    table.border.bottom.style       = "solid",
    table.border.bottom.width       = px(2),
    table.border.bottom.color       = "black",
    column_labels.border.bottom.style = "solid",
    column_labels.border.bottom.width = px(2),
    column_labels.border.bottom.color = "black",
    data_row.padding                = px(4)
  ) %>%
  opt_horizontal_padding(scale = 2)

print(gt_table)

#-------------------------------------------------------------------------------
# 10. SAVE OUTPUTS
#-------------------------------------------------------------------------------

gtsave(gt_table, filename = file.path(output_dir, "Supplementary_Table_3.docx"))

write.csv(
  supp_table_3_data,
  file.path(output_dir, "Supplementary_Table_3_data.csv"),
  row.names = FALSE
)

saveRDS(
  supp_table_3_data,
  file.path(output_dir, "supp_table_3_data.RDS")
)

#===============================================================================
# END OF SCRIPT
#===============================================================================
