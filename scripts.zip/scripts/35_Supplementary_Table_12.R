#===============================================================================
# Supplementary Table 12: Primary motivation for adopting RRPV
#
# Description:
# This script creates a table comparing the primary motivations for RRPV
# adoption between high-income and low-income households. Motivations include
# earning revenue, reducing expenses, addressing power outages, environmental
# concerns, and other factors.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(officer)
library(flextable)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root  <- "D:/rooftop"
path_data  <- file.path(path_root, "survey")
path_output <- file.path(path_root, "tables")

#-------------------------------------------------------------------------------
# 2. LOAD SURVEY DATA
#-------------------------------------------------------------------------------

survey_data <- readRDS(file.path(path_data, "survey_panel_data.RDS"))

#-------------------------------------------------------------------------------
# 3. AGGREGATE TO HOUSEHOLD LEVEL AND CLASSIFY INCOME GROUPS
#-------------------------------------------------------------------------------

household_level <- survey_data %>%
  group_by(household_id) %>%
  summarise(
    rrpv_adopter = max(if_else(treated == 1 & !is.na(pv_capacity_kW), 1, 0), na.rm = TRUE),
    per_capita_income = mean(Monthly_Per_Capita_Household_Income, na.rm = TRUE),
    primary_motivation = first(primary_motivation),
    .groups = "drop"
  )

# Create income quintiles
household_level <- household_level %>%
  mutate(
    income_quintile = cut(
      per_capita_income,
      breaks = quantile(per_capita_income, probs = seq(0, 1, 0.2), na.rm = TRUE),
      labels = 1:5,
      include.lowest = TRUE
    )
  )

#-------------------------------------------------------------------------------
# 4. FILTER ADOPTERS AND CLASSIFY AS HIGH/LOW INCOME
#-------------------------------------------------------------------------------

adopters_motivation <- household_level %>%
  filter(rrpv_adopter == 1) %>%
  mutate(
    income_group = case_when(
      income_quintile == 1 ~ "Low-income",
      income_quintile == 5 ~ "High-income",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(income_group))

#-------------------------------------------------------------------------------
# 5. CALCULATE MOTIVATION DISTRIBUTION BY INCOME GROUP
#-------------------------------------------------------------------------------

table12_data <- adopters_motivation %>%
  group_by(income_group, primary_motivation) %>%
  summarise(n = n(), .groups = "drop") %>%
  group_by(income_group) %>%
  mutate(Share = n / sum(n) * 100) %>%
  select(-n) %>%
  pivot_wider(
    names_from = income_group,
    values_from = Share,
    values_fill = 0
  ) %>%
  rename(`Primary Motivation` = primary_motivation)

# Reorder columns
table12_data <- table12_data %>%
  select(`Primary Motivation`, `High-income` = `High-income`, 
         `Low-income` = `Low-income`)

# Add Total row
table12_data <- table12_data %>%
  add_row(
    `Primary Motivation` = "Total",
    `High-income` = 100,
    `Low-income` = 100
  )

#-------------------------------------------------------------------------------
# 6. EXPORT INTERMEDIATE DATA
#-------------------------------------------------------------------------------

write_csv(
  table12_data,
  file.path(path_output, "Supplementary_Table_12_data.csv")
)

saveRDS(
  table12_data,
  file.path(path_output, "supp_table_12_data.RDS")
)

#-------------------------------------------------------------------------------
# 7. FORMAT TABLE WITH FLEXTABLE
#-------------------------------------------------------------------------------

# Format percentages
table12_formatted <- table12_data %>%
  mutate(
    `High-income` = sprintf("%.1f", `High-income`),
    `Low-income` = sprintf("%.1f", `Low-income`)
  )

ft <- flextable(table12_formatted) %>%
  set_header_labels(
    `Primary Motivation` = "Primary Motivation",
    `High-income` = "High-income households (%)",
    `Low-income` = "Low-income households (%)"
  ) %>%
  width(j = 1, width = 3.5) %>%
  width(j = 2:3, width = 2.0) %>%
  align(j = 2:3, align = "center", part = "all") %>%
  align(j = 1, align = "left", part = "all") %>%
  bold(part = "header") %>%
  bold(i = which(table12_formatted$`Primary Motivation` == "Total")) %>%
  bg(i = which(table12_formatted$`Primary Motivation` == "Total"), 
     bg = "#f0f0f0") %>%
  hline_top(border = fp_border(width = 2), part = "header") %>%
  hline_bottom(border = fp_border(width = 2), part = "header") %>%
  hline(i = nrow(table12_formatted) - 1, border = fp_border(width = 1)) %>%
  hline_bottom(border = fp_border(width = 2), part = "body") %>%
  fontsize(size = 10, part = "all") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  set_caption(
    caption = as_paragraph(
      as_b("Supplementary Table 12. "),
      "Primary motivation for adopting RRPV"
    ),
    align_with_table = FALSE
  )

#-------------------------------------------------------------------------------
# 8. EXPORT TO WORD
#-------------------------------------------------------------------------------

doc <- read_docx() %>%
  body_add_flextable(value = ft)

output_path <- file.path(path_output, "Supplementary_Table_12.docx")
print(doc, target = output_path)

#===============================================================================
# END OF SCRIPT
#===============================================================================
