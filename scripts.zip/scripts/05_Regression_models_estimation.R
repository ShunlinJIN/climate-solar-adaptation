#===============================================================================
# Regression Models Estimation Script
#
# Description: This script estimates all econometric models (Equations 1-8)
# presented in the manuscript. Each model is precisely matched to its 
# corresponding equation specification. All estimated model objects are 
# saved for subsequent extraction and visualization.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        15/11/2025
#===============================================================================

library(tidyverse)
library(fixest)
library(lubridate)

# --- Paths ---
path_root   <- "D:/rooftop"
path_models <- file.path(path_root, "models")

# --- Load Data ---
data_adoption     <- readRDS(file.path(path_root, "adoption/rrpv_analysis_panel.RDS"))
data_elec_rrpv    <- readRDS(file.path(path_root, "electricity/rrpv_electricity_panel.RDS"))
data_elec_rrpv_bs <- readRDS(file.path(path_root, "electricity/rrpv_bs_electricity_panel.RDS"))


#-------------------------------------------------------------------------------
# EQUATION (1): Baseline Temperature-Adoption Response
#
# Specification:
#   log(Install_cmy) = Σ βj*Temp_j,cmy + γ*X_cmy + λ_c + δ_ym + ε_cmy
#
# Where:
#   - Y: log(1 + installations)
#   - X: 9 temperature bins (reference: 15-20°C), weather controls (sunshine, 
#        rainfall, humidity, windspeed + quadratics), PM2.5, income, PV firms
#   - Fixed Effects: county_id, year^month
#   - Cluster: county_id
#
# Used in: Figure 1a (baseline coefficients), Figure 1d (robustness baseline)
#-------------------------------------------------------------------------------

eq1_baseline <- feols(
  log_install ~ 
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data = data_adoption,
  cluster = ~county_id
)

saveRDS(eq1_baseline, file.path(path_models, "eq1_baseline.RDS"))


#-------------------------------------------------------------------------------
# EQUATION (2): Cumulative Temperature Effects
#
# Specification:
#   log(Install_cmy) = ΣΣ βj*Temp_j,c,m-k,y + γ*X_cmy + λ_c + δ_ym + ε_cmy
#   (k=0,1,2,3,4 lags)
#
# Where:
#   - Y: log(1 + installations)
#   - X: Current + 4 lagged temperature bins, same weather/economic controls as Eq(1)
#   - Fixed Effects: county_id, year^month
#   - Cluster: county_id
#
# Used in: Figure 1b (lagged temperature effects)
#-------------------------------------------------------------------------------

data_for_eq2 <- data_adoption %>%
  arrange(county_id, time) %>%
  group_by(county_id) %>%
  mutate(
    across(c("temp_below_neg5", "temp_neg5_to_0", "temp_0_to_5", 
             "temp_5_to_10", "temp_10_to_15", "temp_20_to_25", 
             "temp_25_to_30", "temp_above_30"), 
           list(lag1 = ~lag(., 1), lag2 = ~lag(., 2), 
                lag3 = ~lag(., 3), lag4 = ~lag(., 4)),
           .names = "{.col}_{.fn}")
  ) %>%
  ungroup()

eq2_cumulative <- feols(
  log_install ~
    # Current month
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    # Lag 1
    temp_below_neg5_lag1 + temp_neg5_to_0_lag1 + temp_0_to_5_lag1 + 
    temp_5_to_10_lag1 + temp_10_to_15_lag1 + temp_20_to_25_lag1 + 
    temp_25_to_30_lag1 + temp_above_30_lag1 +
    # Lag 2
    temp_below_neg5_lag2 + temp_neg5_to_0_lag2 + temp_0_to_5_lag2 + 
    temp_5_to_10_lag2 + temp_10_to_15_lag2 + temp_20_to_25_lag2 + 
    temp_25_to_30_lag2 + temp_above_30_lag2 +
    # Lag 3
    temp_below_neg5_lag3 + temp_neg5_to_0_lag3 + temp_0_to_5_lag3 + 
    temp_5_to_10_lag3 + temp_10_to_15_lag3 + temp_20_to_25_lag3 + 
    temp_25_to_30_lag3 + temp_above_30_lag3 +
    # Lag 4
    temp_below_neg5_lag4 + temp_neg5_to_0_lag4 + temp_0_to_5_lag4 + 
    temp_5_to_10_lag4 + temp_10_to_15_lag4 + temp_20_to_25_lag4 + 
    temp_25_to_30_lag4 + temp_above_30_lag4 +
    # Other controls
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data = data_for_eq2,
  cluster = ~county_id
)

saveRDS(eq2_cumulative, file.path(path_models, "eq2_cumulative.RDS"))


#-------------------------------------------------------------------------------
# EQUATION (3): Pilot Policy DID Model
#
# Specification:
#   log(Install_cmy) = φ0 + α1*PVpilot_cmy + γ1*X_cmy + λ_c + δ_ym + ε_cmy
#
# Where:
#   - Y: log(1 + installations)
#   - Treatment: PVpilot_cmy (=1 if county is pilot after Sep 2021)
#   - X: Same controls as Eq(1)
#   - Fixed Effects: county_id, year^month
#   - Cluster: county_id
#
# Note: This is a simple DID model, NOT used for figure generation
#-------------------------------------------------------------------------------

eq3_pilot_did <- feols(
  log_install ~
    pilot_dummy +
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data = data_adoption,
  cluster = ~county_id
)

saveRDS(eq3_pilot_did, file.path(path_models, "eq3_pilot_did.RDS"))


#-------------------------------------------------------------------------------
# EQUATION (4): Pilot Policy Event Study
#
# Specification:
#   log(Install_cmy) = φ0 + Σ αk*D_PVpilot_cmy,k + γ1*X_cmy + λ_c + δ_ym + ε_cmy
#   (k ∈ [-8,8], k≠-1)
#
# Where:
#   - Y: log(1 + installations)
#   - Event dummies: D_PVpilot_cmy,k (k=-1 is reference)
#   - X: Same controls as Eq(1)
#   - Fixed Effects: county_id, year^month
#   - Cluster: county_id
#
# Used in: Figure 1c (pilot policy event study)
#-------------------------------------------------------------------------------

data_for_eq4 <- data_adoption %>%
  group_by(county_id) %>%
  mutate(
    pilot_start = if_else(sum(pilot_dummy) > 0, 
                          min(time[pilot_dummy == 1]), 
                          NA_Date_),
    months_to_pilot = if_else(
      !is.na(pilot_start),  
      as.numeric(interval(pilot_start, time) %/% months(1)),
      NA_real_
    )
  ) %>%
  ungroup()

# Generate dummy variables for window [-8, 8], excluding -1
for (k in c(-8:-2, 0:8)) {
  var_name <- paste0("event_pilot_", k)
  data_for_eq4[[var_name]] <- if_else(data_for_eq4$months_to_pilot == k, 1, 0, missing = 0)
}

eq4_pilot_event <- feols(
  log_install ~
    `event_pilot_-8` + `event_pilot_-7` + `event_pilot_-6` + `event_pilot_-5` +
    `event_pilot_-4` + `event_pilot_-3` + `event_pilot_-2` +
    event_pilot_0 + event_pilot_1 + event_pilot_2 + event_pilot_3 +
    event_pilot_4 + event_pilot_5 + event_pilot_6 + event_pilot_7 + event_pilot_8 +
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data = data_for_eq4,
  cluster = ~county_id
)

saveRDS(eq4_pilot_event, file.path(path_models, "eq4_pilot_event.RDS"))
rm(data_for_eq4)


#-------------------------------------------------------------------------------
# EQUATION (5): Pilot Policy × Temperature Interaction
#
# Specification:
#   log(Install_cmy) = φ0 + Σ(αj*Temp_j,cmy × PVpilot_cmy) + Σ βj*Temp_j,cmy 
#                      + μ*PVpilot_cmy + γ*X_cmy + λ_c + δ_ym + ε_cmy
#
# Where:
#   - Y: log(1 + installations)
#   - Interactions: PVpilot_cmy × each temperature bin
#   - X: Same controls as Eq(1) 
#   - Fixed Effects: county_id, year^month
#   - Cluster: county_id
#
# Used in: Figure 1d (robustness check with policy interaction)
#-------------------------------------------------------------------------------

eq5_pilot_temp_interact <- feols(
  log_install ~
    # Main effects
    pilot_dummy + 
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    # Interactions
    pilot_dummy:temp_below_neg5 + pilot_dummy:temp_neg5_to_0 + 
    pilot_dummy:temp_0_to_5 + pilot_dummy:temp_5_to_10 +
    pilot_dummy:temp_10_to_15 + pilot_dummy:temp_20_to_25 + 
    pilot_dummy:temp_25_to_30 + pilot_dummy:temp_above_30 +
    # Controls
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data = data_adoption,
  cluster = ~ county_id
)

saveRDS(eq5_pilot_temp_interact,
        file.path(path_models, "eq5_pilot_temp_interact.RDS"))


#-------------------------------------------------------------------------------
# EQUATION (6): Loan Program Event Study
#
# Specification:
#   log(Install_cmy) = φ0 + Σ αk*D_loan_cmy,k + γ1*X_cmy + λ_c + δ_ym + ε_cmy
#   (k ∈ [-8,8], k≠-1)
#
# Where:
#   - Y: log(1 + installations)
#   - Sample: Low-income counties only
#   - Event dummies: D_loan_cmy,k (k=-1 is reference)
#   - X: Same controls as Eq(1)
#   - Fixed Effects: county_id, year^month
#   - Cluster: county_id
#
# Used in: Figure 2f (loan program event study)
#-------------------------------------------------------------------------------

data_for_eq6 <- data_adoption %>%
  filter(income_group == "Low") %>%
  group_by(county_id) %>%
  mutate(
    loan_start = if_else(sum(loan_dummy) > 0, min(time[loan_dummy == 1]), NA_Date_),
    months_to_loan = if_else(
      !is.na(loan_start),
      as.numeric(interval(loan_start, time) %/% months(1)),
      NA_real_
    )
  ) %>%
  ungroup()

for (k in c(-8:-2, 0:8)) {
  var_name <- paste0("event_loan_", k)
  data_for_eq6[[var_name]] <- if_else(data_for_eq6$months_to_loan == k, 1, 0, missing = 0)
}

eq6_loan_event <- feols(
  log_install ~
    `event_loan_-8` + `event_loan_-7` + `event_loan_-6` + `event_loan_-5` +
    `event_loan_-4` + `event_loan_-3` + `event_loan_-2` +
    event_loan_0 + event_loan_1 + event_loan_2 + event_loan_3 +
    event_loan_4 + event_loan_5 + event_loan_6 + event_loan_7 + event_loan_8 +
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data = data_for_eq6,
  cluster = ~county_id
)

saveRDS(eq6_loan_event, file.path(path_models, "eq6_loan_event.RDS"))
rm(data_for_eq6)


#-------------------------------------------------------------------------------
# EQUATION (7): Power Outage Event Studies
#
# Specification:
#   log(Install_cmy) = φ0 + Σ αk*D_Outage_cmy,k + γ1*X_cmy + λ_c + δ_ym + ε_cmy
#   (k ∈ [-8,8], k≠-1)
#
# Where:
#   - Y: log(1 + installations) OR log(1 + RRPV-BS installations)
#   - Event dummies: D_Outage_cmy,k (k=-1 is reference)
#   - X: Same controls as Eq(1)
#   - Fixed Effects: county_id, year^month
#   - Cluster: county_id
#
# Used in: Figure 3b (RRPV-BS), Figure 3c (RRPV-only), Figure 3d (with interaction)
#-------------------------------------------------------------------------------
data_for_eq7 <- data_adoption %>%
  group_by(county_id) %>%
  mutate(
    outage_start = if_else(sum(outage_dummy) > 0, 
                           min(time[outage_dummy == 1]), 
                           NA_Date_),
    months_to_outage = if_else(
      !is.na(outage_start),
      as.numeric(interval(outage_start, time) %/% months(1)),
      NA_real_
    )
  ) %>%
  ungroup()

for (k in c(-8:-2, 0:8)) {
  var_name <- paste0("event_outage_", k)
  data_for_eq7[[var_name]] <- if_else(data_for_eq7$months_to_outage == k, 1, 0, missing = 0)
}

# 7a: RRPV-BS adoption response (Figure 3b)
eq7a_outage_rrpv_bs <- feols(
  log_install_bs ~
    `event_outage_-8` + `event_outage_-7` + `event_outage_-6` + `event_outage_-5` +
    `event_outage_-4` + `event_outage_-3` + `event_outage_-2` +
    event_outage_0 + event_outage_1 + event_outage_2 + event_outage_3 +
    event_outage_4 + event_outage_5 + event_outage_6 + event_outage_7 + event_outage_8 +
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data = data_for_eq7,
  cluster = ~county_id
)
saveRDS(eq7a_outage_rrpv_bs, file.path(path_models, "eq7a_outage_rrpv_bs.RDS"))

# 7b: RRPV-only adoption response (Figure 3c)
eq7b_outage_total_rrpv <- feols(
  log_install ~
    `event_outage_-8` + `event_outage_-7` + `event_outage_-6` + `event_outage_-5` +
    `event_outage_-4` + `event_outage_-3` + `event_outage_-2` +
    event_outage_0 + event_outage_1 + event_outage_2 + event_outage_3 +
    event_outage_4 + event_outage_5 + event_outage_6 + event_outage_7 + event_outage_8 +
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data = data_for_eq7,
  cluster = ~county_id
)
saveRDS(eq7b_outage_total_rrpv, file.path(path_models, "eq7b_outage_total_rrpv.RDS"))

# 7c: Outage × Temperature interaction for RRPV-BS (Figure 3d)
eq7c_outage_temp_interact <- feols(
  log_install_bs ~
    outage_dummy +
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    outage_dummy:temp_below_neg5 + outage_dummy:temp_neg5_to_0 + 
    outage_dummy:temp_0_to_5 + outage_dummy:temp_5_to_10 +
    outage_dummy:temp_10_to_15 + outage_dummy:temp_20_to_25 + 
    outage_dummy:temp_25_to_30 + outage_dummy:temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data    = data_adoption,
  cluster = ~ county_id
)

saveRDS(eq7c_outage_temp_interact,
        file.path(path_models, "eq7c_outage_temp_interact.RDS"))

rm(data_for_eq7) 


#-------------------------------------------------------------------------------
# RRPV-BS Temperature Response
#
# Re-estimates Equation (1) specification using RRPV-BS as dependent variable
# Used in: Figure 3a
#-------------------------------------------------------------------------------

rrpv_bs_temp_response <- feols(
  log_install_bs ~ 
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data = data_adoption,
  cluster = ~county_id
)

saveRDS(rrpv_bs_temp_response, file.path(path_models, "rrpv_bs_temp_response.RDS"))


#-------------------------------------------------------------------------------
# ROBUSTNESS CHECKS FOR EQUATION (1)
#
# Re-estimates baseline model on various subsamples
# Used in: Figure 1d
#-------------------------------------------------------------------------------

# Pre-COVID subsample
robust_pre_covid <- feols(
  log_install ~ 
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data = data_adoption %>% filter(time < as.Date("2020-01-01")),
  cluster = ~county_id
)
saveRDS(robust_pre_covid, file.path(path_models, "robust_pre_covid.RDS"))

# Non-pilot counties
robust_no_pilot <- feols(
  log_install ~ 
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data = data_adoption %>% filter(pilot_dummy == 0),
  cluster = ~county_id
)
saveRDS(robust_no_pilot, file.path(path_models, "robust_no_pilot.RDS"))

# No subsidy period
robust_no_subsidy <- feols(
  log_install ~ 
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    pm25_concentration + income_per_capita + num_pv_firms |
    county_id + year^month,
  data = data_adoption %>% filter(time >= as.Date("2022-01-01")),
  cluster = ~county_id
)
saveRDS(robust_no_subsidy, file.path(path_models, "robust_no_subsidy.RDS"))


#-------------------------------------------------------------------------------
# HETEROGENEITY ANALYSIS
#
# Description: Re-estimates the baseline specification (Equation 1) across 
# different subsamples to test for heterogeneous effects.
#
# Note: The function 'run_hetero' includes an argument 'include_income_control'.
# - Set to TRUE (default) for non-income subgroups to maintain consistency 
#   with the baseline model (controlling for economic factors).
# - Set to FALSE for income-based subgroups to avoid multicollinearity 
#   between the grouping variable and the control variable.
#
# Used in: Figure 2a-2e
#-------------------------------------------------------------------------------

run_hetero <- function(subset_data, model_name, include_income_control = TRUE) {
  
  if (include_income_control) {
    fml <- log_install ~
      temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
      temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
      sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
      rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
      humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
      windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
      pm25_concentration + num_pv_firms + income_per_capita |
      county_id + year^month
  } else {
    fml <- log_install ~
      temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
      temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
      sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
      rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
      humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
      windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
      pm25_concentration + num_pv_firms |
      county_id + year^month
  }
  
  m <- feols(
    fml,
    data = subset_data,
    cluster = ~county_id
  )
  
  saveRDS(m, file.path(path_models, paste0("hetero_", model_name, ".RDS")))
}


# --- 1. Temperature Average Heterogeneity (Figure 2a) ---
# Control for income: YES
run_hetero(data_adoption %>% filter(temp_avg_longterm_high == 1), "temp_long_high", include_income_control = TRUE)
run_hetero(data_adoption %>% filter(temp_avg_longterm_high == 0), "temp_long_low", include_income_control = TRUE)
run_hetero(data_adoption %>% filter(temp_avg_shortterm_high == 1), "temp_short_high", include_income_control = TRUE)
run_hetero(data_adoption %>% filter(temp_avg_shortterm_high == 0), "temp_short_low", include_income_control = TRUE)

# --- 2. Temperature Fluctuation Heterogeneity (Figure 2b) ---
# Control for income: YES
run_hetero(data_adoption %>% filter(temp_fluctuation_longterm_high == 1), "fluct_long_high", include_income_control = TRUE)
run_hetero(data_adoption %>% filter(temp_fluctuation_longterm_high == 0), "fluct_long_low", include_income_control = TRUE)
run_hetero(data_adoption %>% filter(temp_fluctuation_shortterm_high == 1), "fluct_short_high", include_income_control = TRUE)
run_hetero(data_adoption %>% filter(temp_fluctuation_shortterm_high == 0), "fluct_short_low", include_income_control = TRUE)

# --- 3. Solar Radiation Heterogeneity (Figure 2c) ---
# Control for income: YES
run_hetero(data_adoption %>% filter(solar_radiation_group == "High"), "solar_high", include_income_control = TRUE)
run_hetero(data_adoption %>% filter(solar_radiation_group == "Medium"), "solar_medium", include_income_control = TRUE)
run_hetero(data_adoption %>% filter(solar_radiation_group == "Low"), "solar_low", include_income_control = TRUE)

# --- 4. Land Slope Heterogeneity (Figure 2d) ---
# Control for income: YES
run_hetero(data_adoption %>% filter(land_slope_group == "High"), "slope_high", include_income_control = TRUE)
run_hetero(data_adoption %>% filter(land_slope_group == "Medium"), "slope_medium", include_income_control = TRUE)
run_hetero(data_adoption %>% filter(land_slope_group == "Low"), "slope_low", include_income_control = TRUE)

# --- 5. Income Level Heterogeneity (Figure 2e) ---
# Control for income: NO 
run_hetero(data_adoption %>% filter(income_group == "High"), "income_high", include_income_control = FALSE)
run_hetero(data_adoption %>% filter(income_group == "Medium"), "income_medium", include_income_control = FALSE)
run_hetero(data_adoption %>% filter(income_group == "Low"), "income_low", include_income_control = FALSE)


#-------------------------------------------------------------------------------
# EQUATION (8): Distributed Lag Model for Electricity Consumption
#
# Specification:
#   EC_id = alpha + beta0*EG_i,d + beta1*EG_i,d-1 + beta2*EG_i,d-2 + beta3*EG_i,d-3 
#           + tau1*Temp_id + tau2*Temp_id^2 
#           + lambda_iy + delta_my + gamma1*Holiday_d + gamma2*Weekend_d + ε_id
#
# Where:
#   - Y: total_consumption_kwh (daily household electricity consumption)
#   - X: total_generation_kwh (current + 3 lags), temp_avg_celsius, temp_avg_celsius_sq,
#        is_holiday, is_weekend
#   - Fixed Effects: household_id^year, year^month
#   - Cluster: household_id
#
# Used in: Figure 4a (RRPV), 4b (RRPV-BS), 4c (RRPV income heterogeneity), 
#          4d (RRPV-BS income heterogeneity)
#-------------------------------------------------------------------------------

run_distributed_lag_model <- function(df, model_name) {
  
  model <- feols(
    total_consumption_kwh ~
      total_generation_kwh + 
      l(total_generation_kwh, 1) + 
      l(total_generation_kwh, 2) + 
      l(total_generation_kwh, 3) +
      temp_avg_celsius + temp_avg_celsius_sq +
      is_holiday + is_weekend |
      household_id^year + year^month,
    data = df,
    panel.id = ~household_id + time, 
    cluster = ~household_id
  )
  
  saveRDS(model, file.path(path_models, model_name))
  return(model)
}

#-------------------------------------------------------------------------------
# Main Models
#-------------------------------------------------------------------------------
# 1. Main RRPV Model (Figure 4a)
eq8a_rrpv_dlm <- run_distributed_lag_model(data_elec_rrpv, "eq8a_rrpv_dlm.RDS")
# 2. Main RRPV-BS Model (Figure 4b)
eq8b_rrpv_bs_dlm <- run_distributed_lag_model(data_elec_rrpv_bs, "eq8b_rrpv_bs_dlm.RDS")


#-------------------------------------------------------------------------------
# INCOME DECILE HETEROGENEITY (Distributed Lag Model)
# Used in: Figure 4c (RRPV), Figure 4d (RRPV-BS)
#-------------------------------------------------------------------------------

run_income_decile_hetero <- function(df, adopter_type) {
  
  df_with_decile <- df %>%
    filter(!is.na(income_decile))
  
  for (i in 1:10) {
    subset_data <- df_with_decile %>% filter(income_decile == i)
    model_name  <- paste0("eq8_hetero_", adopter_type, "_decile", i, ".RDS")
    
    # Skip estimation if sample size is too small
    if(nrow(subset_data) > 100) {
      run_distributed_lag_model(subset_data, model_name)
    }
  }
}

# RRPV Income Deciles
run_income_decile_hetero(data_elec_rrpv, "rrpv")
# RRPV-BS Income Deciles
run_income_decile_hetero(data_elec_rrpv_bs, "rrpv_bs")


#===============================================================================
# END OF SCRIPT
#===============================================================================
