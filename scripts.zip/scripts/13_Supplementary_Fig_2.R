#===============================================================================
# Supplementary Figure 2: Spatial Distribution of RRPV Installations
#
# Description:
# This script generates county-level maps showing the spatial distribution of
# RRPV installations across four provinces: Fujian, Liaoning, Hubei, and Jiangsu.
# It aggregates monthly panel data to the county level and visualizes the
# total installation counts using a shared gradient color scheme.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(dplyr)
library(ggplot2)
library(sf)
library(patchwork)
library(readr)
library(scales)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root <- "D:/rooftop"
path_map  <- file.path(path_root, "map")
path_data <- file.path(path_root, "adoption")
fig_dir   <- file.path(path_root, "Fig")

#-------------------------------------------------------------------------------
# 2. LOAD AND PREPARE GEOGRAPHIC DATA
#-------------------------------------------------------------------------------

# Load China county-level shapefile
china_counties <- st_read(
  file.path(path_map, "china_county_boundaries.shp"),
  stringsAsFactors = FALSE,
  quiet = TRUE
)

# Set coordinate reference system to WGS84
st_crs(china_counties) <- 4326

# Extract province codes and ensure county codes are characters
china_counties <- china_counties %>%
  mutate(
    county_code = as.character(QUHUADAIMA),
    province_code = substr(county_code, 1, 2)
  )

# Filter boundaries for the four target provinces
shp_jiangsu  <- filter(china_counties, province_code == "32")
shp_liaoning <- filter(china_counties, province_code == "21")
shp_hubei    <- filter(china_counties, province_code == "42")
shp_fujian   <- filter(china_counties, province_code == "35")

#-------------------------------------------------------------------------------
# 3. LOAD AND AGGREGATE INSTALLATION DATA
#-------------------------------------------------------------------------------

# Load the main analysis panel
panel_data <- readRDS(file.path(path_data, "rrpv_analysis_panel.RDS"))

# Aggregate installations by county
county_totals <- panel_data %>%
  group_by(county_id) %>%
  summarise(total_installation_count = sum(installations, na.rm = TRUE), .groups = "drop") %>%
  mutate(county_code = as.character(county_id))

#-------------------------------------------------------------------------------
# 4. MERGE GEOGRAPHIC AND INSTALLATION DATA
#-------------------------------------------------------------------------------

# Function to merge shapefile with data and handle missing values
merge_data <- function(shp_data, data_df) {
  shp_data %>%
    left_join(data_df, by = "county_code") %>%
    mutate(total_installation_count = replace_na(total_installation_count, 0))
}

# Create mapping datasets for each province
map_data_jiangsu  <- merge_data(shp_jiangsu, county_totals)
map_data_liaoning <- merge_data(shp_liaoning, county_totals)
map_data_hubei    <- merge_data(shp_hubei, county_totals)
map_data_fujian   <- merge_data(shp_fujian, county_totals)

#-------------------------------------------------------------------------------
# 5. DEFINE COMMON PLOTTING THEME AND COLOR SCALE
#-------------------------------------------------------------------------------

# Calculate global range for consistent color scaling across panels
all_counts <- c(
  map_data_jiangsu$total_installation_count,
  map_data_fujian$total_installation_count,
  map_data_liaoning$total_installation_count,
  map_data_hubei$total_installation_count
)

install_min <- min(all_counts, na.rm = TRUE)
install_max <- max(all_counts, na.rm = TRUE)

# Define plotting colors
color_low  <- "white"
color_high <- "#448CC6"

# Define map theme
map_theme <- theme_minimal(base_size = 14) +
  theme(
    panel.background = element_rect(fill = "white", colour = NA),
    plot.background  = element_rect(fill = "white", colour = NA),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border     = element_blank(),
    axis.text        = element_blank(),
    axis.title       = element_blank(),
    axis.ticks       = element_blank(),
    legend.position  = "right",
    legend.title     = element_text(size = 12, face = "bold"),
    legend.text      = element_text(size = 10),
    legend.key.height = unit(0.8, "cm"),
    legend.key.width  = unit(0.4, "cm"),
    plot.title       = element_text(hjust = 0, size = 14, face = "bold", 
                                    margin = margin(b = 10)),
    plot.margin      = margin(t = 5, r = 5, b = 5, l = 5)
  )

# Define shared scale for legend collection
shared_scale <- scale_fill_gradient(
  low = color_low,
  high = color_high,
  limits = c(install_min, install_max),
  na.value = "grey90",
  name = "RRPV\ninstallation",
  breaks = scales::pretty_breaks(n = 5)(c(install_min, install_max))
)

#-------------------------------------------------------------------------------
# 6. CREATE INDIVIDUAL PROVINCE MAPS
#-------------------------------------------------------------------------------

# Panel a: Fujian
map_fujian <- ggplot(map_data_fujian) +
  geom_sf(aes(fill = total_installation_count), color = "grey80", linewidth = 0.1) +
  shared_scale +
  labs(title = "a") +
  map_theme

# Panel b: Liaoning
map_liaoning <- ggplot(map_data_liaoning) +
  geom_sf(aes(fill = total_installation_count), color = "grey80", linewidth = 0.1) +
  shared_scale +
  labs(title = "b") +
  map_theme

# Panel c: Hubei
map_hubei <- ggplot(map_data_hubei) +
  geom_sf(aes(fill = total_installation_count), color = "grey80", linewidth = 0.1) +
  shared_scale +
  labs(title = "c") +
  map_theme

# Panel d: Jiangsu
map_jiangsu <- ggplot(map_data_jiangsu) +
  geom_sf(aes(fill = total_installation_count), color = "grey80", linewidth = 0.1) +
  shared_scale +
  labs(title = "d") +
  map_theme

#-------------------------------------------------------------------------------
# 7. COMBINE MAPS AND SAVE
#-------------------------------------------------------------------------------

# Arrange in 2x2 grid with collected legend
combined_map <- (map_fujian + map_liaoning) /
  (map_hubei + map_jiangsu) +
  plot_layout(guides = "collect") +
  plot_annotation(
    theme = theme(
      legend.position = "right",
      plot.margin = margin(t = 10, r = 10, b = 10, l = 10)
    )
  )


# PDF
ggsave(
  filename = file.path(fig_dir, "Supplementary_Fig_2.pdf"),
  plot = combined_map,
  width = 10, height = 9, units = "in",
  device = cairo_pdf,
  bg = "white"
)

# PNG
ggsave(
  filename = file.path(fig_dir, "Supplementary_Fig_2.png"),
  plot = combined_map,
  width = 10, height = 9, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)


#===============================================================================
# END OF SCRIPT
#===============================================================================
