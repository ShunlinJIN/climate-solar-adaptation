#===============================================================================
# Supplementary Fig. 11: Propensity score matching for survey-based analysis
#
# Description:
# This script implements propensity score matching (PSM) to address potential 
# bias between RRPV adopters and non-adopters using survey data. It performs:
# - Logistic regression to estimate propensity scores based on pre-adoption 
#   household characteristics (income, roof area, household size, and 
#   average monthly electricity consumption in the 12 months prior to adoption)
# - One-to-one nearest-neighbor matching with replacement using a caliper of 0.01
# - Visualization of propensity score distributions before and after matching
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(ggprism)
library(patchwork)
library(MatchIt)
library(cobalt)
library(lubridate)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root   <- "D:/rooftop"
path_survey <- file.path(path_root, "survey")
output_dir  <- file.path(path_root, "Fig")

# Text size parameters
text_size_axis_text   <- 14
text_size_axis_title  <- 16
text_size_legend_text <- 14
text_size_title       <- 16

# Density estimation bandwidth
bw_unmatched <- 0.04
bw_matched   <- 0.04

#-------------------------------------------------------------------------------
# 2. LOAD AND PREPARE OBSERVATION-LEVEL DATA
#-------------------------------------------------------------------------------

survey_data_raw <- readRDS(file.path(path_survey, "survey_panel_data.RDS"))

# Create wave_date from year and month
survey_data_obs <- survey_data_raw %>%
  mutate(
    wave_date                = ymd(paste(year, month, "01", sep = "-")),
    monthly_elec_consumption = Monthly_Electricity_Consumption_kWh,
    pv_capacity              = pv_capacity_kW,
    household_size           = Household_Size,
    monthly_income           = Monthly_Per_Capita_Household_Income * Household_Size,
    roof_area                = Roof_Area,
    adoption_date            = if_else(treatment == 1, ymd(adoption_time), as.Date(NA))
  ) %>%
  arrange(household_id, wave_date)

#-------------------------------------------------------------------------------
# 3. EXTRACT PRE-ADOPTION CHARACTERISTICS
#-------------------------------------------------------------------------------

# For ADOPTERS: use data from waves before adoption
adopter_pre_data <- survey_data_obs %>%
  filter(treatment == 1) %>%
  filter(wave_date < adoption_date) %>%
  group_by(household_id) %>%
  # Use last 2 waves before adoption (approximately 12 months)
  slice_tail(n = 2) %>%
  summarise(
    pre_income          = mean(monthly_income,           na.rm = TRUE),
    pre_roof_area       = mean(roof_area,                na.rm = TRUE),
    pre_household_size  = mean(household_size,           na.rm = TRUE),
    pre_avg_consumption = mean(monthly_elec_consumption, na.rm = TRUE),
    .groups = "drop"
  )

# For NON-ADOPTERS: use baseline period (first 2 waves)
non_adopter_pre_data <- survey_data_obs %>%
  filter(treatment == 0) %>%
  group_by(household_id) %>%
  slice_head(n = 2) %>%
  summarise(
    pre_income          = mean(monthly_income,           na.rm = TRUE),
    pre_roof_area       = mean(roof_area,                na.rm = TRUE),
    pre_household_size  = mean(household_size,           na.rm = TRUE),
    pre_avg_consumption = mean(monthly_elec_consumption, na.rm = TRUE),
    .groups = "drop"
  )

# Combine adopters and non-adopters
psm_data <- bind_rows(
  adopter_pre_data     %>% mutate(treatment = 1),
  non_adopter_pre_data %>% mutate(treatment = 0)
) %>%
  filter(
    !is.na(pre_income) & !is.na(pre_roof_area) & 
      !is.na(pre_household_size) & !is.na(pre_avg_consumption)
  )

#-------------------------------------------------------------------------------
# 4. ESTIMATE PROPENSITY SCORES
#-------------------------------------------------------------------------------

ps_model <- glm(
  treatment ~ pre_income + pre_roof_area + pre_household_size + pre_avg_consumption,
  data   = psm_data,
  family = binomial(link = "logit")
)

psm_data$propensity_score <- predict(ps_model, type = "response")

#-------------------------------------------------------------------------------
# 5. PROPENSITY SCORE MATCHING
#-------------------------------------------------------------------------------

match_result <- matchit(
  treatment ~ pre_income + pre_roof_area + pre_household_size + pre_avg_consumption,
  data        = psm_data,
  method      = "nearest",
  distance    = "glm",
  link        = "logit",
  replace     = TRUE,           # matching with replacement
  caliper     = 0.01,           # caliper of 0.01
  std.caliper = FALSE,          # caliper in raw propensity score units
  ratio       = 1,              # 1:1 matching
  estimand    = "ATT"           # Average Treatment Effect on the Treated
)

#-------------------------------------------------------------------------------
# 6. EXTRACT MATCHED DATA
#-------------------------------------------------------------------------------

matched_data <- match.data(match_result)

# Merge back to panel data for subsequent DiD analysis
matched_households <- matched_data %>% select(household_id, treatment, weights, distance)

matched_panel <- survey_data_obs %>%
  inner_join(matched_households, by = "household_id") %>%
  mutate(
    post_adoption = if_else(treatment == 1 & wave_date >= adoption_date, 1, 0)
  )

saveRDS(matched_panel, file.path(path_survey, "matched_survey_panel_data.RDS"))

#-------------------------------------------------------------------------------
# 7. PREPARE DATA FOR PROPENSITY SCORE DISTRIBUTION PLOT
#-------------------------------------------------------------------------------

unmatched_plot_data <- psm_data %>%
  select(household_id, treatment, propensity_score) %>%
  mutate(
    matched_status  = "Unmatched",
    treatment_label = if_else(treatment == 1, "Treatment (Solar)", "Control (Non-Solar)"),
    weights         = 1
  )

matched_plot_data <- matched_data %>%
  select(household_id, treatment, propensity_score = distance, weights) %>%
  mutate(
    matched_status  = "Matched",
    treatment_label = if_else(treatment == 1, "Treatment (Solar)", "Control (Non-Solar)")
  )

plot_data_combined <- bind_rows(
  unmatched_plot_data %>% select(propensity_score, treatment, treatment_label, matched_status, weights),
  matched_plot_data   %>% select(propensity_score, treatment, treatment_label, matched_status, weights)
)

#-------------------------------------------------------------------------------
# 8. CALCULATE KERNEL DENSITY ESTIMATES
#-------------------------------------------------------------------------------

get_normalized_density <- function(data_subset, weights_subset, bw_val,
                                   from_val = 0, to_val = 1, n_points = 512) {
  if (length(data_subset) == 0 || sum(weights_subset) == 0) {
    x_grid <- seq(from_val, to_val, length.out = n_points)
    return(data.frame(x = x_grid, y = rep(0, length(x_grid))))
  }
  
  d_result <- density(
    data_subset,
    weights = weights_subset / sum(weights_subset),
    bw      = bw_val,
    from    = from_val,
    to      = to_val,
    n       = n_points
  )
  
  integral_val <- sum(d_result$y) * diff(d_result$x)[1]
  
  if (is.na(integral_val) || integral_val == 0) {
    normalized_y <- d_result$y * 0
  } else {
    normalized_y <- d_result$y / integral_val
  }
  
  data.frame(x = d_result$x, y = normalized_y)
}

unmatched_subset <- plot_data_combined %>% filter(matched_status == "Unmatched")

df_density_unmatched_treat <- get_normalized_density(
  unmatched_subset$propensity_score[unmatched_subset$treatment == 1],
  unmatched_subset$weights[unmatched_subset$treatment == 1],
  bw_unmatched
) %>% mutate(treatment_label = "Treatment (Solar)")

df_density_unmatched_ctrl <- get_normalized_density(
  unmatched_subset$propensity_score[unmatched_subset$treatment == 0],
  unmatched_subset$weights[unmatched_subset$treatment == 0],
  bw_unmatched
) %>% mutate(treatment_label = "Control (Non-Solar)")

df_density_unmatched <- bind_rows(df_density_unmatched_treat, df_density_unmatched_ctrl)

matched_subset <- plot_data_combined %>% filter(matched_status == "Matched")

df_density_matched_treat <- get_normalized_density(
  matched_subset$propensity_score[matched_subset$treatment == 1],
  matched_subset$weights[matched_subset$treatment == 1],
  bw_matched
) %>% mutate(treatment_label = "Treatment (Solar)")

df_density_matched_ctrl <- get_normalized_density(
  matched_subset$propensity_score[matched_subset$treatment == 0],
  matched_subset$weights[matched_subset$treatment == 0],
  bw_matched
) %>% mutate(treatment_label = "Control (Non-Solar)")

df_density_matched <- bind_rows(df_density_matched_treat, df_density_matched_ctrl)

y_axis_upper <- max(
  max(df_density_unmatched$y, na.rm = TRUE),
  max(df_density_matched$y,   na.rm = TRUE)
) * 1.05

#-------------------------------------------------------------------------------
# 9. PLOTTING THEME AND SETTINGS
#-------------------------------------------------------------------------------

label_formatter <- function(x) {
  labels <- sprintf("%.2f", x)
  labels[x == 0] <- "0"
  labels[x == 1] <- "1"
  labels
}

common_theme <- theme_prism() +
  theme(
    plot.title       = element_text(hjust = 0.5, size = text_size_title, face = "bold"),
    axis.title.x     = element_blank(),
    axis.title.y     = element_text(size = text_size_axis_title, angle = 90, margin = margin(r = 10)),
    axis.text        = element_text(size = text_size_axis_text, color = "black"),
    axis.ticks       = element_line(color = "black", linewidth = 0.5),
    axis.line        = element_line(color = "black", linewidth = 0.5),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position  = "top",
    legend.title     = element_blank(),
    legend.text      = element_text(size = text_size_legend_text),
    plot.margin      = margin(t = 12, r = 12, b = 12, l = 12)
  )

#-------------------------------------------------------------------------------
# 10. CREATE PROPENSITY SCORE DISTRIBUTION PLOTS
#-------------------------------------------------------------------------------

p_unmatched <- ggplot(
  df_density_unmatched,
  aes(x = x, y = y, color = treatment_label, linetype = treatment_label)
) +
  geom_line(linewidth = 1.2, na.rm = TRUE) +
  scale_color_manual(
    values = c("Treatment (Solar)" = "red", "Control (Non-Solar)" = "blue")
  ) +
  scale_linetype_manual(
    values = c("Treatment (Solar)" = "solid", "Control (Non-Solar)" = "dashed")
  ) +
  scale_x_continuous(
    limits = c(0, 1),
    expand = c(0, 0),
    breaks = seq(0, 1, by = 0.2),
    labels = label_formatter
  ) +
  scale_y_continuous(
    limits = c(0, y_axis_upper),
    expand = c(0, 0)
  ) +
  labs(title = "Unmatched", y = "Density") +
  common_theme

p_matched <- ggplot(
  df_density_matched,
  aes(x = x, y = y, color = treatment_label, linetype = treatment_label)
) +
  geom_line(linewidth = 1.2, na.rm = TRUE) +
  scale_color_manual(
    values = c("Treatment (Solar)" = "red", "Control (Non-Solar)" = "blue")
  ) +
  scale_linetype_manual(
    values = c("Treatment (Solar)" = "solid", "Control (Non-Solar)" = "dashed")
  ) +
  scale_x_continuous(
    limits = c(0, 1),
    expand = c(0, 0),
    breaks = seq(0, 1, by = 0.2),
    labels = label_formatter
  ) +
  scale_y_continuous(
    limits = c(0, y_axis_upper),
    expand = c(0, 0)
  ) +
  labs(title = "Matched", y = NULL) +
  common_theme

combined_ps_plot <- (p_unmatched + p_matched) +
  plot_layout(guides = "collect") +
  plot_annotation(caption = "Propensity score") &
  theme(
    plot.caption    = element_text(hjust = 0.5, size = text_size_axis_title, margin = margin(t = 10)),
    legend.position = "top",
    legend.title    = element_blank(),
    legend.text     = element_text(size = text_size_legend_text)
  )

#-------------------------------------------------------------------------------
# 11. SAVE OUTPUTS
#-------------------------------------------------------------------------------

# PDF
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_11.pdf"),
  plot = combined_ps_plot,
  width = 10, height = 6, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_11.png"),
  plot = combined_ps_plot,
  width = 10, height = 6, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)


#===============================================================================
# END OF SCRIPT
#===============================================================================
