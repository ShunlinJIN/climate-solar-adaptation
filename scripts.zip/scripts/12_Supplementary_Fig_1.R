#===============================================================================
# Supplementary Figure 1: PV Feed-in Tariffs, Subsidies, and RRPV Installations
#
# Description:
# This script generates a two-panel supplementary figure.
# - Panel a: Plots China’s historical solar electricity feed-in tariffs for 
#   different resource zones and per-kWh subsidy levels from 2013-2020.
# - Panel b: Plots the total monthly RRPV installation counts from 2018-2022.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(dplyr)
library(ggplot2)
library(tidyr)
library(stringr)
library(readr)
library(scales)
library(ggprism)
library(patchwork)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root <- "D:/rooftop"
path_policy_data <- file.path(path_root, "policy")
path_adoption_data <- file.path(path_root, "adoption")
output_dir <- file.path(path_root, "Fig")

#-------------------------------------------------------------------------------
# 2. PANEL A: FEED-IN TARIFFS AND SUBSIDIES
#-------------------------------------------------------------------------------

# Load policy data (Unit: CNY/kWh)
policy_data <- read_csv(file.path(path_policy_data, "pv_tariffs_and_subsidies.csv"), show_col_types = FALSE)

# Prepare data for plotting
data_long <- policy_data %>%
  pivot_longer(cols = -Year, names_to = "Category", values_to = "Value") %>%
  mutate(
    Category = str_replace_all(Category, c(
      "FIT_category1" = "Resource Zone I",
      "FIT_category2" = "Resource Zone II",
      "FIT_category3" = "Resource Zone III",
      "Subsidy" = "Subsidy Levels"
    ))
  )

# Create plot for panel a
p1 <- ggplot(data_long, aes(x = Year, y = Value, color = Category, shape = Category)) +
  geom_line(aes(linetype = Category), linewidth = 1) +
  geom_point(size = 3) +
  geom_text(aes(label = sprintf("%.2f", Value)), 
            vjust = -0.5, size = 2.8, color = "black", 
            nudge_x = 0.15, show.legend = FALSE) +
  scale_y_continuous(
    name = "Feed-in Tariffs and per-kWh Subsidy Levels (¥/kWh)",
    limits = c(0, 1),
    breaks = seq(0, 1, by = 0.25),
    guide = "prism_offset"
  ) +
  scale_x_continuous(breaks = unique(policy_data$Year)) +
  scale_color_manual(values = c(
    "Resource Zone I" = "red",
    "Resource Zone II" = "blue",
    "Resource Zone III" = "#00CED1",
    "Subsidy Levels" = "purple"
  )) +
  scale_shape_manual(values = c(
    "Resource Zone I" = 16,
    "Resource Zone II" = 17,
    "Resource Zone III" = 18,
    "Subsidy Levels" = 15
  )) +
  scale_linetype_manual(values = c(
    "Resource Zone I" = "solid",
    "Resource Zone II" = "solid",
    "Resource Zone III" = "solid",
    "Subsidy Levels" = "dashed"
  )) +
  coord_cartesian(clip = "off") +
  labs(x = "Year", title = "a") +
  theme_prism() +
  theme(
    axis.text = element_text(size = 10, face = "plain"),
    axis.title = element_text(size = 12, face = "plain"),
    legend.position = "top",
    legend.title = element_blank(),
    legend.text = element_text(size = 9),
    plot.margin = margin(14, 10, 10, 10),
    plot.title = element_text(size = 14, face = "bold", hjust = 0)
  ) +
  guides(
    color = guide_legend(nrow = 2), 
    shape = guide_legend(nrow = 2), 
    linetype = guide_legend(nrow = 2)
  )

#-------------------------------------------------------------------------------
# 3. PANEL B: MONTHLY RRPV INSTALLATIONS
#-------------------------------------------------------------------------------

# Load adoption data
adoption_panel <- readRDS(file.path(path_adoption_data, "rrpv_analysis_panel.RDS"))

# Aggregate monthly data
monthly_total <- adoption_panel %>%
  group_by(time) %>%
  summarise(total_installation = sum(installations, na.rm = TRUE), .groups = "drop") %>%
  rename(Month = time)

# Define COVID-19 period
break_start <- as.Date("2020-01-01")
break_end <- as.Date("2020-04-30")

# Create plot for panel b
p2 <- ggplot(monthly_total, aes(x = Month, y = total_installation)) +
  annotate("rect", 
           xmin = break_start, xmax = break_end,
           ymin = -Inf, ymax = Inf,
           fill = "gray90", alpha = 0.5) +
  geom_vline(xintercept = as.numeric(break_start), 
             linetype = "dashed", color = "red", linewidth = 0.6) +
  geom_vline(xintercept = as.numeric(break_end), 
             linetype = "dashed", color = "red", linewidth = 0.6) +
  geom_line(color = "blue", linewidth = 1) +
  geom_point(color = "blue", size = 2.5, shape = 16) +
  annotate("text", x = as.Date("2020-02-15"), 
           y = max(monthly_total$total_installation) * 0.95,
           label = "COVID-19 Period", 
           color = "red", size = 3, fontface = "plain") +
  scale_x_date(
    name = "Month",
    date_breaks = "6 months", 
    date_labels = "%Y-%m",
    limits = c(as.Date("2018-01-01"), as.Date("2022-12-31")),
    expand = expansion(mult = c(0.02, 0.02))
  ) +
  scale_y_continuous(
    name = "Total Rooftop PV Installation Count",
    labels = scales::comma,
    guide = "prism_offset"
  ) +
  labs(title = "b") +
  theme_prism() +
  theme(
    axis.text = element_text(size = 10, face = "plain"),
    axis.title = element_text(size = 12, face = "plain"),
    panel.border = element_blank(),
    plot.margin = margin(10, 10, 10, 10),
    plot.title = element_text(size = 14, face = "bold", hjust = 0)
  )

#-------------------------------------------------------------------------------
# 4. COMBINE AND SAVE
#-------------------------------------------------------------------------------

# Combine plots
combined_plot <- p1 + p2 +
  plot_layout(ncol = 2) +
  plot_annotation(
    theme = theme(
      plot.margin = margin(5, 5, 5, 5)
    )
  )

# PDF
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_1.pdf"),
  plot = combined_plot,
  width = 16, height = 6, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_1.png"),
  plot = combined_plot,
  width = 16, height = 6, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)

#===============================================================================
# END OF SCRIPT
#===============================================================================
