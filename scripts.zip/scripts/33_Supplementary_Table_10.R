#===============================================================================
# Supplementary Table 10: Effects of electricity generation on consumption
#
# Description:
# This script estimates Equation (8) with four different lag specifications for
# both RRPV and RRPV-BS adopters, corresponding to Columns (1)-(8). The model
# examines how current and lagged PV generation affects household electricity
# consumption, controlling for weather and temporal fixed effects.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(fixest)
library(officer)
library(flextable)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root   <- "D:/rooftop"
path_data   <- file.path(path_root, "electricity")
path_models <- file.path(path_root, "models")
path_output <- file.path(path_root, "tables")

#-------------------------------------------------------------------------------
# 2. LOAD AND PREPARE DATA
#-------------------------------------------------------------------------------

data_elec_rrpv    <- readRDS(file.path(path_data, "rrpv_electricity_panel.RDS"))
data_elec_rrpv_bs <- readRDS(file.path(path_data, "rrpv_bs_electricity_panel.RDS"))

# Function to prepare lagged variables
prepare_data <- function(df) {
  df %>%
    arrange(household_id, date) %>%
    group_by(household_id) %>%
    mutate(
      EG_lag1 = lag(total_generation_kwh, 1),
      EG_lag2 = lag(total_generation_kwh, 2),
      EG_lag3 = lag(total_generation_kwh, 3)
    ) %>%
    ungroup()
}

data_rrpv_prepared    <- prepare_data(data_elec_rrpv)
data_rrpv_bs_prepared <- prepare_data(data_elec_rrpv_bs)

#-------------------------------------------------------------------------------
# 3. ESTIMATE MODELS (COLUMNS 1-8)
#-------------------------------------------------------------------------------

estimate_lag_model <- function(df, n_lags, model_name) {
  
  # Construct formula based on number of lags
  base_formula <- "total_consumption_kwh ~ total_generation_kwh"
  
  if (n_lags >= 1) base_formula <- paste(base_formula, "+ EG_lag1")
  if (n_lags >= 2) base_formula <- paste(base_formula, "+ EG_lag2")
  if (n_lags >= 3) base_formula <- paste(base_formula, "+ EG_lag3")
  
  # Add controls and fixed effects
  full_formula <- paste(
    base_formula,
    "+ temp_avg_celsius + temp_avg_celsius_sq + is_holiday + is_weekend",
    "| household_id^year + year^month"
  )
  
  model <- feols(
    as.formula(full_formula),
    data = df,
    cluster = ~household_id
  )
  
  saveRDS(model, file.path(path_models, model_name))
  return(model)
}

models_rrpv <- list(
  col1 = estimate_lag_model(data_rrpv_prepared, 0, "supp_table10_rrpv_lag0.RDS"),
  col2 = estimate_lag_model(data_rrpv_prepared, 1, "supp_table10_rrpv_lag1.RDS"),
  col3 = estimate_lag_model(data_rrpv_prepared, 2, "supp_table10_rrpv_lag2.RDS"),
  col4 = estimate_lag_model(data_rrpv_prepared, 3, "supp_table10_rrpv_lag3.RDS")
)

models_rrpv_bs <- list(
  col5 = estimate_lag_model(data_rrpv_bs_prepared, 0, "supp_table10_rrpv_bs_lag0.RDS"),
  col6 = estimate_lag_model(data_rrpv_bs_prepared, 1, "supp_table10_rrpv_bs_lag1.RDS"),
  col7 = estimate_lag_model(data_rrpv_bs_prepared, 2, "supp_table10_rrpv_bs_lag2.RDS"),
  col8 = estimate_lag_model(data_rrpv_bs_prepared, 3, "supp_table10_rrpv_bs_lag3.RDS")
)

models_all <- c(models_rrpv, models_rrpv_bs)

#-------------------------------------------------------------------------------
# 4. CALCULATE TOTAL EFFECT AND EXTRACT COEFFICIENTS
#-------------------------------------------------------------------------------

# Function to calculate total effect with SE
get_total_effect_stats <- function(model) {
  coef_tbl <- summary(model)$coefficients
  vcov_mat <- vcov(model, cluster = "household_id")
  all_gen_vars <- c("total_generation_kwh", "EG_lag1", "EG_lag2", "EG_lag3")
  vars_present <- intersect(all_gen_vars, rownames(coef_tbl))
  
  if (length(vars_present) == 0) return(c(NA, NA, NA))
  
  # Calculate Total Effect (Sum of coefficients)
  total_est <- sum(coef_tbl[vars_present, "Estimate"])
  
  # Calculate SE of Total Effect
  if (length(vars_present) > 1) {
    V_sub <- vcov_mat[vars_present, vars_present, drop = FALSE]
    total_se <- sqrt(sum(V_sub))
  } else {
    total_se <- coef_tbl[vars_present, "Std. Error"]
  }
  
  t_stat <- total_est / total_se
  df <- model$nobs - length(coef(model))
  pval <- 2 * pt(abs(t_stat), df, lower.tail = FALSE)
  
  return(c(total_est, total_se, pval))
}

# Function to extract individual coefficients
get_coef_stats <- function(model, varname) {
  coef_tbl <- summary(model)$coefficients
  if (!varname %in% rownames(coef_tbl)) return(c(NA, NA, NA))
  
  est  <- coef_tbl[varname, "Estimate"]
  se   <- coef_tbl[varname, "Std. Error"]
  pval <- coef_tbl[varname, "Pr(>|t|)"]
  
  return(c(est, se, pval))
}

# Formatting function
format_cell <- function(est, se, pval) {
  if (is.na(est)) return(c("", ""))
  
  stars <- case_when(
    pval < 0.01 ~ "***",
    pval < 0.05 ~ "**",
    pval < 0.10 ~ "*",
    TRUE ~ ""
  )
  
  c(sprintf("%.3f%s", est, stars), sprintf("(%.3f)", se))
}

#-------------------------------------------------------------------------------
# 5. BUILD TABLE DATA FRAME
#-------------------------------------------------------------------------------

tbl_data <- tibble(Variable = character())

# Row 1: Total Effect
coef_row <- c("Total effect", rep("", 8))
se_row   <- c("", rep("", 8))

for (i in 1:8) {
  stats <- get_total_effect_stats(models_all[[i]])
  formatted <- format_cell(stats[1], stats[2], stats[3])
  coef_row[i + 1] <- formatted[1]
  se_row[i + 1]   <- formatted[2]
}

tbl_data <- tbl_data %>%
  bind_rows(tibble(
    Variable = coef_row[1], `(1)` = coef_row[2], `(2)` = coef_row[3],
    `(3)` = coef_row[4], `(4)` = coef_row[5], `(5)` = coef_row[6],
    `(6)` = coef_row[7], `(7)` = coef_row[8], `(8)` = coef_row[9]
  )) %>%
  bind_rows(tibble(
    Variable = se_row[1], `(1)` = se_row[2], `(2)` = se_row[3],
    `(3)` = se_row[4], `(4)` = se_row[5], `(5)` = se_row[6],
    `(6)` = se_row[7], `(7)` = se_row[8], `(8)` = se_row[9]
  ))

# Rows 2-5: Individual Lag Coefficients
var_map <- list(
  list(label = "EGid",    var = "total_generation_kwh"),
  list(label = "EGi,d-1", var = "EG_lag1"),
  list(label = "EGi,d-2", var = "EG_lag2"),
  list(label = "EGi,d-3", var = "EG_lag3")
)

for (v in var_map) {
  coef_row <- c(v$label, rep("", 8))
  se_row   <- c("", rep("", 8))
  
  for (i in 1:8) {
    stats <- get_coef_stats(models_all[[i]], v$var)
    formatted <- format_cell(stats[1], stats[2], stats[3])
    coef_row[i + 1] <- formatted[1]
    se_row[i + 1]   <- formatted[2]
  }
  
  tbl_data <- tbl_data %>%
    bind_rows(tibble(
      Variable = coef_row[1], `(1)` = coef_row[2], `(2)` = coef_row[3],
      `(3)` = coef_row[4], `(4)` = coef_row[5], `(5)` = coef_row[6],
      `(6)` = coef_row[7], `(7)` = coef_row[8], `(8)` = coef_row[9]
    )) %>%
    bind_rows(tibble(
      Variable = se_row[1], `(1)` = se_row[2], `(2)` = se_row[3],
      `(3)` = se_row[4], `(4)` = se_row[5], `(5)` = se_row[6],
      `(6)` = se_row[7], `(7)` = se_row[8], `(8)` = se_row[9]
    ))
}

# Bottom Rows: Obs and Controls
tbl_data <- tbl_data %>%
  bind_rows(tibble(
    Variable = "Obs.",
    `(1)` = format(nobs(models_all[[1]]), big.mark = ","),
    `(2)` = format(nobs(models_all[[2]]), big.mark = ","),
    `(3)` = format(nobs(models_all[[3]]), big.mark = ","),
    `(4)` = format(nobs(models_all[[4]]), big.mark = ","),
    `(5)` = format(nobs(models_all[[5]]), big.mark = ","),
    `(6)` = format(nobs(models_all[[6]]), big.mark = ","),
    `(7)` = format(nobs(models_all[[7]]), big.mark = ","),
    `(8)` = format(nobs(models_all[[8]]), big.mark = ",")
  )) %>%
  bind_rows(tibble(
    Variable = "Control variables",
    `(1)` = "✓", `(2)` = "✓", `(3)` = "✓", `(4)` = "✓",
    `(5)` = "✓", `(6)` = "✓", `(7)` = "✓", `(8)` = "✓"
  )) %>%
  bind_rows(tibble(
    Variable = "Household-Year FE",
    `(1)` = "✓", `(2)` = "✓", `(3)` = "✓", `(4)` = "✓",
    `(5)` = "✓", `(6)` = "✓", `(7)` = "✓", `(8)` = "✓"
  )) %>%
  bind_rows(tibble(
    Variable = "Year-Month FE",
    `(1)` = "✓", `(2)` = "✓", `(3)` = "✓", `(4)` = "✓",
    `(5)` = "✓", `(6)` = "✓", `(7)` = "✓", `(8)` = "✓"
  ))

#-------------------------------------------------------------------------------
# 6. CREATE AND FORMAT FLEXTABLE
#-------------------------------------------------------------------------------

ft <- flextable(tbl_data) %>%
  set_header_labels(
    Variable = "Variables",
    `(1)` = "(1)", `(2)` = "(2)", `(3)` = "(3)", `(4)` = "(4)",
    `(5)` = "(5)", `(6)` = "(6)", `(7)` = "(7)", `(8)` = "(8)"
  ) %>%
  add_header_row(
    values = c("", "RRPV-only adopters", "RRPV-BS adopters"),
    colwidths = c(1, 4, 4)
  ) %>%
  width(j = 1, width = 2.0) %>%
  width(j = 2:9, width = 0.9) %>%
  align(j = 2:9, align = "center", part = "all") %>%
  align(j = 1, align = "left", part = "body") %>%
  bold(part = "header") %>%
  padding(i = which(tbl_data$Variable == ""), j = 1, padding.left = 20) %>%
  hline_top(border = fp_border(width = 2), part = "header") %>%
  hline(i = 1, border = fp_border(width = 1), part = "header") %>%
  hline_bottom(border = fp_border(width = 2), part = "header") %>%
  hline(i = nrow(tbl_data) - 3, border = fp_border(width = 1)) %>%
  hline_bottom(border = fp_border(width = 2), part = "body") %>%
  fontsize(size = 10, part = "all") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  set_caption(
    caption = as_paragraph(
      as_b("Supplementary Table 10. "),
      "The effects of electricity generation on consumption"
    ),
    align_with_table = FALSE
  )

#-------------------------------------------------------------------------------
# 7. EXPORT TO WORD
#-------------------------------------------------------------------------------

doc <- read_docx() %>%
  body_add_flextable(value = ft) %>%
  body_end_section_landscape()

output_file <- file.path(path_output, "Supplementary_Table_10.docx")
print(doc, target = output_file)

#===============================================================================
# END OF SCRIPT
#===============================================================================
