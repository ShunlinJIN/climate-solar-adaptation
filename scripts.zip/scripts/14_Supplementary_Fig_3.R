#===============================================================================
# Supplementary Fig. 3: Electricity generation and grid exchange patterns of average RRPV adopter
#
# Description:
# This script visualizes the electricity generation and grid exchange patterns
# for an average RRPV adopter.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(dplyr)
library(ggplot2)
library(zoo)
library(scales)
library(ggprism)
library(readr)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root  <- "D:/rooftop"
path_data  <- file.path(path_root, "electricity")
output_dir <- file.path(path_root, "Fig")

rrpv_data <- readRDS(file.path(path_data, "rrpv_electricity_panel.RDS"))

#-------------------------------------------------------------------------------
# 2. PREPARE DATA FOR PLOTTING
#-------------------------------------------------------------------------------
# Calculate daily averages across all households
daily_avg <- rrpv_data %>%
  group_by(time) %>%
  summarise(
    EG_mean         = mean(total_generation_kwh,   na.rm = TRUE),
    SelfUse_mean    = mean(self_consumption_kwh,   na.rm = TRUE),
    GridImport_mean = mean(grid_import_kwh,        na.rm = TRUE),
    GridExport_mean = mean(grid_export_kwh,        na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(time)

# Calculate 7-day rolling averages for smoother lines
k <- 7
daily_avg <- daily_avg %>%
  mutate(
    EG_smooth         = rollmean(EG_mean,         k = k, fill = NA, align = "right"),
    SelfUse_smooth    = rollmean(SelfUse_mean,    k = k, fill = NA, align = "right"),
    GridImport_smooth = rollmean(GridImport_mean, k = k, fill = NA, align = "right"),
    GridExport_smooth = rollmean(GridExport_mean, k = k, fill = NA, align = "right")
  )

#-------------------------------------------------------------------------------
# 3. DEFINE PLOTTING THEME AND COLORS
#-------------------------------------------------------------------------------

theme_clean_pub <- theme(
  panel.background = element_rect(fill = "white", colour = NA),
  plot.background  = element_rect(fill = "white", colour = NA),
  panel.grid.major = element_blank(),
  panel.grid.minor = element_blank(),
  axis.line        = element_line(colour = "black", linewidth = 0.4),
  axis.ticks       = element_line(colour = "black", linewidth = 0.4),
  axis.text        = element_text(color = "black", size = 10),
  axis.title       = element_text(color = "black", size = 11),
  legend.position  = "top",
  legend.title     = element_blank(),
  legend.text      = element_text(size = 10),
  plot.margin      = margin(6, 12, 6, 6)
)

col_line <- c(
  "PV generation"                = "#1f77b4", 
  "Self-consumed PV electricity" = "#E69F00", 
  "Grid-imported electricity"    = "#009E73"
)

fill_ribbon <- c(
  "Grid-exported electricity" = "#D55E00"  
)

#-------------------------------------------------------------------------------
# 4. CREATE AND SAVE THE PLOT
#-------------------------------------------------------------------------------

plot_supp_fig3 <-
  ggplot(daily_avg, aes(x = time)) +
  
  # Shaded area: Grid-exported electricity
  geom_ribbon(
    aes(
      ymin = SelfUse_smooth,
      ymax = EG_smooth,
      fill = "Grid-exported electricity"
    ),
    alpha = 0.18,
    color = NA,
    show.legend = TRUE
  ) +
  
  # Background lines: raw daily data (thin and light)
  geom_line(
    aes(y = EG_mean,         color = "PV generation"),
    linewidth = 0.35,
    alpha = 0.35
  ) +
  geom_line(
    aes(y = SelfUse_mean,    color = "Self-consumed PV electricity"),
    linewidth = 0.35,
    alpha = 0.35
  ) +
  geom_line(
    aes(y = GridImport_mean, color = "Grid-imported electricity"),
    linewidth = 0.35,
    alpha = 0.35,
    linetype = "dashed"
  ) +
  
  # Foreground lines: 7-day rolling averages (bold)
  geom_line(
    aes(y = EG_smooth,         color = "PV generation"),
    linewidth = 0.9
  ) +
  geom_line(
    aes(y = SelfUse_smooth,    color = "Self-consumed PV electricity"),
    linewidth = 0.9
  ) +
  geom_line(
    aes(y = GridImport_smooth, color = "Grid-imported electricity"),
    linewidth = 0.9,
    linetype = "dashed"
  ) +
  
  scale_color_manual(values = col_line) +
  scale_fill_manual(values = fill_ribbon) +
  scale_x_date(
    breaks = pretty_breaks(n = 8),
    labels = function(x) format(x, "%Y-%m")
  ) +
  labs(
    x = "Date",
    y = "Average Per Household Per Day (kWh)"
  ) +
  theme_clean_pub +
  guides(
    fill  = guide_legend(
      order = 1,
      override.aes = list(alpha = 0.25)
    ),
    color = guide_legend(
      order = 2,
      override.aes = list(
        linewidth = 1.0,
        linetype  = c(2, 1, 1)
      )
    )
  )

# PDF
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_3.pdf"),
  plot = plot_supp_fig3,
  width = 8.4, height = 4.8, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_3.png"),
  plot = plot_supp_fig3,
  width = 8.4, height = 4.8, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)


#===============================================================================
# END OF SCRIPT
#===============================================================================
