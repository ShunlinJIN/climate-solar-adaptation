#===============================================================================
# Supplementary Table 6: Sources of funding for RRPV installation in the survey
#
# Description:
# This script creates a table comparing funding sources for RRPV installation
# between high-income and low-income households. Funding sources include
# out-of-pocket payment, loans, financial assistance, roof rental, and others.
# High-income households are defined as the top income quintile (Q5), and
# low-income households as the bottom quintile (Q1).
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(gt)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root  <- "D:/rooftop"
path_data  <- file.path(path_root, "survey")
output_dir <- file.path(path_root, "tables")

#-------------------------------------------------------------------------------
# 2. LOAD SURVEY DATA
#-------------------------------------------------------------------------------

survey_data <- readRDS(file.path(path_data, "survey_panel_data.RDS"))

#-------------------------------------------------------------------------------
# 3. AGGREGATE TO HOUSEHOLD LEVEL AND CLASSIFY INCOME GROUPS
#-------------------------------------------------------------------------------

household_level <- survey_data %>%
  group_by(household_id) %>%
  summarise(
    rrpv_adopter = max(if_else(treated == 1 & !is.na(pv_capacity_kW), 1, 0), na.rm = TRUE),
    per_capita_income = mean(Monthly_Per_Capita_Household_Income, na.rm = TRUE),
    funding_source = first(funding_source),
    .groups = "drop"
  )

# Create income quintiles
household_level <- household_level %>%
  mutate(
    income_quintile = cut(
      per_capita_income,
      breaks = quantile(per_capita_income, probs = seq(0, 1, 0.2), na.rm = TRUE),
      labels = 1:5,
      include.lowest = TRUE
    )
  )

#-------------------------------------------------------------------------------
# 4. FILTER ADOPTERS AND CLASSIFY AS HIGH/LOW INCOME
#-------------------------------------------------------------------------------

adopters_funding <- household_level %>%
  filter(rrpv_adopter == 1) %>%
  mutate(
    income_group = case_when(
      income_quintile == 1 ~ "Low-income",
      income_quintile == 5 ~ "High-income",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(income_group))

#-------------------------------------------------------------------------------
# 5. CALCULATE FUNDING SOURCE DISTRIBUTION BY INCOME GROUP
#-------------------------------------------------------------------------------

table6_data <- adopters_funding %>%
  group_by(income_group, funding_source) %>%
  summarise(n = n(), .groups = "drop") %>%
  group_by(income_group) %>%
  mutate(Share = n / sum(n) * 100) %>%
  select(-n) %>%
  pivot_wider(
    names_from = income_group,
    values_from = Share,
    values_fill = 0
  ) %>%
  rename(Sources = funding_source)

table6_data <- table6_data %>%
  select(Sources, `High-income households` = `High-income`, `Low-income households` = `Low-income`)

table6_data <- table6_data %>%
  add_row(
    Sources = "Total",
    `High-income households` = 100,
    `Low-income households` = 100
  )

#-------------------------------------------------------------------------------
# 6. FORMAT TABLE WITH GT
#-------------------------------------------------------------------------------

gt_table6 <- table6_data %>%
  gt() %>%
  fmt_number(
    columns = c(`High-income households`, `Low-income households`),
    decimals = 1,
    pattern = "{x}%"
  ) %>%
  cols_label(
    Sources = "Sources",
    `High-income households` = "High-income households",
    `Low-income households` = "Low-income households"
  ) %>%
  tab_style(
    style = list(
      cell_text(weight = "bold"),
      cell_fill(color = "#f7f7f7")
    ),
    locations = cells_body(
      rows = Sources == "Total"
    )
  ) %>%
  tab_style(
    style = cell_text(indent = px(20)),
    locations = cells_body(
      rows = str_starts(Sources, "from ")
    )
  ) %>%
  tab_header(
    title = md("**Supplementary Table 6:** Sources of funding for RRPV installation in the survey")
  ) %>%
  tab_options(
    table.font.size = px(12),
    heading.title.font.size = px(14),
    column_labels.font.weight = "bold",
    table.border.top.style = "solid",
    table.border.top.width = px(2),
    table.border.top.color = "black",
    table.border.bottom.style = "solid",
    table.border.bottom.width = px(2),
    table.border.bottom.color = "black",
    column_labels.border.bottom.style = "solid",
    column_labels.border.bottom.width = px(2),
    column_labels.border.bottom.color = "black",
    data_row.padding = px(4)
  ) %>%
  opt_horizontal_padding(scale = 2)

print(gt_table6)

#-------------------------------------------------------------------------------
# 7. SAVE OUTPUTS
#-------------------------------------------------------------------------------

gtsave(gt_table6, filename = file.path(output_dir, "Supplementary_Table_6.docx"))

write_csv(
  table6_data,
  file.path(output_dir, "Supplementary_Table_6_data.csv")
)

saveRDS(
  table6_data,
  file.path(output_dir, "supp_table_6_data.RDS")
)

#===============================================================================
# END OF SCRIPT
#===============================================================================
