#===============================================================================
# Supplementary Table 9: CMIP6 global climate models
#
# Description:
# This script generates a formatted table listing the 31 CMIP6 models used in
# future climate projections and exports to Word document.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(officer)
library(flextable)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root   <- "D:/rooftop"
path_output <- file.path(path_root, "tables")

#-------------------------------------------------------------------------------
# 2. CREATE MODEL LIST
#-------------------------------------------------------------------------------

cmip6_models <- tribble(
  ~No_1, ~Model_1,           ~No_2, ~Model_2,           ~No_3, ~Model_3,
  1,     "EC-Earth3",        12,    "NESM3",            23,    "KACE-1-0-G",
  2,     "FGOALS-f3-L",      13,    "CIESM",            24,    "TaiESM1",
  3,     "AWI-CM-1-1-MR",    14,    "EC-Earth3-Veg-LR", 25,    "MPI-ESM1-2-HR",
  4,     "BCC-CSM2-MR",      15,    "IPSL-CM6A-LR",     26,    "MPI-ESM1-2-LR",
  5,     "FGOALS-g3",        16,    "CAMS-CSM1-0",      27,    "MRI-ESM2-0",
  6,     "CAS-ESM2-0",       17,    "FIO-ESM-2-0",      28,    "ACCESS-CM2",
  7,     "CESM2-WACCM",      18,    "GFDL-ESM4",        29,    "NorESM2-LM",
  8,     "ITM-ESM",          19,    "EC-Earth3-Veg",    30,    "NorESM2-MM",
  9,     "INM-CM4-8",        20,    "CMCC-CM2-SR5",     31,    "MIROC6",
  10,    "CMCC-ESM2",        21,    "INM-CM5-0",        NA,    NA,
  11,    "CanESM5",          22,    "ACCESS-ESM1-5",    NA,    NA
)

#-------------------------------------------------------------------------------
# 3. CREATE FLEXTABLE
#-------------------------------------------------------------------------------

ft <- flextable(cmip6_models) %>%
  set_header_labels(
    No_1 = "No.", Model_1 = "Climate model",
    No_2 = "No.", Model_2 = "Climate model",
    No_3 = "No.", Model_3 = "Climate model"
  ) %>%
  width(j = c(1, 3, 5), width = 0.5) %>%
  width(j = c(2, 4, 6), width = 1.8) %>%
  align(j = c(1, 3, 5), align = "center", part = "all") %>%
  align(j = c(2, 4, 6), align = "left", part = "all") %>%
  bold(part = "header") %>%
  hline_top(border = fp_border(width = 2), part = "header") %>%
  hline_bottom(border = fp_border(width = 2), part = "header") %>%
  hline_bottom(border = fp_border(width = 2), part = "body") %>%
  fontsize(size = 10, part = "all") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  set_caption(
    caption = as_paragraph(
      as_b("Supplementary Table 9. "),
      "31 CMIP6 global climate models"
    ),
    align_with_table = FALSE
  )

#-------------------------------------------------------------------------------
# 4. EXPORT TO WORD
#-------------------------------------------------------------------------------

doc <- read_docx() %>%
  body_add_flextable(value = ft)

output_path <- file.path(path_output, "Supplementary_Table_9.docx")
print(doc, target = output_path)

#===============================================================================
# END OF SCRIPT
#===============================================================================
