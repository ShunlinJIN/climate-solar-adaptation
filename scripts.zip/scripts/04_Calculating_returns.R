#===============================================================================
# Economic Returns Calculation Script
#
# Description:
#   This script calculates household-level economic returns for adopters of
#   RRPV and RRPV-BS systems under Net Billing, following the methodology and
#   equations described in the main text (Eqs. 9–20).
#
# Methodology:
#   - Construct climatological PV potential from bias-corrected CMIP6 (Eq. 9–12)
#   - Derive climate adjustment factors from observed weather and CMIP6 (Eq. 13)
#   - Estimate household-specific nominal generation profiles (Eq. 14–15)
#   - Simulate future PV generation under SSP2 climate (Eq. 16–17)
#   - Compute daily and annual economic returns (Eq. 18)
#   - Calculate net present value and equivalent annual annuity (Eq. 19–20)
#
# Key Economic Metrics:
#   - annual_gross_per_kwp     : Annual gross return per kWp ($/kWp/year)
#   - annual_net_per_kwp       : Annual net return per kWp ($/kWp/year)
#   - NPV                      : Net Present Value (NPV, $) - Eq. 19
#   - EAA                      : Equivalent Annual Annuity (EAA, $/year) - Eq. 20
#   - self_sufficiency_rate    : Self-sufficiency rate (% of demand met by PV)
#
#===============================================================================

library(tidyverse)
library(lubridate)

# --- Paths ---
path_root   <- "D:/rooftop"
path_return <- file.path(path_root, "return")
path_models <- file.path(path_root, "models")
path_output <- file.path(path_return, "results")

#-------------------------------------------------------------------------------
# 1. LOAD DATA
#-------------------------------------------------------------------------------

data_rrpv_obs    <- readRDS(file.path(path_root, "electricity/rrpv_electricity_panel.RDS"))
data_rrpv_bs_obs <- readRDS(file.path(path_root, "electricity/rrpv_bs_electricity_panel.RDS"))

weather_observed <- readRDS(file.path(path_root, "weather_daily_county.RDS"))

cmip6_historical <- readRDS(file.path(path_return, "cmip6_historical_climate.RDS"))
cmip6_future     <- readRDS(file.path(path_return, "cmip6_future_climate.RDS"))

cost_data      <- read_csv(file.path(path_return, "household_costs.csv"))
tiered_pricing <- read_csv(file.path(path_return, "tiered_pricing_by_county.csv"))

#-------------------------------------------------------------------------------
# 2. COUNTY TEMPERATURE ZONES (for heterogeneity analysis)
#-------------------------------------------------------------------------------

county_avg_temp <- weather_observed %>%
  mutate(
    county_id = as.character(county_code),
    date      = as.Date(date),
    year      = year(date)
  ) %>%
  filter(year >= 1981 & year <= 2010) %>%
  group_by(county_id) %>%
  summarise(
    avg_temp_30yr = mean(temp_avg_daily_c, na.rm = TRUE),
    .groups = "drop"
  )

temp_thresholds <- quantile(
  county_avg_temp$avg_temp_30yr,
  probs = c(0.40, 0.70),
  na.rm = TRUE
)

county_temp_zones <- county_avg_temp %>%
  mutate(
    temp_zone = case_when(
      avg_temp_30yr >= temp_thresholds[2] ~ "Hot",
      avg_temp_30yr >= temp_thresholds[1] ~ "Mild",
      TRUE                                ~ "Cool"
    ),
    temp_zone = factor(temp_zone, levels = c("Cool", "Mild", "Hot"))
  ) %>%
  select(county_id, avg_temp_30yr, temp_zone)

saveRDS(county_temp_zones, file.path(path_output, "county_temperature_zones.RDS"))

#-------------------------------------------------------------------------------
# 3. CLIMATOLOGICAL MEAN PV POTENTIAL (Eqs. 9–12)
#
# Eq. 9:  PV_POT,c,t = PR_c,t × (I_c,t / I_STC)
# Eq. 10: PR_c,t     = 1 - γ (T_cell,c,t - T_STC)
# Eq. 11: T_cell,c,t = a1 + a2 I_c,t + a3 T_c,t - a4 ν_c,t
# Eq. 12: PVM_c(d)   = (1/N_c,d) Σ_{y∈φ} PV_POT,c,y,d, φ = {1981,…,2010}
#-------------------------------------------------------------------------------

I_STC <- 1000   # Reference irradiance under STC (W/m²)
T_STC <- 25     # Reference temperature under STC (°C)
gamma <- 0.005  # Temperature coefficient of module efficiency (1/°C)

# Coefficients in empirical cell temperature relationship (Feron et al. 2021)
a1 <- 4.3   # Baseline temperature
a2 <- 0.943 # Irradiance heating coefficient
a3 <- 0.028 # Air-to-module temperature coefficient
a4 <- 1.528 # Convective cooling coefficient (wind)

cmip6_historical <- cmip6_historical %>%
  mutate(
    # Eq. 11: Cell temperature under field conditions
    T_cell      = a1 + a2 * I_t + a3 * T_t - a4 * v_t,
    # Eq. 10: Performance ratio
    PR_t        = pmax(0, 1 - gamma * (T_cell - T_STC)),
    # Eq. 9: Potential PV output (normalized to 1 kW under STC)
    PV_POT      = PR_t * (I_t / I_STC),
    day_of_year = yday(time)
  )

# Eq. 12: Climatological mean PV potential PVM_c(d)
PV_M <- cmip6_historical %>%
  filter(year(time) >= 1981 & year(time) <= 2010) %>%
  group_by(county_id, day_of_year) %>%
  summarise(PV_M_d = mean(PV_POT, na.rm = TRUE), .groups = "drop")

saveRDS(PV_M, file.path(path_output, "climatological_pv_potential.RDS"))

#-------------------------------------------------------------------------------
# 4. CLIMATE ADJUSTMENT FACTORS FROM OBSERVED WEATHER (Eq. 13)
#
# Eq. 13: F_c,t = PV_POT,c,t / PVM_c(d(t))
#-------------------------------------------------------------------------------

weather_obs_2018_2020 <- weather_observed %>%
  mutate(
    county_id = as.character(county_code),
    date      = as.Date(date)
  ) %>%
  filter(date >= as.Date("2018-06-01") & date <= as.Date("2020-12-31")) %>%
  select(
    county_id,
    date,
    I_obs = solar_radiation_wm2,
    T_obs = temp_avg_daily_c,
    v_obs = wind_speed_ms
  ) %>%
  mutate(
    T_cell_obs  = a1 + a2 * I_obs + a3 * T_obs - a4 * v_obs,
    PR_t_obs    = pmax(0, 1 - gamma * (T_cell_obs - T_STC)),
    PV_POT_obs  = PR_t_obs * (I_obs / I_STC),
    day_of_year = yday(date)
  ) %>%
  left_join(PV_M, by = c("county_id", "day_of_year")) %>%
  mutate(
    # Eq. 13: Climate adjustment factor
    F_ct = PV_POT_obs / pmax(PV_M_d, 0.001)
  )

saveRDS(weather_obs_2018_2020, file.path(path_output, "climate_adjustment_obs.RDS"))

#-------------------------------------------------------------------------------
# 5. NOMINAL GENERATION PATTERNS (Eqs. 14–15)
#
# Eq. 14: ĝ_i,t = e_i,t / (K_i × F_{c(i),t})
# Eq. 15: Nom_i(d) = (1/N_i,d) Σ_{t∈D_i(d)} ĝ_i,t
#-------------------------------------------------------------------------------

# RRPV
data_rrpv_with_F <- data_rrpv_obs %>%
  left_join(
    weather_obs_2018_2020 %>% select(county_id, date, F_ct),
    by = c("county_id", "time" = "date")
  ) %>%
  mutate(
    # Eq. 14: weather-normalized generation intensity per kW
    g_hat     = total_generation_kwh / pmax(install_capacity_kwp * F_ct, 0.001),
    day_of_year = yday(time)
  )

Nom_h_rrpv <- data_rrpv_with_F %>%
  group_by(household_id, day_of_year) %>%
  summarise(
    Nom_h_d = mean(g_hat, na.rm = TRUE),
    .groups = "drop"
  )

# RRPV-BS
data_rrpv_bs_with_F <- data_rrpv_bs_obs %>%
  left_join(
    weather_obs_2018_2020 %>% select(county_id, date, F_ct),
    by = c("county_id", "time" = "date")
  ) %>%
  mutate(
    g_hat      = total_generation_kwh / pmax(install_capacity_kwp * F_ct, 0.001),
    day_of_year = yday(time)
  )

Nom_h_rrpv_bs <- data_rrpv_bs_with_F %>%
  group_by(household_id, day_of_year) %>%
  summarise(
    Nom_h_d = mean(g_hat, na.rm = TRUE),
    .groups = "drop"
  )

saveRDS(Nom_h_rrpv,    file.path(path_output, "nominal_generation_rrpv.RDS"))
saveRDS(Nom_h_rrpv_bs, file.path(path_output, "nominal_generation_rrpv_bs.RDS"))

#-------------------------------------------------------------------------------
# 6. MONTHLY CONSUMPTION GROWTH RATES (for future E_self,t)
#-------------------------------------------------------------------------------

calculate_monthly_growth <- function(data_obs) {
  monthly_consumption <- data_obs %>%
    mutate(
      year  = year(time),
      month = month(time)
    ) %>%
    group_by(household_id, year, month) %>%
    summarise(
      monthly_total = sum(total_consumption_kwh, na.rm = TRUE),
      .groups = "drop"
    )
  
  growth_rates <- monthly_consumption %>%
    arrange(household_id, year, month) %>%
    group_by(household_id, month) %>%
    mutate(
      prev_year   = lag(monthly_total, 1),
      growth_rate = if_else(
        !is.na(prev_year) & prev_year > 0,
        pmax(0, (monthly_total - prev_year) / prev_year),
        0
      )
    ) %>%
    ungroup()
  
  avg_growth <- growth_rates %>%
    group_by(household_id, month) %>%
    summarise(
      avg_growth_rate = mean(growth_rate, na.rm = TRUE),
      .groups = "drop"
    )
  
  baseline_daily <- data_obs %>%
    mutate(month = month(time)) %>%
    group_by(household_id, month) %>%
    summarise(
      baseline_daily_kwh = mean(total_consumption_kwh, na.rm = TRUE),
      .groups = "drop"
    )
  
  left_join(baseline_daily, avg_growth, by = c("household_id", "month"))
}

consumption_growth_rrpv    <- calculate_monthly_growth(data_rrpv_obs)
consumption_growth_rrpv_bs <- calculate_monthly_growth(data_rrpv_bs_obs)

saveRDS(consumption_growth_rrpv,    file.path(path_output, "consumption_growth_rrpv.RDS"))
saveRDS(consumption_growth_rrpv_bs, file.path(path_output, "consumption_growth_rrpv_bs.RDS"))

#-------------------------------------------------------------------------------
# 7. FUTURE GENERATION UNDER CLIMATE CHANGE (Eqs. 16–17)
#
# Eq. 16: G_i,t^future = Nom_i(d(t)) × F_{c(i),t}^future
# Eq. 17: E_total,t    = K_i × G_i,t^future × (1 - δ)^(y(t) - y_0)
#-------------------------------------------------------------------------------

cmip6_future <- cmip6_future %>%
  mutate(
    T_cell        = c1 + c2 * I_t + c3 * T_t - c4 * v_t,
    PR_t          = pmax(0, 1 - gamma * (T_cell - T_STC)),
    PV_POT_future = PR_t * (I_t / I_STC),
    day_of_year   = yday(time)
  ) %>%
  left_join(PV_M, by = c("county_id", "day_of_year")) %>%
  mutate(
    # Eq. 13 with future climate
    F_ct_future = PV_POT_future / pmax(PV_M_d, 0.001)
  )

# Household characteristics
household_chars_rrpv <- data_rrpv_obs %>%
  group_by(household_id) %>%
  summarise(
    county_id            = first(county_id),
    install_capacity_kwp = first(install_capacity_kwp),
    .groups = "drop"
  ) %>%
  left_join(
    county_temp_zones %>% select(county_id, temp_zone),
    by = "county_id"
  ) %>%
  mutate(install_date = as.Date("2018-06-01"))

household_chars_rrpv_bs <- data_rrpv_bs_obs %>%
  group_by(household_id) %>%
  summarise(
    county_id            = first(county_id),
    install_capacity_kwp = first(install_capacity_kwp),
    battery_capacity_kwh = first(battery_capacity_kwh),
    .groups = "drop"
  ) %>%
  left_join(
    county_temp_zones %>% select(county_id, temp_zone),
    by = "county_id"
  ) %>%
  mutate(install_date = as.Date("2018-06-01"))

# RRPV future generation
future_gen_rrpv <- cmip6_future %>%
  left_join(household_chars_rrpv, by = "county_id") %>%
  filter(!is.na(household_id)) %>%
  left_join(Nom_h_rrpv, by = c("household_id", "day_of_year")) %>%
  mutate(
    year      = year(time),
    month     = month(time),
    y0        = year(install_date),
    delta     = 0.015,
    # Eq. 16: daily intensity per kW under future climate
    G_future  = Nom_h_d * F_ct_future,
    # Eq. 17: daily PV generation (kWh)
    E_total_t = install_capacity_kwp * G_future * (1 - delta)^pmax(year - y0, 0)
  )

# RRPV-BS future generation
future_gen_rrpv_bs <- cmip6_future %>%
  left_join(household_chars_rrpv_bs, by = "county_id") %>%
  filter(!is.na(household_id)) %>%
  left_join(Nom_h_rrpv_bs, by = c("household_id", "day_of_year")) %>%
  mutate(
    year      = year(time),
    month     = month(time),
    y0        = year(install_date),
    delta     = 0.015,
    G_future  = Nom_h_d * F_ct_future,
    E_total_t = install_capacity_kwp * G_future * (1 - delta)^pmax(year - y0, 0)
  )

saveRDS(future_gen_rrpv,    file.path(path_output, "future_generation_rrpv.RDS"))
saveRDS(future_gen_rrpv_bs, file.path(path_output, "future_generation_rrpv_bs.RDS"))

#-------------------------------------------------------------------------------
# 8. TEMPERATURE-DRIVEN DEMAND ADJUSTMENT (future E_self,t)
#-------------------------------------------------------------------------------

# Temperature response of total grid electricity use (non-adopters, Supplementary Fig. 14a)
model_temp_control <- readRDS(file.path(path_models, "supp_fig14a_model.RDS"))

temp_bins <- c(
  "temp_below_neg5", "temp_neg5_to_0", "temp_0_to_5", "temp_5_to_10",
  "temp_10_to_15", "temp_20_to_25", "temp_25_to_30", "temp_above_30"
)

beta_temp <- coef(model_temp_control)[temp_bins]

# Temperature bin assignment (consistent with Supplementary Fig. 14)
assign_temp_bin <- function(temp) {
  case_when(
    temp <= -5              ~ "temp_below_neg5",
    temp > -5 & temp <= 0   ~ "temp_neg5_to_0",
    temp > 0  & temp <= 5   ~ "temp_0_to_5",
    temp > 5  & temp <= 10  ~ "temp_5_to_10",
    temp > 10 & temp <= 15  ~ "temp_10_to_15",
    temp > 15 & temp <= 20  ~ "temp_15_to_20",
    temp > 20 & temp <= 25  ~ "temp_20_to_25",
    temp > 25 & temp <= 30  ~ "temp_25_to_30",
    temp > 30               ~ "temp_above_30",
    TRUE                    ~ NA_character_
  )
}

# Baseline monthly temperature distribution (2018–2020, observed weather)
temp_baseline <- weather_observed %>%
  mutate(
    county_id = as.character(county_code),
    date      = as.Date(date),
    year      = year(date),
    month     = month(date),
    temp_bin  = assign_temp_bin(temp_avg_daily_c)
  ) %>%
  filter(year >= 2018 & year <= 2020) %>%
  group_by(county_id, month, temp_bin) %>%
  summarise(days_in_bin = n(), .groups = "drop") %>%
  group_by(county_id, month) %>%
  mutate(
    days_total = sum(days_in_bin),
    share      = if_else(days_total > 0, days_in_bin / days_total, 0)
  ) %>%
  ungroup() %>%
  mutate(days_30 = share * 30) %>%
  select(county_id, month, temp_bin, days_30) %>%
  tidyr::pivot_wider(
    names_from  = temp_bin,
    values_from = days_30,
    values_fill = 0
  )

# Future monthly temperature distribution (CMIP6 SSP2 climate)
cmip6_temp_future_monthly <- cmip6_future %>%
  mutate(
    temp_bin = assign_temp_bin(T_t),
    year     = year(time),
    month    = month(time)
  ) %>%
  group_by(county_id, year, month, temp_bin) %>%
  summarise(days_in_bin = n(), .groups = "drop") %>%
  group_by(county_id, year, month) %>%
  mutate(
    days_total = sum(days_in_bin),
    share      = if_else(days_total > 0, days_in_bin / days_total, 0)
  ) %>%
  ungroup() %>%
  mutate(days_30 = share * 30) %>%
  select(county_id, year, month, temp_bin, days_30) %>%
  tidyr::pivot_wider(
    names_from  = temp_bin,
    values_from = days_30,
    values_fill = 0
  )

# Monthly climate adjustment factor for electricity demand
climate_factor_monthly <- cmip6_temp_future_monthly %>%
  left_join(
    temp_baseline,
    by = c("county_id", "month"),
    suffix = c("_future", "_base")
  ) %>%
  rowwise() %>%
  mutate(
    log_factor = sum(
      (c_across(all_of(paste0(temp_bins, "_future"))) -
         c_across(all_of(paste0(temp_bins, "_base")))) *
        beta_temp[temp_bins],
      na.rm = TRUE
    ),
    climate_factor = exp(log_factor)
  ) %>%
  ungroup() %>%
  mutate(
    climate_factor = pmin(pmax(climate_factor, 0.5), 2)
  ) %>%
  select(county_id, year, month, climate_factor)

#-------------------------------------------------------------------------------
# 9. PROJECT FUTURE CONSUMPTION (baseline 2020, climate-adjusted)
#-------------------------------------------------------------------------------

project_consumption <- function(future_gen, growth_data, climate_factor_monthly, baseline_year = 2020) {
  future_gen %>%
    left_join(growth_data, by = c("household_id", "month")) %>%
    left_join(climate_factor_monthly, by = c("county_id", "year", "month")) %>%
    mutate(
      climate_factor      = if_else(is.na(climate_factor), 1, climate_factor),
      years_since_baseline = year - baseline_year,
      # Socio-economic trend in daily consumption (baseline 2020)
      E_self_trend = baseline_daily_kwh *
        (1 + avg_growth_rate)^pmax(years_since_baseline, 0),
      # Climate-adjusted daily consumption demand E_self,t
      E_self_t = E_self_trend * climate_factor
    )
}

future_gen_rrpv    <- project_consumption(future_gen_rrpv,    consumption_growth_rrpv,    climate_factor_monthly)
future_gen_rrpv_bs <- project_consumption(future_gen_rrpv_bs, consumption_growth_rrpv_bs, climate_factor_monthly)

saveRDS(future_gen_rrpv,    file.path(path_output, "future_gen_consumption_rrpv.RDS"))
saveRDS(future_gen_rrpv_bs, file.path(path_output, "future_gen_consumption_rrpv_bs.RDS"))

#-------------------------------------------------------------------------------
# 10. DAILY RETURNS UNDER TIERED PRICING (Eq. 18)
#
# Eq. 18:
#   R_t =
#     E_total,t × P_grid,t                               if E_total,t ≤ E_self,t
#     E_self,t × P_grid,t + (E_total,t - E_self,t) × P_sell,t   if E_total,t > E_self,t
#
#-------------------------------------------------------------------------------

# Compute daily returns given future generation/consumption
compute_daily_returns <- function(future_gen, data_obs, tiered_pricing) {
  future_gen %>%
    left_join(tiered_pricing, by = "county_id") %>%
    # Average feed-in tariff (converted from CNY/kWh to USD/kWh)
    left_join(
      data_obs %>%
        group_by(household_id) %>%
        summarise(
          P_sell = mean(feedin_tariff_yuan_kwh, na.rm = TRUE) / 7,
          .groups = "drop"
        ),
      by = "household_id"
    ) %>%
    mutate(
      # Daily self-consumption and exports based on Eq. 18
      self_use_t    = pmin(E_total_t, E_self_t),
      export_t      = pmax(E_total_t - E_self_t, 0),
      grid_purchase = pmax(E_self_t - E_total_t, 0)
    ) %>%
    group_by(household_id, year) %>%
    # Annual cumulative grid purchases decide marginal tier
    mutate(cum_purchase = cumsum(grid_purchase)) %>%
    ungroup() %>%
    mutate(
      # Tiered retail electricity price P_grid,t
      P_grid = case_when(
        cum_purchase <= tier1_threshold_kwh ~ tier1_price_usd_kwh,
        cum_purchase <= tier2_threshold_kwh ~ tier2_price_usd_kwh,
        TRUE                                ~ tier3_price_usd_kwh
      ),
      # Eq. 18: avoided cost + export revenue
      self_use_value = self_use_t * P_grid,
      export_value   = export_t   * P_sell,
      R_t            = self_use_value + export_value
    )
}

future_returns_rrpv    <- compute_daily_returns(future_gen_rrpv,    data_rrpv_obs,    tiered_pricing)
future_returns_rrpv_bs <- compute_daily_returns(future_gen_rrpv_bs, data_rrpv_bs_obs, tiered_pricing)

saveRDS(future_returns_rrpv,    file.path(path_output, "future_returns_rrpv.RDS"))
saveRDS(future_returns_rrpv_bs, file.path(path_output, "future_returns_rrpv_bs.RDS"))

#-------------------------------------------------------------------------------
# 11. NPV AND EAA (Eqs. 19–20)
#
# Eq. 19: NPV_i = [ Σ_{y=1}^{LT} (R_y - M_y) / (1 + r)^y ] - C_install
# Eq. 20: EAA   = NPV × r / [1 - (1 + r)^(-LT)]
#-------------------------------------------------------------------------------

r  <- 0.05  # Discount rate
LT <- 25    # System lifetime (years)

#---------------- RRPV ----------------

annual_rrpv <- future_returns_rrpv %>%
  group_by(household_id, year) %>%
  summarise(
    R_y               = sum(R_t,            na.rm = TRUE),
    sales_y           = sum(export_value,   na.rm = TRUE),
    savings_y         = sum(self_use_value, na.rm = TRUE),
    total_self_use    = sum(self_use_t,     na.rm = TRUE),
    total_consumption = sum(E_self_t,       na.rm = TRUE),
    .groups = "drop"
  ) %>%
  left_join(
    cost_data %>% select(household_id, upfront_cost_usd, annual_om_cost_usd),
    by = "household_id"
  ) %>%
  mutate(
    net_return_y = R_y - annual_om_cost_usd,          # R_y - M_y
    y_relative   = year - min(year) + 1               # y = 1,…,LT
  ) %>%
  filter(y_relative <= LT)

npv_rrpv <- annual_rrpv %>%
  group_by(household_id) %>%
  summarise(
    total_discounted_gross   = sum(R_y          / (1 + r)^y_relative),
    total_discounted_sales   = sum(sales_y      / (1 + r)^y_relative),
    total_discounted_savings = sum(savings_y    / (1 + r)^y_relative),
    total_discounted_net     = sum(net_return_y / (1 + r)^y_relative),
    total_self_use           = sum(total_self_use),
    total_consumption        = sum(total_consumption),
    upfront_cost_usd         = first(upfront_cost_usd),
    .groups = "drop"
  ) %>%
  mutate(
    # Eq. 19: Net present value
    NPV = total_discounted_net - upfront_cost_usd
  ) %>%
  left_join(
    household_chars_rrpv %>% select(household_id, install_capacity_kwp, temp_zone),
    by = "household_id"
  ) %>%
  mutate(
    # Key economic metrics
    annual_gross_per_kwp  = total_discounted_gross / (LT * install_capacity_kwp),
    annual_net_per_kwp    = (NPV / LT) / install_capacity_kwp,
    self_sufficiency_rate = total_self_use / total_consumption,
    # Eq. 20: Equivalent annual annuity
    EAA = NPV * r / (1 - (1 + r)^(-LT))
  )

#---------------- RRPV-BS ----------------

annual_rrpv_bs <- future_returns_rrpv_bs %>%
  group_by(household_id, year) %>%
  summarise(
    R_y               = sum(R_t,            na.rm = TRUE),
    sales_y           = sum(export_value,   na.rm = TRUE),
    savings_y         = sum(self_use_value, na.rm = TRUE),
    total_self_use    = sum(self_use_t,     na.rm = TRUE),
    total_consumption = sum(E_self_t,       na.rm = TRUE),
    .groups = "drop"
  ) %>%
  left_join(
    cost_data %>% select(
      household_id,
      upfront_cost_usd,
      battery_cost_usd,
      annual_om_cost_usd
    ),
    by = "household_id"
  ) %>%
  mutate(
    total_upfront = upfront_cost_usd + battery_cost_usd,
    net_return_y  = R_y - annual_om_cost_usd,
    y_relative    = year - min(year) + 1
  ) %>%
  filter(y_relative <= LT)

npv_rrpv_bs <- annual_rrpv_bs %>%
  group_by(household_id) %>%
  summarise(
    total_discounted_gross   = sum(R_y          / (1 + r)^y_relative),
    total_discounted_sales   = sum(sales_y      / (1 + r)^y_relative),
    total_discounted_savings = sum(savings_y    / (1 + r)^y_relative),
    total_discounted_net     = sum(net_return_y / (1 + r)^y_relative),
    total_self_use           = sum(total_self_use),
    total_consumption        = sum(total_consumption),
    total_upfront            = first(total_upfront),
    .groups = "drop"
  ) %>%
  mutate(
    NPV = total_discounted_net - total_upfront
  ) %>%
  left_join(
    household_chars_rrpv_bs %>% select(household_id, install_capacity_kwp, temp_zone),
    by = "household_id"
  ) %>%
  mutate(
    annual_gross_per_kwp  = total_discounted_gross / (LT * install_capacity_kwp),
    annual_net_per_kwp    = (NPV / LT) / install_capacity_kwp,
    self_sufficiency_rate = total_self_use / total_consumption,
    EAA                   = NPV * r / (1 - (1 + r)^(-LT))
  )

saveRDS(npv_rrpv,    file.path(path_output, "npv_and_eaa_rrpv.RDS"))
saveRDS(npv_rrpv_bs, file.path(path_output, "npv_and_eaa_rrpv_bs.RDS"))

#-------------------------------------------------------------------------------
# 12. FIGURE 5 DATA
#-------------------------------------------------------------------------------

# --- Panel A: Overall Economic Return ---
fig5_panel_a <- bind_rows(
  npv_rrpv %>%
    summarise(
      System                     = "RRPV Adopters", 
      Total_Gross_Return_Per_kWp = mean(annual_gross_per_kwp, na.rm = TRUE),
      Net_Earnings_Per_kWp       = mean(annual_net_per_kwp,   na.rm = TRUE)
    ),
  npv_rrpv_bs %>%
    summarise(
      System                     = "RRPV-BS Adopters",
      Total_Gross_Return_Per_kWp = mean(annual_gross_per_kwp, na.rm = TRUE),
      Net_Earnings_Per_kWp       = mean(annual_net_per_kwp,   na.rm = TRUE)
    )
)

# --- Panel B: Return Composition ---
fig5_panel_b <- bind_rows(
  npv_rrpv %>%
    summarise(
      System           = "RRPV Adopters", 
      Sales_Return_Pct = mean(total_discounted_sales   / total_discounted_gross * 100, na.rm = TRUE),  
      Bill_Savings_Pct = mean(total_discounted_savings / total_discounted_gross * 100, na.rm = TRUE)
    ),
  npv_rrpv_bs %>%
    summarise(
      System           = "RRPV-BS Adopters",
      Sales_Return_Pct = mean(total_discounted_sales   / total_discounted_gross * 100, na.rm = TRUE),
      Bill_Savings_Pct = mean(total_discounted_savings / total_discounted_gross * 100, na.rm = TRUE)
    )
)

# --- Panel C: Performance Metrics ---
fig5_panel_c <- bind_rows(
  npv_rrpv %>%
    summarise(
      System             = "RRPV Adopters",  
      Self_Sufficiency   = mean(self_sufficiency_rate * 100, na.rm = TRUE),  
      Economic_Viability = mean(NPV > 0, na.rm = TRUE) * 100 
    ),
  npv_rrpv_bs %>%
    summarise(
      System             = "RRPV-BS Adopters",
      Self_Sufficiency   = mean(self_sufficiency_rate * 100, na.rm = TRUE),
      Economic_Viability = mean(NPV > 0, na.rm = TRUE) * 100
    )
)

# --- Panel D & E: Return by Zone ---
calc_zone_returns <- function(df, sys_name) {
  df %>%
    group_by(temp_zone) %>%
    summarise(
      Sales_Return = mean(total_discounted_sales   / (LT * install_capacity_kwp), na.rm = TRUE),
      Bill_Savings = mean(total_discounted_savings / (LT * install_capacity_kwp), na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(System = sys_name)
}

fig5_panel_d <- calc_zone_returns(npv_rrpv,    "RRPV Adopters")   
fig5_panel_e <- calc_zone_returns(npv_rrpv_bs, "RRPV-BS Adopters") 

# --- Panel F: Self-Sufficiency by Zone ---
fig5_panel_f <- bind_rows(
  npv_rrpv %>% 
    group_by(temp_zone) %>% 
    summarise(
      Self_Sufficiency_Rate = mean(self_sufficiency_rate * 100, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(System = "RRPV Adopters"),
  npv_rrpv_bs %>% 
    group_by(temp_zone) %>% 
    summarise(
      Self_Sufficiency_Rate = mean(self_sufficiency_rate * 100, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(System = "RRPV-BS Adopters")
)

# --- Save All ---
saveRDS(fig5_panel_a, file.path(path_output, "fig5_panel_a_data.RDS"))
saveRDS(fig5_panel_b, file.path(path_output, "fig5_panel_b_data.RDS"))
saveRDS(fig5_panel_c, file.path(path_output, "fig5_panel_c_data.RDS"))
saveRDS(fig5_panel_d, file.path(path_output, "fig5_panel_d_data.RDS"))
saveRDS(fig5_panel_e, file.path(path_output, "fig5_panel_e_data.RDS"))
saveRDS(fig5_panel_f, file.path(path_output, "fig5_panel_f_data.RDS"))

#===============================================================================
# END OF SCRIPT
#===============================================================================