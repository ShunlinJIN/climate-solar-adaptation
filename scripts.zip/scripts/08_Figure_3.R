#===============================================================================
# Figure 3: Climate-Induced Solar and Battery Co-adoption
#
# Description: This script extracts results from models related to RRPV-BS 
# adoption and power outages (Equation 7) to generate Figure 3. 
# It visualizes the temperature response for RRPV-BS, the dynamic effects of 
# power rationing on both RRPV-BS and total RRPV adoption, and the interaction
# between power rationing and temperature.
#
#===============================================================================
library(tidyverse)
library(fixest)
library(ggplot2)
library(ggprism)
library(patchwork)

# --- Paths ---
path_root     <- "D:/rooftop"
path_models   <- file.path(path_root, "models")
path_plotting <- file.path(path_root, "plotting_data")
output_dir    <- "D:/rooftop/Fig"

# --- Text Size Variables ---
text_size_axis_text   <- 18
text_size_axis_title  <- 20
text_size_legend_text <- 18
text_size_plot_tag    <- 22

# --- Common Theme Function ---
common_plot_theme_base <- function() {
  theme_prism() +
    theme(
      axis.text   = element_text(size = text_size_axis_text,  face = "plain", color = "black"),
      axis.title  = element_text(size = text_size_axis_title, face = "plain", color = "black"),
      axis.ticks  = element_line(linewidth = 0.5, color = "black"),
      axis.line   = element_line(linewidth = 0.5, color = "black"),
      legend.position = "top",
      legend.text     = element_text(size = text_size_legend_text, color = "black"),
      legend.title    = element_blank(),
      plot.title      = element_text(hjust = 0.5),
      plot.tag.position = "topleft",
      plot.tag        = element_text(face = "bold", size = text_size_plot_tag)
    )
}

#===============================================================================
# DATA EXTRACTION
#===============================================================================

extract_coef_ci <- function(model, vars) {
  coefs <- coef(model)[vars]
  ci    <- confint(model, level = 0.95)[vars, ]
  data.frame(
    variable = vars,
    coef     = coefs,
    lower_ci = ci[, 1],
    upper_ci = ci[, 2],
    row.names = NULL
  )
}

temp_bins <- c("temp_below_neg5", "temp_neg5_to_0", "temp_0_to_5", "temp_5_to_10",
               "temp_10_to_15", "temp_20_to_25", "temp_25_to_30", "temp_above_30")

# --- Figure 3a: RRPV-BS Temperature Response ---
rrpv_bs <- readRDS(file.path(path_models, "rrpv_bs_temp_response.RDS"))
fig3a_data <- extract_coef_ci(rrpv_bs, temp_bins) %>%
  add_row(variable = "temp_15_to_20", coef = 0, lower_ci = 0, upper_ci = 0, .before = 6)
saveRDS(fig3a_data, file.path(path_plotting, "fig3a_data.RDS"))

# --- Figure 3b: Power Outage Event Study (RRPV-BS) ---
eq7a <- readRDS(file.path(path_models, "eq7a_outage_rrpv_bs.RDS"))
outage_event_vars <- paste0("event_outage_", c(-8:-2, 0:8))

fig3b_data <- extract_coef_ci(eq7a, outage_event_vars) %>%
  add_row(variable = "event_outage_-1", coef = 0, lower_ci = 0, upper_ci = 0, .before = 8)
saveRDS(fig3b_data, file.path(path_plotting, "fig3b_data.RDS"))

# --- Figure 3c: Power Outage Event Study (RRPV-only) ---
eq7b <- readRDS(file.path(path_models, "eq7b_outage_total_rrpv.RDS"))
fig3c_data <- extract_coef_ci(eq7b, outage_event_vars) %>%
  add_row(variable = "event_outage_-1", coef = 0, lower_ci = 0, upper_ci = 0, .before = 8)
saveRDS(fig3c_data, file.path(path_plotting, "fig3c_data.RDS"))

# --- Figure 3d: Outage × Temperature Interaction (RRPV-BS) ---
eq7c <- readRDS(file.path(path_models, "eq7c_outage_temp_interact.RDS"))

interact_vars  <- paste0("outage_dummy:", temp_bins)
main_coefs     <- coef(eq7c)[temp_bins]
interact_coefs <- coef(eq7c)[interact_vars]

vcov_mat      <- vcov(eq7c)
combined_coefs <- main_coefs + interact_coefs
combined_se    <- sqrt(
  diag(vcov_mat[temp_bins, temp_bins]) +
    diag(vcov_mat[interact_vars, interact_vars]) +
    2 * diag(vcov_mat[temp_bins, interact_vars])
)

fig3d_data <- data.frame(
  variable = c(temp_bins[1:5], "temp_15_to_20", temp_bins[6:8]),
  coef     = c(combined_coefs[1:5], 0, combined_coefs[6:8]),
  lower_ci = c(combined_coefs[1:5] - 1.96 * combined_se[1:5], 0,
               combined_coefs[6:8] - 1.96 * combined_se[6:8]),
  upper_ci = c(combined_coefs[1:5] + 1.96 * combined_se[1:5], 0,
               combined_coefs[6:8] + 1.96 * combined_se[6:8])
)
saveRDS(fig3d_data, file.path(path_plotting, "fig3d_data.RDS"))

#===============================================================================
# PLOTTING
#===============================================================================

data_3a <- readRDS(file.path(path_plotting, "fig3a_data.RDS"))
data_3b <- readRDS(file.path(path_plotting, "fig3b_data.RDS"))
data_3c <- readRDS(file.path(path_plotting, "fig3c_data.RDS"))
data_3d <- readRDS(file.path(path_plotting, "fig3d_data.RDS"))

# --- Temperature Bin Labels ---
temperature_bins_labels <- c("≤-5°C", "-5-0°C", "0-5°C", "5-10°C", "10-15°C", 
                             "15-20°C", "20-25°C", "25-30°C", "≥30°C")

data_3a$temperature_bins <- factor(temperature_bins_labels,
                                   levels = temperature_bins_labels)

# --- Event-time Labels for Outage Event Studies ---
Pilot_month_labels <- c("≤-8", "-7", "-6", "-5", "-4", "-3", "-2", "-1",
                        "0", "1", "2", "3", "4", "5", "6", "7", "≥8")

data_3b$Pilot_month <- factor(Pilot_month_labels, levels = Pilot_month_labels)
data_3c$Pilot_month <- factor(Pilot_month_labels, levels = Pilot_month_labels)

#===============================================================================
# Figure 3a: RRPV-BS Temperature Response
#===============================================================================

p_3a <- ggplot(data_3a, aes(x = temperature_bins, y = coef, group = 1)) +
  geom_ribbon(aes(ymin = lower_ci, ymax = upper_ci, fill = "95% CI"), alpha = 0.5) +
  geom_line(aes(color = "Estimated Coefficients"), linewidth = 1) +
  geom_point(aes(color = "Estimated Coefficients"), size = 3) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  scale_x_discrete(expand = expansion(mult = c(0.06, 0.06))) +
  scale_y_continuous(
    name   = "Estimated Coefficients",
    limits = c(-0.03, 0.09), 
    breaks = seq(-0.03, 0.09, by = 0.03),
    guide  = "prism_offset"
  ) +
  xlab("Temperature bins") +
  scale_color_manual(name = NULL, values = c("Estimated Coefficients" = "springgreen4")) +
  scale_fill_manual(name = NULL, values = c("95% CI" = "aquamarine2")) +
  common_plot_theme_base() +
  theme(
    axis.text.x = element_text(size = text_size_axis_text, angle = 0, hjust = 0.5, color = "black"),
    plot.margin = unit(c(0.5, 0.5, 0.5, 0.5), "cm")
  ) +
  labs(tag = "a") +
  guides(fill = guide_legend(order = 1), color = guide_legend(order = 2))

#===============================================================================
# Figure 3b: Power Outage Event Study (RRPV-BS)
#===============================================================================

p_3b <- ggplot(data_3b, aes(x = Pilot_month, y = coef, group = 1)) +
  geom_ribbon(aes(ymin = lower_ci, ymax = upper_ci, fill = "95% CI"), alpha = 0.5) +
  geom_line(aes(color = "Estimated Coefficients"), linewidth = 1) +
  geom_point(aes(color = "Estimated Coefficients"), size = 3) +
  geom_vline(xintercept = 8, linetype = "dashed", color = "black", linewidth = 0.5) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", linewidth = 0.5) +
  scale_y_continuous(
    name   = "Estimated Coefficients",
    breaks = seq(-0.02, 0.04, by = 0.01),
    limits = c(-0.02, 0.04),
    guide  = "prism_offset"
  ) +
  xlab("Months before and after power rationing") +
  scale_color_manual(name = NULL, values = c("Estimated Coefficients" = "springgreen4")) +
  scale_fill_manual(name = NULL, values = c("95% CI" = "aquamarine2")) +
  common_plot_theme_base() +
  theme(
    axis.text.x = element_text(size = text_size_axis_text, angle = 0, hjust = 0.5, color = "black"),
    axis.title.x = element_text(size = text_size_axis_title, color = "black"),
    plot.margin = unit(c(0.5, 0.5, 0.5, 0.5), "cm")
  ) +
  labs(tag = "b") +
  guides(fill = guide_legend(order = 1), color = guide_legend(order = 2))

#===============================================================================
# Figure 3c: Power Outage Event Study (RRPV-only)
#===============================================================================

p_3c <- ggplot(data_3c, aes(x = Pilot_month, y = coef, group = 1)) +
  geom_ribbon(aes(ymin = lower_ci, ymax = upper_ci, fill = "95% CI"),
              alpha = 0.5, color = NA) +
  geom_line(aes(color = "Estimated Coefficients"), linewidth = 1) +
  geom_point(aes(color = "Estimated Coefficients"), size = 3) +
  geom_vline(xintercept = 8, linetype = "dashed", color = "black", linewidth = 0.5) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", linewidth = 0.5) +
  scale_y_continuous(
    name   = "Estimated Coefficients",
    breaks = c(-0.025, 0, 0.025, 0.05, 0.075),
    limits = c(-0.025, 0.075),
    guide  = "prism_offset"
  ) +
  xlab("Months before and after power rationing") +
  scale_color_manual(name = NULL, values = c("Estimated Coefficients" = "springgreen4")) +
  scale_fill_manual(name = NULL, values = c("95% CI" = "aquamarine2")) +
  common_plot_theme_base() +
  theme(
    axis.text.x = element_text(size = text_size_axis_text, angle = 0, hjust = 0.5, color = "black"),
    axis.title.x = element_text(size = text_size_axis_title, color = "black"),
    plot.margin = unit(c(0.5, 0.5, 0.5, 0.5), "cm")
  ) +
  labs(tag = "c") +
  guides(fill = guide_legend(order = 1), color = guide_legend(order = 2))

#===============================================================================
# Figure 3d: Outage × Temperature Interaction (RRPV-BS)
#===============================================================================

data_3d$temperature_bins <- factor(temperature_bins_labels,
                                   levels = temperature_bins_labels)

p_3d <- ggplot(data_3d, aes(x = temperature_bins, y = coef, group = 1)) +
  geom_ribbon(aes(ymin = lower_ci, ymax = upper_ci, fill = "95% CI"), alpha = 0.5) +
  geom_line(aes(color = "Estimated Coefficients"), linewidth = 1) +
  geom_point(aes(color = "Estimated Coefficients"), size = 3) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  scale_x_discrete(expand = expansion(mult = c(0.06, 0.06))) +
  scale_y_continuous(
    name   = "Estimated Coefficients",
    limits = c(-0.06, 0.12),
    breaks = seq(-0.06, 0.12, by = 0.03),
    guide  = "prism_offset"
  ) +
  xlab("Temperature bins") +
  scale_color_manual(name = NULL, values = c("Estimated Coefficients" = "springgreen4")) +
  scale_fill_manual(name = NULL, values = c("95% CI" = "aquamarine2")) +
  common_plot_theme_base() +
  theme(
    axis.text.x = element_text(size = text_size_axis_text, angle = 0, hjust = 0.5, color = "black"),
    plot.margin = unit(c(0.5, 0.5, 0.5, 0.5), "cm")
  ) +
  labs(tag = "d") +
  guides(fill = guide_legend(order = 1), color = guide_legend(order = 2))

#===============================================================================
# COMBINE AND SAVE FIGURE 3
#===============================================================================

final_combined_plot_3 <- (p_3a | p_3b) / (p_3c | p_3d)

# PDF
ggsave(
  filename = file.path(output_dir, "Figure_3.pdf"),
  plot = final_combined_plot_3,
  width = 22, height = 14, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Figure_3.png"),
  plot = final_combined_plot_3,
  width = 22, height = 14, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white",
  limitsize = FALSE
)


#===============================================================================
# END OF SCRIPT
#===============================================================================
