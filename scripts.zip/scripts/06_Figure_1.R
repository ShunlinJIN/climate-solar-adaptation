#===============================================================================
# Figure 1: Climate-Induced Solar Adoption - Baseline Effects
#
# Description: Visualizes baseline temperature-adoption relationship (Eq. 1),
# cumulative temperature effects (Eq. 2), pilot policy dynamics (Eq. 4),
# and robustness checks (Eq. 5).
#
# Panels:
# a) Baseline temperature bin coefficients with daily temperature distribution
# b) Lagged temperature effects (1-month and 2-month lags)
# c) Event study of pilot policy implementation
# d) Robustness checks
#
#===============================================================================

library(tidyverse)
library(fixest)
library(ggplot2)
library(ggprism)
library(patchwork)

# --- Paths ---
path_root     <- "D:/rooftop"
path_models   <- file.path(path_root, "models")
path_plotting <- file.path(path_root, "plotting_data")
output_dir    <- file.path(path_root, "Fig")

# --- Plot Parameters ---
text_size_axis_text        <- 20
text_size_axis_title       <- 24
text_size_legend_text      <- 20
text_size_plot_tag         <- 26
text_size_x_axis_bar       <- 18

# --- Temperature Bins ---
temp_bins <- c("temp_below_neg5", "temp_neg5_to_0", "temp_0_to_5", "temp_5_to_10",
               "temp_10_to_15", "temp_20_to_25", "temp_25_to_30", "temp_above_30")

temperature_bins_labels <- c("≤-5°C", "-5-0°C", "0-5°C", "5-10°C", "10-15°C", 
                             "15-20°C", "20-25°C", "25-30°C", "≥30°C")

# --- Theme Function ---
common_plot_theme <- function() {
  theme_prism() +
    theme(
      axis.text = element_text(size = text_size_axis_text, color = "black"),
      axis.title = element_text(size = text_size_axis_title, color = "black"),
      axis.ticks = element_line(linewidth = 0.5, color = "black"),
      axis.line = element_line(linewidth = 0.5, color = "black"),
      legend.position = "top",
      legend.text = element_text(size = text_size_legend_text, color = "black"),
      legend.title = element_blank(),
      plot.tag.position = 'topleft',
      plot.tag = element_text(face = 'bold', size = text_size_plot_tag)
    )
}

# --- Extract Coefficients with CI ---
extract_coef_ci <- function(model, vars) {
  coefs <- coef(model)[vars]
  ci <- confint(model, level = 0.95)[vars, ]
  data.frame(
    variable = vars,
    coef = coefs,
    lower_ci = ci[, 1],
    upper_ci = ci[, 2],
    row.names = NULL
  )
}


#===============================================================================
# PANEL A: Baseline Temperature Effect (Eq. 1)
#===============================================================================

eq1 <- readRDS(file.path(path_models, "eq1_baseline.RDS"))
fig1a_coefs <- extract_coef_ci(eq1, temp_bins) %>%
  add_row(variable = "temp_15_to_20", coef = 0, lower_ci = 0, upper_ci = 0, .before = 6)

data <- readRDS(file.path(path_root, "adoption/rrpv_analysis_panel.RDS"))
temp_dist <- data %>%
  summarise(across(all_of(c(temp_bins, "temp_15_to_20")), ~sum(., na.rm = TRUE))) %>%
  pivot_longer(everything(), names_to = "variable", values_to = "days_in_bins")

data_1a <- fig1a_coefs %>% 
  left_join(temp_dist, by = "variable") %>%
  mutate(temperature_bins = factor(temperature_bins_labels, levels = temperature_bins_labels))

saveRDS(data_1a, file.path(path_plotting, "fig1a_data.RDS"))

# Plot
line_plot_1a <- ggplot(data_1a, aes(x = temperature_bins, y = coef, group = 1)) +
  geom_ribbon(aes(ymin = lower_ci, ymax = upper_ci, fill = "95% CI"), alpha = 0.5) +
  geom_line(aes(color = "Estimated Coefficients"), linewidth = 1) +
  geom_point(aes(color = "Estimated Coefficients"), size = 3) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  scale_x_discrete(expand = expansion(mult = c(0.06, 0.06))) +
  scale_y_continuous(
    name = "Estimated Coefficients",
    limits = c(-0.04, 0.16), 
    breaks = seq(-0.04, 0.16, by = 0.04),
    guide = "prism_offset"
  ) +
  scale_color_manual(values = c("Estimated Coefficients" = "deepskyblue4")) +
  scale_fill_manual(values = c("95% CI" = "lightblue")) +
  common_plot_theme() +
  theme(
    axis.text.x = element_blank(),
    axis.title.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.line.x = element_blank(),
    plot.margin = unit(c(0.5, 0.5, 0, 0.5), "cm")
  ) +
  labs(tag = "a")

bar_plot_1a <- ggplot(data_1a, aes(x = temperature_bins, y = days_in_bins)) +
  geom_bar(stat = "identity", fill = "grey70", width = 0.5) +
  scale_x_discrete(name = "Temperature bins", expand = expansion(mult = c(0.06, 0.06))) +
  scale_y_continuous(limits = c(0, 12000), breaks = seq(0, 12000, 4000), expand = c(0, 0)) +
  theme_classic() +
  theme(
    axis.line.y = element_blank(),
    axis.ticks.y = element_blank(),
    axis.text.y = element_blank(),
    axis.title.y = element_blank(),
    axis.line.x = element_line(linewidth = 0.5, color = "black"),
    axis.ticks.x = element_line(linewidth = 0.5, color = "black"),
    axis.text.x = element_text(size = text_size_x_axis_bar, color = "black"),
    axis.title.x = element_text(size = text_size_axis_title, color = "black"),
    plot.margin = unit(c(0, 0.5, 0.5, 0.5), "cm")
  )

p_1a <- line_plot_1a / bar_plot_1a + plot_layout(heights = c(3, 1))


#===============================================================================
# PANEL B: Lagged Temperature Effects (Eq. 2)
#===============================================================================

eq2 <- readRDS(file.path(path_models, "eq2_cumulative.RDS"))
vcov_eq2 <- vcov(eq2, cluster = "county_id")
coef_eq2 <- coef(eq2)

# --- Function: Calculate Cumulative Sum and 95% CI ---
get_cumulative_stats <- function(bin, lags_to_sum, level = 0.95) {
  if (length(lags_to_sum) == 0) {
    vars <- bin # Just current
  } else {
    vars <- c(bin, paste0(bin, "_lag", lags_to_sum))
  }
  vars <- vars[vars %in% names(coef_eq2)]
  if (length(vars) == 0) return(c(coef = NA, lower = NA, upper = NA))
  # 1. Sum Coefficients
  sum_coef <- sum(coef_eq2[vars])
  # 2. Calculate Standard Error of the Sum
  sub_vcov <- vcov_eq2[vars, vars, drop = FALSE]
  se_sum   <- sqrt(sum(sub_vcov))
  # 3. Calculate 95% CI
  alpha <- 1 - level
  crit  <- qnorm(1 - alpha / 2)
  lower_ci <- sum_coef - crit * se_sum
  upper_ci <- sum_coef + crit * se_sum
  return(c(coef = sum_coef, lower = lower_ci, upper = upper_ci))
}

# --- 1. Calculate "Lag 1" Series (Cumulative: Current + Lag 1) ---
lag1_data_raw <- map_dfr(temp_bins, function(b) {
  stats <- get_cumulative_stats(b, lags_to_sum = 1) # Current + Lag1
  data.frame(
    variable = b,
    coef = stats["coef"],
    lower_ci = stats["lower"],
    upper_ci = stats["upper"]
  )
})

lag1_data <- lag1_data_raw %>%
  add_row(variable = "temp_15_to_20", coef = 0, lower_ci = 0, upper_ci = 0, .before = 6) %>%
  rename(Lag1 = coef, lower_ci1 = lower_ci, upper_ci1 = upper_ci)

# --- 2. Calculate "Lag 2" Series (Cumulative: Current + Lag 1 + Lag 2) ---
lag2_data_raw <- map_dfr(temp_bins, function(b) {
  stats <- get_cumulative_stats(b, lags_to_sum = c(1, 2)) # Current + Lag1 + Lag2
  data.frame(
    variable = b,
    coef = stats["coef"],
    lower_ci = stats["lower"],
    upper_ci = stats["upper"]
  )
})

lag2_data <- lag2_data_raw %>%
  add_row(variable = "temp_15_to_20", coef = 0, lower_ci = 0, upper_ci = 0, .before = 6) %>%
  rename(Lag2 = coef, lower_ci2 = lower_ci, upper_ci2 = upper_ci)

# --- 3. Merge Data for Plotting --
data_1b <- lag1_data %>%
  left_join(select(lag2_data, variable, Lag2, lower_ci2, upper_ci2), by = "variable") %>%
  mutate(temperature_bins = factor(temperature_bins_labels, levels = temperature_bins_labels))

saveRDS(data_1b, file.path(path_plotting, "fig1b_data.RDS"))

# --- 4. Plot ---
p_1b <- ggplot(data_1b, aes(x = temperature_bins)) +
  geom_ribbon(aes(ymin = lower_ci1, ymax = upper_ci1, fill = "95% CI (Lag 1)", group = 1), alpha = 0.3) +
  geom_ribbon(aes(ymin = lower_ci2, ymax = upper_ci2, fill = "95% CI (Lag 2)", group = 1), alpha = 0.3) +
  geom_line(aes(y = Lag1, color = "Lag 1", group = 1), linewidth = 1) +
  geom_point(aes(y = Lag1, color = "Lag 1"), size = 3) +
  geom_line(aes(y = Lag2, color = "Lag 2", group = 1), linewidth = 1, linetype = "dashed") +
  geom_point(aes(y = Lag2, color = "Lag 2"), size = 3, shape = 21, fill = "white") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  scale_x_discrete(expand = expansion(mult = c(0.06, 0.06))) +
  scale_y_continuous(
    name = "Estimated Coefficients",
    limits = c(-0.04, 0.16),
    breaks = seq(-0.04, 0.16, by = 0.04),
    guide = "prism_offset"
  ) +
  xlab("Temperature bins") +
  scale_fill_manual(values = c("95% CI (Lag 1)" = "lightblue", "95% CI (Lag 2)" = "lightpink")) +
  scale_color_manual(values = c("Lag 1" = "blue", "Lag 2" = "red")) +
  common_plot_theme() +
  theme(axis.text.x = element_text(size = text_size_axis_text, color = "black")) +
  labs(tag = "b")


#===============================================================================
# PANEL C: Pilot Policy Event Study (Eq. 4)
#===============================================================================

eq4 <- readRDS(file.path(path_models, "eq4_pilot_event.RDS"))
event_vars <- paste0("event_pilot_", c(-8:-2, 0:8))

data_1c <- extract_coef_ci(eq4, event_vars) %>%
  add_row(variable = "event_pilot_-1", coef = 0, lower_ci = 0, upper_ci = 0, .before = 8) %>%
  mutate(Pilot_month = factor(
    c("≤-8", "-7", "-6", "-5", "-4", "-3", "-2", "-1", "0", "1", "2", "3", "4", "5", "6", "7", "≥8"),
    levels = c("≤-8", "-7", "-6", "-5", "-4", "-3", "-2", "-1", "0", "1", "2", "3", "4", "5", "6", "7", "≥8")
  ))

saveRDS(data_1c, file.path(path_plotting, "fig1c_data.RDS"))

# Plot
p_1c <- ggplot(data_1c, aes(x = Pilot_month, y = coef, group = 1)) +
  geom_ribbon(aes(ymin = lower_ci, ymax = upper_ci, fill = "95% CI"), alpha = 0.5) +
  geom_line(aes(color = "Estimated Coefficients"), linewidth = 1) +
  geom_point(aes(color = "Estimated Coefficients"), size = 3) +
  geom_vline(xintercept = 8, linetype = "dashed", color = "black", linewidth = 0.5) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", linewidth = 0.5) +
  scale_y_continuous(
    name = "Estimated Coefficients",
    breaks = c(-0.025, 0, 0.025, 0.05, 0.075),
    limits = c(-0.025, 0.075),
    guide = "prism_offset"
  ) +
  xlab("Pilot month") +
  scale_color_manual(values = c("Estimated Coefficients" = "deepskyblue4")) +
  scale_fill_manual(values = c("95% CI" = "lightblue")) +
  common_plot_theme() +
  theme(axis.text.x = element_text(size = text_size_axis_text, color = "black")) +
  labs(tag = "c")


#===============================================================================
# PANEL D: Robustness Checks (Eq. 5 and variants)
#===============================================================================

# Load robustness models
pre_covid <- readRDS(file.path(path_models, "robust_pre_covid.RDS"))
no_pilot <- readRDS(file.path(path_models, "robust_no_pilot.RDS"))
no_subsidy <- readRDS(file.path(path_models, "robust_no_subsidy.RDS"))
pilot_temp <- readRDS(file.path(path_models, "eq5_pilot_temp_interact.RDS"))

# Baseline
baseline_data <- extract_coef_ci(eq1, temp_bins) %>%
  add_row(variable = "temp_15_to_20", coef = 0, lower_ci = 0, upper_ci = 0, .before = 6) %>%
  rename(Baseline = coef, baseline_lower = lower_ci, baseline_upper = upper_ci)

# Pre-COVID
pre_covid_data <- extract_coef_ci(pre_covid, temp_bins) %>%
  add_row(variable = "temp_15_to_20", coef = 0, lower_ci = 0, upper_ci = 0, .before = 6) %>%
  rename(Before_COVID19 = coef) %>%
  select(variable, Before_COVID19)

# No pilot
no_pilot_data <- extract_coef_ci(no_pilot, temp_bins) %>%
  add_row(variable = "temp_15_to_20", coef = 0, lower_ci = 0, upper_ci = 0, .before = 6) %>%
  rename(No_Policy = coef) %>%
  select(variable, No_Policy)

# No subsidy
no_subsidy_data <- extract_coef_ci(no_subsidy, temp_bins) %>%
  add_row(variable = "temp_15_to_20", coef = 0, lower_ci = 0, upper_ci = 0, .before = 6) %>%
  rename(No_subsidy = coef) %>%
  select(variable, No_subsidy)

# Pilot interaction
interact_vars <- paste0("pilot_dummy:", temp_bins)
main_coefs <- coef(pilot_temp)[temp_bins]
interact_coefs <- coef(pilot_temp)[interact_vars]

pilot_interact_data <- data.frame(
  variable = c(temp_bins[1:5], "temp_15_to_20", temp_bins[6:8]),
  Promotion_Policy = c(
    main_coefs[1:5] + interact_coefs[1:5],
    0,
    main_coefs[6:8] + interact_coefs[6:8]
  )
)

data_1d <- baseline_data %>%
  left_join(pre_covid_data, by = "variable") %>%
  left_join(no_pilot_data, by = "variable") %>%
  left_join(pilot_interact_data, by = "variable") %>%
  left_join(no_subsidy_data, by = "variable") %>%
  mutate(temperature_bins = factor(temperature_bins_labels, levels = temperature_bins_labels))

saveRDS(data_1d, file.path(path_plotting, "fig1d_data.RDS"))

# Plot
p_1d <- ggplot(data_1d, aes(x = temperature_bins)) +
  geom_ribbon(aes(ymin = baseline_lower, ymax = baseline_upper, fill = "Baseline CI", group = 1), alpha = 0.5) +
  geom_point(aes(y = Baseline, color = "Baseline"), size = 3, shape = 22, fill = "deepskyblue4") +
  geom_line(aes(y = Before_COVID19, color = "Pre-COVID", group = 1), linewidth = 1, linetype = "dashed") +
  geom_point(aes(y = Before_COVID19, color = "Pre-COVID"), size = 3, shape = 18) +
  geom_line(aes(y = No_Policy, color = "No Pilot", group = 1), linewidth = 1, linetype = "dotted") +
  geom_point(aes(y = No_Policy, color = "No Pilot"), size = 3, shape = 24) +
  geom_line(aes(y = Promotion_Policy, color = "Interacting with Pilot Policy", group = 1), linewidth = 1, linetype = "dotdash") +
  geom_point(aes(y = Promotion_Policy, color = "Interacting with Pilot Policy"), size = 3, shape = 21, fill = "red") +
  geom_line(aes(y = No_subsidy, color = "No Subsidy", group = 1), linewidth = 1, linetype = "twodash") +
  geom_point(aes(y = No_subsidy, color = "No Subsidy"), size = 3, shape = 23, fill = "purple") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  scale_x_discrete(expand = expansion(mult = c(0.06, 0.06))) +
  scale_y_continuous(
    name = "Estimated Coefficients",
    limits = c(-0.04, 0.16),
    breaks = seq(-0.04, 0.16, by = 0.04),
    guide = "prism_offset"
  ) +
  xlab("Temperature bins") +
  scale_fill_manual(values = c("Baseline CI" = "lightblue")) +
  scale_color_manual(
    values = c(
      "Baseline" = "deepskyblue4",
      "Interacting with Pilot Policy" = "red",
      "No Pilot" = "orange",
      "No Subsidy" = "purple",
      "Pre-COVID" = "blue"
    )
  ) +
  guides(fill = guide_legend(order = 1), color = guide_legend(nrow = 2, order = 2)) +
  common_plot_theme() +
  theme(
    axis.text.x = element_text(size = text_size_axis_text, color = "black"),
    legend.text = element_text(size = text_size_legend_text)
  ) +
  labs(tag = "d")


#===============================================================================
# COMBINE AND SAVE FIGURE 1
#===============================================================================
final_plot <- (p_1a | p_1b) / (p_1c | p_1d)

# PDF
ggsave(
  filename = file.path(output_dir, "Figure_1.pdf"),
  plot = final_plot,
  width = 22, height = 14, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Figure_1.png"),
  plot = final_plot,
  width = 22, height = 14, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)


#===============================================================================
# END OF SCRIPT
#===============================================================================
