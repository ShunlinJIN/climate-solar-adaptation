#===============================================================================
# Supplementary Fig. 12: Temperature impact on grid electricity consumption
#
# Description:
# This script estimates and visualizes how monthly grid electricity consumption
# responds to temperature, comparing non-adopters (panel a) with RRPV adopters
# (panel b). Models include weather controls (sunshine, rainfall, humidity, wind)
# and calendar controls (holidays, weekends),
# with household-by-year and year-by-month fixed effects.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(fixest)
library(ggplot2)
library(patchwork)
library(lubridate)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root   <- "D:/rooftop"
path_models <- file.path(path_root, "models")
output_dir  <- file.path(path_root, "Fig")

#-------------------------------------------------------------------------------
# 2. LOAD DAILY DATA
#-------------------------------------------------------------------------------

data_control_daily <- readRDS(file.path(path_root, "electricity/control_electricity_panel.RDS"))
data_rrpv_daily    <- readRDS(file.path(path_root, "electricity/rrpv_electricity_panel.RDS"))

#-------------------------------------------------------------------------------
# 3. AGGREGATE TO MONTHLY LEVEL
#-------------------------------------------------------------------------------

# Temperature bin assignment function
assign_temp_bin <- function(temp) {
  case_when(
    temp <= -5              ~ "temp_below_neg5",
    temp > -5 & temp <= 0   ~ "temp_neg5_to_0",
    temp > 0  & temp <= 5   ~ "temp_0_to_5",
    temp > 5  & temp <= 10  ~ "temp_5_to_10",
    temp > 10 & temp <= 15  ~ "temp_10_to_15",
    temp > 15 & temp <= 20  ~ "temp_15_to_20",
    temp > 20 & temp <= 25  ~ "temp_20_to_25",
    temp > 25 & temp <= 30  ~ "temp_25_to_30",
    temp > 30               ~ "temp_above_30",
    TRUE                    ~ NA_character_
  )
}

# Monthly aggregation function
aggregate_to_monthly <- function(daily_data, consumption_var) {
  daily_data %>%
    mutate(
      time = as.Date(time),
      year = year(time),
      month = month(time),
      temp_bin = assign_temp_bin(temp_avg_celsius)
    ) %>%
    group_by(household_id, year, month) %>%
    summarise(
      # Dependent variable
      consumption_monthly = sum(!!sym(consumption_var), na.rm = TRUE),
      
      # Temperature bins
      temp_below_neg5 = sum(temp_bin == "temp_below_neg5", na.rm = TRUE),
      temp_neg5_to_0  = sum(temp_bin == "temp_neg5_to_0", na.rm = TRUE),
      temp_0_to_5     = sum(temp_bin == "temp_0_to_5", na.rm = TRUE),
      temp_5_to_10    = sum(temp_bin == "temp_5_to_10", na.rm = TRUE),
      temp_10_to_15   = sum(temp_bin == "temp_10_to_15", na.rm = TRUE),
      temp_15_to_20   = sum(temp_bin == "temp_15_to_20", na.rm = TRUE),
      temp_20_to_25   = sum(temp_bin == "temp_20_to_25", na.rm = TRUE),
      temp_25_to_30   = sum(temp_bin == "temp_25_to_30", na.rm = TRUE),
      temp_above_30   = sum(temp_bin == "temp_above_30", na.rm = TRUE),
      
      # Weather controls (monthly averages)
      sunshine_hours_daily_avg = mean(sunshine_hours_daily_avg, na.rm = TRUE),
      rainfall_mm_daily_avg    = mean(rainfall_mm_daily_avg, na.rm = TRUE),
      humidity_pct_daily_avg   = mean(humidity_pct_daily_avg, na.rm = TRUE),
      windspeed_ms_daily_avg   = mean(windspeed_ms_daily_avg, na.rm = TRUE),
      
      # Calendar controls (total days in month)
      is_holiday = sum(is_holiday, na.rm = TRUE),
      is_weekend = sum(is_weekend, na.rm = TRUE),
      
      .groups = 'drop'
    ) %>%
    mutate(
      log_consumption = log(consumption_monthly + 1),
      
      sunshine_hours_daily_avg_sq = sunshine_hours_daily_avg^2,
      rainfall_mm_daily_avg_sq    = rainfall_mm_daily_avg^2,
      humidity_pct_daily_avg_sq   = humidity_pct_daily_avg^2,
      windspeed_ms_daily_avg_sq   = windspeed_ms_daily_avg^2
    )
}

data_control_monthly <- aggregate_to_monthly(data_control_daily, "total_consumption_kwh")
data_rrpv_monthly    <- aggregate_to_monthly(data_rrpv_daily, "grid_import_kwh")

#-------------------------------------------------------------------------------
# 4. MODEL ESTIMATION
#-------------------------------------------------------------------------------

model_formula <- as.formula(
  `log_consumption ~ 
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg + windspeed_ms_daily_avg_sq +
    is_holiday + is_weekend |
    household_id^year + year^month`
)

model_a <- feols(
  fml = model_formula,
  data = data_control_monthly,
  cluster = ~household_id
)
saveRDS(model_a, file.path(path_models, "supp_fig14a_model.RDS"))

model_b <- feols(
  fml = model_formula,
  data = data_rrpv_monthly,
  cluster = ~household_id
)
saveRDS(model_b, file.path(path_models, "supp_fig14b_model.RDS"))

#-------------------------------------------------------------------------------
# 5. EXTRACT DATA FOR PLOTTING
#-------------------------------------------------------------------------------

temp_bins_vars <- c("temp_below_neg5", "temp_neg5_to_0", "temp_0_to_5", "temp_5_to_10",
                    "temp_10_to_15", "temp_20_to_25", "temp_25_to_30", "temp_above_30")

extract_plot_data <- function(model_object, monthly_data) {
  coef_data <- tibble(
    variable = temp_bins_vars,
    coef = coef(model_object)[temp_bins_vars]
  )
  
  ci_matrix <- confint(model_object, level = 0.95)[temp_bins_vars, ]
  coef_data$lower_ci <- ci_matrix[, 1]
  coef_data$upper_ci <- ci_matrix[, 2]
  
  # Add reference category (15-20°C)
  coef_data <- coef_data %>%
    add_row(variable = "temp_15_to_20", coef = 0, lower_ci = 0, upper_ci = 0, .before = 6)
  
  # Calculate temperature distribution
  temp_dist <- monthly_data %>%
    summarise(across(all_of(c(temp_bins_vars, "temp_15_to_20")), ~sum(., na.rm = TRUE))) %>%
    pivot_longer(everything(), names_to = "variable", values_to = "days_in_bins")
  
  left_join(coef_data, temp_dist, by = "variable")
}

data_plot_a <- extract_plot_data(model_a, data_control_monthly)
data_plot_b <- extract_plot_data(model_b, data_rrpv_monthly)

#-------------------------------------------------------------------------------
# 6. VISUALIZATION
#-------------------------------------------------------------------------------

# Common theme
text_size_axis_text  <- 10
text_size_axis_title <- 12

common_plot_theme <- function() {
  theme_minimal() +
    theme(
      panel.background = element_rect(fill = "white", colour = NA),
      plot.background  = element_rect(fill = "white", colour = NA),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      axis.line        = element_line(colour = "black", linewidth = 0.5),
      axis.ticks       = element_line(colour = "black", linewidth = 0.5),
      axis.text        = element_text(size = text_size_axis_text, color = "black"),
      axis.title       = element_text(size = text_size_axis_title, color = "black"),
      legend.position  = "top",
      legend.title     = element_blank(),
      legend.text      = element_text(size = text_size_axis_text, color = "black"),
      plot.tag         = element_text(face = 'bold', size = 14)
    )
}

# Panel plot function
create_panel_plot <- function(plot_data, panel_tag) {
  
  temperature_bins_labels <- c("≤-5°C", "-5-0°C", "0-5°C", "5-10°C", "10-15°C", 
                               "15-20°C", "20-25°C", "25-30°C", "≥30°C")
  
  plot_data <- plot_data %>%
    mutate(
      temperature_bins = factor(
        variable,
        levels = c("temp_below_neg5", "temp_neg5_to_0", "temp_0_to_5", "temp_5_to_10",
                   "temp_10_to_15", "temp_15_to_20", "temp_20_to_25", "temp_25_to_30", 
                   "temp_above_30"),
        labels = temperature_bins_labels
      )
    )
  
  # Top plot: Estimated coefficients
  line_plot <- ggplot(plot_data, aes(x = temperature_bins, y = coef, group = 1)) +
    geom_ribbon(aes(ymin = lower_ci, ymax = upper_ci, fill = "95% CI"), alpha = 0.5) +
    geom_line(aes(color = "Estimated Coefficients"), linewidth = 1) +
    geom_point(color = "springgreen4", size = 3) +
    geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
    scale_x_discrete(expand = expansion(mult = c(0.06, 0.06))) +
    scale_y_continuous(
      limits = c(-0.1, 0.3), 
      expand = c(0, 0), 
      breaks = seq(-0.1, 0.3, by = 0.1)
    ) +
    scale_color_manual(name = NULL, values = c("Estimated Coefficients" = "springgreen4")) +
    scale_fill_manual(name = NULL, values = c("95% CI" = "aquamarine2")) +
    common_plot_theme() +
    theme(
      axis.title.x = element_blank(),
      axis.text.x = element_blank(),
      axis.ticks.x = element_blank(),
      axis.line.x = element_blank(),
      plot.margin = unit(c(0.5, 0.5, 0, 0.5), "cm")
    ) +
    ylab("Estimated Coefficients") +
    labs(tag = panel_tag) +
    guides(fill = guide_legend(order = 1), color = guide_legend(order = 2))
  
  # Bottom plot: Temperature distribution
  bar_plot <- ggplot(plot_data, aes(x = temperature_bins, y = days_in_bins)) +
    geom_bar(stat = "identity", fill = "grey70", width = 0.5) +
    scale_x_discrete(name = "Temperature bins", expand = expansion(mult = c(0.06, 0.06))) +
    scale_y_continuous(
      breaks = seq(0, 12000, 4000), 
      limits = c(0, max(plot_data$days_in_bins, na.rm = TRUE) * 1.1)
    ) +
    theme_minimal() +
    theme(
      panel.background = element_rect(fill = "white", colour = NA),
      panel.grid = element_blank(),
      axis.title.y = element_blank(),
      axis.text.y = element_blank(),
      axis.ticks.y = element_blank(),
      axis.line.y = element_blank(),
      axis.title.x = element_text(size = text_size_axis_title, color = "black"),
      axis.ticks.x = element_line(linewidth = 0.5, color = "black"),
      axis.text.x = element_text(size = text_size_axis_text, angle = 0, hjust = 0.5, color = "black"),
      axis.line.x = element_line(linewidth = 0.5, color = "black"),
      plot.margin = unit(c(0, 0.5, 0.5, 0.5), "cm")
    ) +
    xlab("Temperature bins")
  
  # Combine
  line_plot / bar_plot + plot_layout(heights = c(3, 1))
}

# Create panels
p_14a <- create_panel_plot(data_plot_a, panel_tag = "a")
p_14b <- create_panel_plot(data_plot_b, panel_tag = "b")

#-------------------------------------------------------------------------------
# 7. COMBINE AND SAVE
#-------------------------------------------------------------------------------

supp_fig_14 <- p_14a | p_14b

# PNG
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_12.png"),
  plot = supp_fig_14,
  width = 16, height = 6, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)

# PDF
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_12.pdf"),
  plot = supp_fig_14,
  width = 16, height = 6, units = "in",
  device = cairo_pdf
)


#===============================================================================
# END OF SCRIPT
#===============================================================================
