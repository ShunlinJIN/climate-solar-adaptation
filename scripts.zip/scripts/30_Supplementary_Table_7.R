#===============================================================================
# Supplementary Table 7: Robustness checks of temperature effects on RRPV-BS adoption
#
# This script estimates seven robustness check specifications for Equation (1)
# using RRPV-BS installations as dependent variable:
#   Column (1): Use maximum temperature instead of mean temperature
#   Column (2): Alternative FE - County FE + Month FE
#   Column (3): Alternative FE - Province FE + Year-by-month FE
#   Column (4): Alternative FE - County FE + Year-by-month FE + Province-by-year FE
#   Column (5): Alternative reference bin - 10-15°C instead of 15-20°C
#   Column (6): Narrower temperature bins - 3°C intervals (ref: 12-15°C)
#   Column (7): Alternative clustering - Province level
#
# All specifications include full set of control variables as in baseline model.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(fixest)
library(lubridate)
library(officer)
library(flextable)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root   <- "D:/rooftop"
path_models <- file.path(path_root, "models")
path_output <- file.path(path_root, "tables")

#-------------------------------------------------------------------------------
# 2. LOAD DATA
#-------------------------------------------------------------------------------

data_adoption <- readRDS(file.path(path_root, "adoption/rrpv_analysis_panel.RDS"))
weather_daily <- readRDS(file.path(path_root, "weather_daily_county.RDS"))

#-------------------------------------------------------------------------------
# 3. CONTROL VARIABLES
#-------------------------------------------------------------------------------

controls <- paste(c(
  "sunshine_hours_daily_avg", "sunshine_hours_daily_avg_sq",
  "rainfall_mm_daily_avg", "rainfall_mm_daily_avg_sq",
  "humidity_pct_daily_avg", "humidity_pct_daily_avg_sq",
  "windspeed_ms_daily_avg", "windspeed_ms_daily_avg_sq",
  "pm25_concentration", "income_per_capita", "num_pv_firms"
), collapse = " + ")

#-------------------------------------------------------------------------------
# 4. MODEL ESTIMATION
#-------------------------------------------------------------------------------

# --- Column (1): Maximum Temperature ---
col1_bs <- feols(
  as.formula(paste0(
    "log_install_bs ~ ",
    "temp_max_below_neg5 + temp_max_neg5_to_0 + temp_max_0_to_5 + ",
    "temp_max_5_to_10 + temp_max_10_to_15 + ",
    "temp_max_20_to_25 + temp_max_25_to_30 + temp_max_above_30 + ",
    controls, " | county_id + year^month"
  )),
  data = data_adoption, 
  cluster = ~county_id
)
saveRDS(col1_bs, file.path(path_models, "supp_table7_col1.RDS"))

# --- Column (2): County FE + Month FE ---
col2_bs <- feols(
  as.formula(paste0(
    "log_install_bs ~ ",
    "temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 + ",
    "temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 + ",
    controls, " | county_id + month"
  )),
  data = data_adoption, 
  cluster = ~county_id
)
saveRDS(col2_bs, file.path(path_models, "supp_table7_col2.RDS"))

# --- Column (3): Province FE + Year-by-month FE ---
col3_bs <- feols(
  as.formula(paste0(
    "log_install_bs ~ ",
    "temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 + ",
    "temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 + ",
    controls, " | province_id + year^month"
  )),
  data = data_adoption, 
  cluster = ~county_id
)
saveRDS(col3_bs, file.path(path_models, "supp_table7_col3.RDS"))

# --- Column (4): County FE + Year-by-month FE + Province-by-year FE ---
col4_bs <- feols(
  as.formula(paste0(
    "log_install_bs ~ ",
    "temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 + ",
    "temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 + ",
    controls, " | county_id + year^month + province_id^year"
  )),
  data = data_adoption, 
  cluster = ~county_id
)
saveRDS(col4_bs, file.path(path_models, "supp_table7_col4.RDS"))

# --- Column (5): Alternative Reference Bin (10-15°C) ---
# Prepare data for Alt Ref
temp_bins_alt_ref <- weather_daily %>%
  mutate(
    county_id = as.character(county_code),
    date = as.Date(date),
    year = year(date),
    month = month(date)
  ) %>%
  filter(year >= 2018 & year <= 2022) %>%
  mutate(
    temp_bin_alt = case_when(
      temp_avg_daily <= -5  ~ "below_neg5",
      temp_avg_daily > -5 & temp_avg_daily < 0  ~ "neg5_to_0",
      temp_avg_daily >= 0 & temp_avg_daily < 5  ~ "0_to_5",
      temp_avg_daily >= 5 & temp_avg_daily < 10 ~ "5_to_10",
      temp_avg_daily >= 15 & temp_avg_daily < 20 ~ "15_to_20",
      temp_avg_daily >= 20 & temp_avg_daily < 25 ~ "20_to_25",
      temp_avg_daily >= 25 & temp_avg_daily < 30 ~ "25_to_30",
      temp_avg_daily >= 30 ~ "above_30",
      TRUE ~ NA_character_
    )
  ) %>%
  group_by(county_id, year, month) %>%
  summarise(
    temp_alt_below_neg5 = sum(temp_bin_alt == "below_neg5", na.rm = TRUE),
    temp_alt_neg5_to_0  = sum(temp_bin_alt == "neg5_to_0", na.rm = TRUE),
    temp_alt_0_to_5     = sum(temp_bin_alt == "0_to_5", na.rm = TRUE),
    temp_alt_5_to_10    = sum(temp_bin_alt == "5_to_10", na.rm = TRUE),
    temp_alt_15_to_20   = sum(temp_bin_alt == "15_to_20", na.rm = TRUE),
    temp_alt_20_to_25   = sum(temp_bin_alt == "20_to_25", na.rm = TRUE),
    temp_alt_25_to_30   = sum(temp_bin_alt == "25_to_30", na.rm = TRUE),
    temp_alt_above_30   = sum(temp_bin_alt == "above_30", na.rm = TRUE),
    .groups = "drop"
  )

data_col5_bs <- data_adoption %>%
  left_join(temp_bins_alt_ref, by = c("county_id", "year", "month"))

col5_bs <- feols(
  as.formula(paste0(
    "log_install_bs ~ ",
    "temp_alt_below_neg5 + temp_alt_neg5_to_0 + temp_alt_0_to_5 + temp_alt_5_to_10 + ",
    "temp_alt_15_to_20 + temp_alt_20_to_25 + temp_alt_25_to_30 + temp_alt_above_30 + ",
    controls, " | county_id + year^month"
  )),
  data = data_col5_bs, 
  cluster = ~county_id
)
saveRDS(col5_bs, file.path(path_models, "supp_table7_col5.RDS"))

# --- Column (6): 3-Degree Bins (Ref: 12-15°C) ---
# Prepare data for 3-deg bins
temp_bins_3deg <- weather_daily %>%
  mutate(
    county_id = as.character(county_code),
    date = as.Date(date),
    year = year(date),
    month = month(date)
  ) %>%
  filter(year >= 2018 & year <= 2022) %>%
  mutate(
    temp_bin_3deg = case_when(
      temp_avg_daily < -6   ~ "below_neg6",
      temp_avg_daily >= -6 & temp_avg_daily < -3 ~ "neg6_to_neg3",
      temp_avg_daily >= -3 & temp_avg_daily < 0  ~ "neg3_to_0",
      temp_avg_daily >= 0 & temp_avg_daily < 3   ~ "0_to_3",
      temp_avg_daily >= 3 & temp_avg_daily < 6   ~ "3_to_6",
      temp_avg_daily >= 6 & temp_avg_daily < 9   ~ "6_to_9",
      temp_avg_daily >= 9 & temp_avg_daily < 12  ~ "9_to_12",
      temp_avg_daily >= 15 & temp_avg_daily < 18 ~ "15_to_18",
      temp_avg_daily >= 18 & temp_avg_daily < 21 ~ "18_to_21",
      temp_avg_daily >= 21 & temp_avg_daily < 24 ~ "21_to_24",
      temp_avg_daily >= 24 & temp_avg_daily < 27 ~ "24_to_27",
      temp_avg_daily >= 27 & temp_avg_daily < 30 ~ "27_to_30",
      temp_avg_daily >= 30 ~ "above_30",
      TRUE ~ NA_character_
    )
  ) %>%
  group_by(county_id, year, month) %>%
  summarise(
    temp_3deg_below_neg6 = sum(temp_bin_3deg == "below_neg6", na.rm = TRUE),
    temp_3deg_neg6_to_neg3 = sum(temp_bin_3deg == "neg6_to_neg3", na.rm = TRUE),
    temp_3deg_neg3_to_0 = sum(temp_bin_3deg == "neg3_to_0", na.rm = TRUE),
    temp_3deg_0_to_3 = sum(temp_bin_3deg == "0_to_3", na.rm = TRUE),
    temp_3deg_3_to_6 = sum(temp_bin_3deg == "3_to_6", na.rm = TRUE),
    temp_3deg_6_to_9 = sum(temp_bin_3deg == "6_to_9", na.rm = TRUE),
    temp_3deg_9_to_12 = sum(temp_bin_3deg == "9_to_12", na.rm = TRUE),
    temp_3deg_15_to_18 = sum(temp_bin_3deg == "15_to_18", na.rm = TRUE),
    temp_3deg_18_to_21 = sum(temp_bin_3deg == "18_to_21", na.rm = TRUE),
    temp_3deg_21_to_24 = sum(temp_bin_3deg == "21_to_24", na.rm = TRUE),
    temp_3deg_24_to_27 = sum(temp_bin_3deg == "24_to_27", na.rm = TRUE),
    temp_3deg_27_to_30 = sum(temp_bin_3deg == "27_to_30", na.rm = TRUE),
    temp_3deg_above_30 = sum(temp_bin_3deg == "above_30", na.rm = TRUE),
    .groups = "drop"
  )

data_col6_bs <- data_adoption %>%
  left_join(temp_bins_3deg, by = c("county_id", "year", "month"))

col6_bs <- feols(
  as.formula(paste0(
    "log_install_bs ~ ",
    "temp_3deg_below_neg6 + temp_3deg_neg6_to_neg3 + temp_3deg_neg3_to_0 + ",
    "temp_3deg_0_to_3 + temp_3deg_3_to_6 + temp_3deg_6_to_9 + temp_3deg_9_to_12 + ",
    "temp_3deg_15_to_18 + temp_3deg_18_to_21 + temp_3deg_21_to_24 + ",
    "temp_3deg_24_to_27 + temp_3deg_27_to_30 + temp_3deg_above_30 + ",
    controls, " | county_id + year^month"
  )),
  data = data_col6_bs, 
  cluster = ~county_id
)
saveRDS(col6_bs, file.path(path_models, "supp_table7_col6.RDS"))

# --- Column (7): Province-level Clustering ---
col7_bs <- feols(
  as.formula(paste0(
    "log_install_bs ~ ",
    "temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 + ",
    "temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 + ",
    controls, " | county_id + year^month"
  )),
  data = data_adoption, 
  cluster = ~province_id # Clustered at province level
)
saveRDS(col7_bs, file.path(path_models, "supp_table7_col7.RDS"))

#-------------------------------------------------------------------------------
# 5. TABLE GENERATION
#-------------------------------------------------------------------------------

models <- list(
  readRDS(file.path(path_models, "supp_table7_col1.RDS")),
  readRDS(file.path(path_models, "supp_table7_col2.RDS")),
  readRDS(file.path(path_models, "supp_table7_col3.RDS")),
  readRDS(file.path(path_models, "supp_table7_col4.RDS")),
  readRDS(file.path(path_models, "supp_table7_col5.RDS")),
  readRDS(file.path(path_models, "supp_table7_col6.RDS")),
  readRDS(file.path(path_models, "supp_table7_col7.RDS"))
)

# Extract coefficient function
get_coef <- function(model, varname) {
  coef_tbl <- summary(model)$coefficients
  if (!varname %in% rownames(coef_tbl)) return(c("", ""))
  est <- coef_tbl[varname, "Estimate"]
  se  <- coef_tbl[varname, "Std. Error"]
  pval <- coef_tbl[varname, "Pr(>|t|)"]
  stars <- case_when(
    pval < 0.01 ~ "***", 
    pval < 0.05 ~ "**", 
    pval < 0.10 ~ "*", 
    TRUE ~ ""
  )
  c(sprintf("%.3f%s", est, stars), sprintf("(%.3f)", se))
}

# Define variable list to match the table content provided
var_list <- list(
  baseline = list(
    # Mapping "below 0" effectively to the standard "below -5" for now, or use -5-0 if that's preferred.
    # Given robustness check descriptions are identical, I'll list the standard set.
    list(label = "# of days below -5 ℃", 
         vars = c("temp_max_below_neg5", "temp_below_neg5", "temp_below_neg5", 
                  "temp_below_neg5", "temp_alt_below_neg5", NA, "temp_below_neg5")),
    list(label = "# of days -5-0 ℃",
         vars = c("temp_max_neg5_to_0", "temp_neg5_to_0", "temp_neg5_to_0",
                  "temp_neg5_to_0", "temp_alt_neg5_to_0", NA, "temp_neg5_to_0")),
    list(label = "# of days 0-5 ℃",
         vars = c("temp_max_0_to_5", "temp_0_to_5", "temp_0_to_5",
                  "temp_0_to_5", "temp_alt_0_to_5", NA, "temp_0_to_5")),
    list(label = "# of days 25-30 ℃",
         vars = c("temp_max_25_to_30", "temp_25_to_30", "temp_25_to_30",
                  "temp_25_to_30", "temp_alt_25_to_30", NA, "temp_25_to_30")),
    list(label = "# of days above 30 ℃",
         vars = c("temp_max_above_30", "temp_above_30", "temp_above_30",
                  "temp_above_30", "temp_alt_above_30", NA, "temp_above_30"))
  ),
  alternative = list(
    list(label = "# of days below -6 ℃",
         vars = c(NA, NA, NA, NA, NA, "temp_3deg_below_neg6", NA)),
    list(label = "# of days -6-3 ℃", # Note: Represents -6 to -3 range
         vars = c(NA, NA, NA, NA, NA, "temp_3deg_neg6_to_neg3", NA)),
    list(label = "# of days 27-30 ℃",
         vars = c(NA, NA, NA, NA, NA, "temp_3deg_27_to_30", NA)),
    list(label = "# of days above 30 ℃",
         vars = c(NA, NA, NA, NA, NA, "temp_3deg_above_30", NA))
  )
)

# Build table data
tbl_data <- tibble(Variable = character())

for (row in var_list$baseline) {
  coef_row <- c(row$label, rep("", 7))
  se_row   <- c("", rep("", 7))
  for (col_idx in 1:7) {
    if (!is.na(row$vars[col_idx])) {
      result <- get_coef(models[[col_idx]], row$vars[col_idx])
      coef_row[col_idx + 1] <- result[1]
      se_row[col_idx + 1]   <- result[2]
    }
  }
  tbl_data <- tbl_data %>%
    bind_rows(tibble(Variable = coef_row[1], 
                     `(1)` = coef_row[2], `(2)` = coef_row[3], `(3)` = coef_row[4],
                     `(4)` = coef_row[5], `(5)` = coef_row[6], `(6)` = coef_row[7], 
                     `(7)` = coef_row[8])) %>%
    bind_rows(tibble(Variable = se_row[1],
                     `(1)` = se_row[2], `(2)` = se_row[3], `(3)` = se_row[4],
                     `(4)` = se_row[5], `(5)` = se_row[6], `(6)` = se_row[7], 
                     `(7)` = se_row[8]))
}

for (row in var_list$alternative) {
  coef_row <- c(row$label, rep("", 7))
  se_row   <- c("", rep("", 7))
  for (col_idx in 1:7) {
    if (!is.na(row$vars[col_idx])) {
      result <- get_coef(models[[col_idx]], row$vars[col_idx])
      coef_row[col_idx + 1] <- result[1]
      se_row[col_idx + 1]   <- result[2]
    }
  }
  tbl_data <- tbl_data %>%
    bind_rows(tibble(Variable = coef_row[1],
                     `(1)` = coef_row[2], `(2)` = coef_row[3], `(3)` = coef_row[4],
                     `(4)` = coef_row[5], `(5)` = coef_row[6], `(6)` = coef_row[7], 
                     `(7)` = coef_row[8])) %>%
    bind_rows(tibble(Variable = se_row[1],
                     `(1)` = se_row[2], `(2)` = se_row[3], `(3)` = se_row[4],
                     `(4)` = se_row[5], `(5)` = se_row[6], `(6)` = se_row[7], 
                     `(7)` = se_row[8]))
}

# Add observations
tbl_data <- tbl_data %>%
  bind_rows(tibble(
    Variable = "Obs.",
    `(1)` = format(nobs(models[[1]]), big.mark = ","),
    `(2)` = format(nobs(models[[2]]), big.mark = ","),
    `(3)` = format(nobs(models[[3]]), big.mark = ","),
    `(4)` = format(nobs(models[[4]]), big.mark = ","),
    `(5)` = format(nobs(models[[5]]), big.mark = ","),
    `(6)` = format(nobs(models[[6]]), big.mark = ","),
    `(7)` = format(nobs(models[[7]]), big.mark = ",")
  ))

# Add control variables
tbl_data <- tbl_data %>%
  bind_rows(tibble(
    Variable = "Control variables", 
    `(1)` = "✓", `(2)` = "✓", `(3)` = "✓",
    `(4)` = "✓", `(5)` = "✓", `(6)` = "✓", `(7)` = "✓"
  ))

# Add fixed effects
fe_specs <- tribble(
  ~Variable,              ~`(1)`, ~`(2)`, ~`(3)`, ~`(4)`, ~`(5)`, ~`(6)`, ~`(7)`,
  "County FE",            "✓",    "✓",    "",     "✓",    "✓",    "✓",    "✓",
  "Province FE",          "",     "",     "✓",    "",     "",     "",     "",
  "Month FE",             "",     "✓",    "",     "",     "",     "",     "",
  "Year-by-month FE",     "✓",    "",     "✓",    "✓",    "✓",    "✓",    "✓",
  "Province-by-year FE",  "",     "",     "",     "✓",    "",     "",     ""
)

tbl_data <- tbl_data %>% bind_rows(fe_specs)

# Add clustering level
tbl_data <- tbl_data %>%
  bind_rows(tibble(
    Variable = "Standard error clustering level",
    `(1)` = "County", `(2)` = "County", `(3)` = "County",
    `(4)` = "County", `(5)` = "County", `(6)` = "County", `(7)` = "Province"
  ))

# Format with flextable
ft <- flextable(tbl_data) %>%
  set_header_labels(
    Variable = "",
    `(1)` = "(1)", `(2)` = "(2)", `(3)` = "(3)",
    `(4)` = "(4)", `(5)` = "(5)", `(6)` = "(6)", `(7)` = "(7)"
  ) %>%
  width(j = 1, width = 3.5) %>%
  width(j = 2:8, width = 0.9) %>%
  align(j = 2:8, align = "center", part = "all") %>%
  align(j = 1, align = "left", part = "body") %>%
  bold(part = "header") %>%
  padding(i = which(tbl_data$Variable == ""), j = 1, padding.left = 20) %>%
  hline_top(border = fp_border(width = 2), part = "header") %>%
  hline_bottom(border = fp_border(width = 2), part = "header") %>%
  hline(i = nrow(tbl_data) - 6, border = fp_border(width = 1)) %>%
  hline_bottom(border = fp_border(width = 2), part = "body") %>%
  fontsize(size = 10, part = "all") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  set_caption(
    caption = as_paragraph(
      as_b("Supplementary Table 7. "),
      "Robustness checks of temperature effects on RRPV-BS adoption"
    ),
    align_with_table = FALSE
  )

doc <- read_docx() %>%
  body_add_flextable(value = ft) %>%
  body_end_section_landscape()

output_path <- file.path(path_output, "Supplementary_Table_7.docx")
print(doc, target = output_path)

#===============================================================================
# END OF SCRIPT
#===============================================================================
