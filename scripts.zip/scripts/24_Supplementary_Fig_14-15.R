#===============================================================================
# Supplementary Figs. 14 & 15: Validation of PV generation model
#
# Description:
# This script validates the predictive power of the PV generation model used
# in the economic returns analysis. The model parameters are estimated using
# empirical engineering equations (Equations 9-17 in Methods) that link daily
# PV generation to household-specific installation capacity and meteorological
# variables (solar radiation, temperature, wind speed) from bias-corrected
# CMIP6 projections under SSP2.
#
# Supplementary Fig. 14 compares model-predicted daily generation against
# observed generation over 2018-2020, showing high correspondence with R² = 0.83.
# Supplementary Fig. 15 presents a household-day level scatter plot with
# 1:1 reference line, LOESS smoother, and summary metrics (R², RMSE, MAE, bias).
#
#===============================================================================

library(tidyverse)
library(ggplot2)
library(lubridate)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root   <- "D:/rooftop"
path_elec   <- file.path(path_root, "electricity")
path_output <- file.path(path_root, "return/results")
fig_dir     <- file.path(path_root, "Fig")

#-------------------------------------------------------------------------------
# 2. LOAD DATA
#-------------------------------------------------------------------------------

# Observed household-level generation panel (2018-06-01 to 2020-12-31)
data_rrpv_obs <- readRDS(file.path(path_elec, "rrpv_electricity_panel.RDS"))

# Predicted household-level daily generation (E_total_t)
future_gen_rrpv <- readRDS(file.path(path_output, "future_generation_rrpv.RDS"))

# Restrict to overlapping time range of observed data
time_min <- min(as.Date(data_rrpv_obs$time))
time_max <- max(as.Date(data_rrpv_obs$time))

future_gen_rrpv <- future_gen_rrpv %>%
  mutate(time = as.Date(time)) %>%
  filter(time >= time_min, time <= time_max)

#-------------------------------------------------------------------------------
# 3. PREPARE DATA FOR PLOTTING
#-------------------------------------------------------------------------------

# (1) Daily average generation per household (for time series, Supp Fig. 15)
obs_daily <- data_rrpv_obs %>%
  group_by(time) %>%
  summarise(
    observed_avg_kwh = mean(total_generation_kwh, na.rm = TRUE),
    .groups = "drop"
  )

pred_daily <- future_gen_rrpv %>%
  group_by(time) %>%
  summarise(
    predicted_avg_kwh = mean(E_total_t, na.rm = TRUE),
    .groups = "drop"
  )

ts_daily <- obs_daily %>%
  inner_join(pred_daily, by = "time") %>%
  rename(Date = time)

# (2) Household-day level data for scatter plot (Supp Fig. 16)
obs_pred_hhday <- data_rrpv_obs %>%
  select(household_id, time, observed_kwh = total_generation_kwh) %>%
  inner_join(
    future_gen_rrpv %>%
      select(household_id, time, predicted_kwh = E_total_t),
    by = c("household_id", "time")
  ) %>%
  mutate(
    observed_kwh  = as.numeric(observed_kwh),
    predicted_kwh = as.numeric(predicted_kwh)
  ) %>%
  filter(!is.na(observed_kwh), !is.na(predicted_kwh))

#-------------------------------------------------------------------------------
# 4. COMPUTE VALIDATION METRICS
#-------------------------------------------------------------------------------

residuals_vec <- obs_pred_hhday$predicted_kwh - obs_pred_hhday$observed_kwh

rmse_val <- sqrt(mean(residuals_vec^2, na.rm = TRUE))
mae_val  <- mean(abs(residuals_vec), na.rm = TRUE)
bias_val <- mean(residuals_vec, na.rm = TRUE)
r2_val   <- cor(obs_pred_hhday$predicted_kwh,
                obs_pred_hhday$observed_kwh,
                use = "complete.obs")^2

metrics_label <- sprintf(
  "R² = %.3f\nRMSE = %.3f kWh\nMAE = %.3f kWh\nBias = %.3f kWh",
  r2_val, rmse_val, mae_val, bias_val
)

#-------------------------------------------------------------------------------
# 5. COMMON PLOTTING THEME AND COLORS
#-------------------------------------------------------------------------------

base_theme <- theme_minimal(base_size = 20) +
  theme(
    panel.background  = element_rect(fill = "white", colour = NA),
    plot.background   = element_rect(fill = "white", colour = NA),
    axis.text         = element_text(size = 16, colour = "black"),
    axis.title        = element_text(size = 18, colour = "black"),
    axis.line         = element_line(linewidth = 0.6, colour = "black"),
    axis.ticks        = element_line(linewidth = 0.6, colour = "black"),
    axis.ticks.length = unit(0.2, "cm"),
    panel.grid.major  = element_blank(),
    panel.grid.minor  = element_blank(),
    legend.position   = "top",
    legend.title      = element_blank(),
    legend.text       = element_text(size = 18)
  )

# Colors
col_observed  <- "#1f77b4"  
col_predicted <- "#ff7f0e"  
col_11line    <- "#d62728"  
col_loess     <- "#ff7f0e"  

#-------------------------------------------------------------------------------
# 6. SUPPLEMENTARY FIG. 15 – TIME SERIES
#-------------------------------------------------------------------------------

ts_long <- ts_daily %>%
  pivot_longer(
    cols = c(observed_avg_kwh, predicted_avg_kwh),
    names_to = "Series",
    values_to = "Generation"
  ) %>%
  mutate(
    Series = factor(
      Series,
      levels = c("observed_avg_kwh", "predicted_avg_kwh"),
      labels = c("Observed", "Predicted")
    )
  )

supp15 <- ggplot(ts_long, aes(x = Date, y = Generation, colour = Series, linetype = Series)) +
  geom_line(linewidth = 0.7) +
  scale_colour_manual(
    values = c("Observed" = col_observed, "Predicted" = col_predicted)
  ) +
  scale_linetype_manual(
    values = c("Observed" = "solid", "Predicted" = "dashed")
  ) +
  labs(
    x = "Date",
    y = "Average daily generation (kWh per household)"
  ) +
  base_theme +
  theme(
    legend.position   = "top",
    legend.direction  = "horizontal",
    legend.justification = "center"
  )

# PDF
ggsave(
  filename = file.path(fig_dir, "Supplementary_Fig_14.pdf"),
  plot = supp15, 
  width = 10, height = 4.5, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(fig_dir, "Supplementary_Fig_14.png"),
  plot = supp15, 
  width = 10, height = 4.5, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)

#-------------------------------------------------------------------------------
# 7. SUPPLEMENTARY FIG. 16 – SCATTER PLOT WITH METRICS
#-------------------------------------------------------------------------------

# Determine annotation position (top-left corner)
x_min <- min(obs_pred_hhday$observed_kwh,  na.rm = TRUE)
x_max <- max(obs_pred_hhday$observed_kwh,  na.rm = TRUE)
y_min <- min(obs_pred_hhday$predicted_kwh, na.rm = TRUE)
y_max <- max(obs_pred_hhday$predicted_kwh, na.rm = TRUE)

x_annot <- x_min + 0.03 * (x_max - x_min)
y_annot <- y_max - 0.03 * (y_max - y_min)

supp16 <- ggplot(obs_pred_hhday, aes(x = observed_kwh, y = predicted_kwh)) +
  geom_point(alpha = 0.25, size = 1.3, colour = col_observed) +
  geom_abline(
    slope = 1, 
    intercept = 0, 
    linetype = "dashed",
    colour = col_11line, 
    linewidth = 1
  ) +
  geom_smooth(
    method = "loess", 
    se = FALSE,
    colour = col_loess, 
    linewidth = 1
  ) +
  annotate(
    "text",
    x = x_annot, 
    y = y_annot,
    label = metrics_label,
    hjust = 0, 
    vjust = 1,
    size = 5
  ) +
  labs(
    x = "Observed generation (kWh)",
    y = "Predicted generation (kWh)"
  ) +
  base_theme +
  theme(legend.position = "none")

# PDF
ggsave(
  filename = file.path(fig_dir, "Supplementary_Fig_15.pdf"),
  plot = supp16, 
  width = 8, height = 8, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(fig_dir, "Supplementary_Fig_15.png"),
  plot = supp16, 
  width = 8, height = 8, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)


#===============================================================================
# END OF SCRIPT
#===============================================================================
