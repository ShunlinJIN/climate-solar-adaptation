#===============================================================================
# CMIP6 Climate Data Processing Script
#
# Description: This script processes raw CMIP6 gridded climate data (NetCDF format)
#              and generates bias-corrected county-level daily climate variables
#              for PV modeling. It applies the ISI-MIP trend-preserving 
#              bias correction method (Hempel et al., 2013) and computes multi-model 
#              ensemble means.
#===============================================================================

library(tidyverse)
library(terra)
library(sf)
library(exactextractr)
library(lubridate)

# --- Paths ---
path_root    <- "D:/rooftop"
path_climate <- file.path(path_root, "climate/cmip6")
path_shp     <- file.path(path_root, "county_boundaries.shp")
path_output  <- file.path(path_root, "return")

#-------------------------------------------------------------------------------
# 1. LOAD SPATIAL DATA
#-------------------------------------------------------------------------------

counties_sf <- st_read(path_shp, quiet = TRUE) %>%
  mutate(county_id = as.character(COUNTY_ID)) %>%
  select(county_id, geometry) %>%
  st_transform(crs = "EPSG:4326")

#-------------------------------------------------------------------------------
# 2. DEFINE CLIMATE MODELS AND SCENARIOS
#-------------------------------------------------------------------------------

cmip6_models <- c(
  "ACCESS-CM2", "ACCESS-ESM1-5", "AWI-CM-1-1-MR", "BCC-CSM2-MR",
  "CAMS-CSM1-0", "CanESM5", "CESM2", "CESM2-WACCM", "CMCC-CM2-SR5",
  "CNRM-CM6-1", "CNRM-ESM2-1", "EC-Earth3", "EC-Earth3-Veg",
  "FGOALS-f3-L", "FGOALS-g3", "FIO-ESM-2-0", "GFDL-ESM4",
  "GISS-E2-1-G", "HadGEM3-GC31-LL", "INM-CM4-8", "INM-CM5-0",
  "IPSL-CM6A-LR", "KACE-1-0-G", "MIROC6", "MIROC-ES2L",
  "MPI-ESM1-2-HR", "MPI-ESM1-2-LR", "MRI-ESM2-0", "NESM3",
  "NorESM2-LM", "NorESM2-MM"
)

scenarios <- c("SSP1-2.6", "SSP2-4.5", "SSP5-8.5")

vars_map <- list(
  "rsds"    = "solar",
  "tas"     = "temp",
  "sfcWind" = "wind"
)

#-------------------------------------------------------------------------------
# 3. LOAD OBSERVED CLIMATOLOGY (1981-2014 BASELINE)
#-------------------------------------------------------------------------------

weather_obs <- readRDS(file.path(path_root, "weather_daily_county.RDS")) %>%
  mutate(
    county_id = as.character(county_code),
    date = as.Date(date)
  ) %>%
  filter(year(date) >= 1981 & year(date) <= 2014)

calc_monthly_stats <- function(data, val_col) {
  data %>%
    mutate(month = month(date)) %>%
    group_by(county_id, month) %>%
    summarise(
      mu = mean(.data[[val_col]], na.rm = TRUE),
      sd = sd(.data[[val_col]], na.rm = TRUE),
      .groups = "drop"
    )
}

obs_stats <- list(
  solar = calc_monthly_stats(weather_obs, "solar_radiation_wm2"),
  temp  = calc_monthly_stats(weather_obs, "temp_avg_daily_c"),
  wind  = calc_monthly_stats(weather_obs, "wind_speed_ms")
)

rm(weather_obs); gc()

#-------------------------------------------------------------------------------
# 4. HELPER FUNCTIONS
#-------------------------------------------------------------------------------

process_nc_to_county <- function(nc_path, var_name, counties_sf) {
  
  if (!file.exists(nc_path)) return(NULL)
  
  r <- tryCatch(rast(nc_path, subds = var_name), error = function(e) NULL)
  if (is.null(r)) return(NULL)
  
  r_times <- time(r)
  if (all(is.na(r_times))) return(NULL)
  
  vals <- exact_extract(r, counties_sf, 'weighted_mean', 
                        weights = 'area', progress = FALSE)
  
  mat <- t(vals)
  colnames(mat) <- counties_sf$county_id
  
  df <- as_tibble(mat) %>%
    mutate(date = as.Date(r_times)) %>%
    pivot_longer(-date, names_to = "county_id", values_to = "value")
  
  return(df)
}

perform_bias_correction <- function(raw_data, mod_stats_hist, 
                                    obs_stats, var_type) {
  
  raw_data %>%
    mutate(month = month(date)) %>%
    left_join(mod_stats_hist, by = c("county_id", "month"), 
              suffix = c("", "_mod")) %>%
    left_join(obs_stats, by = c("county_id", "month"), 
              suffix = c("", "_obs")) %>%
    mutate(
      mu_mod = ifelse(abs(mu_mod) < 1e-5, 1e-5, mu_mod),
      mu_obs = ifelse(abs(mu_obs) < 1e-5, 1e-5, mu_obs),
      sd_mod = ifelse(sd_mod < 1e-5, 1e-5, sd_mod),
      
      val_bc_mean = case_when(
        var_type == "temp" ~ value - mu_mod + mu_obs,
        TRUE               ~ value * (mu_obs / mu_mod)
      ),
      
      anomaly = case_when(
        var_type == "temp" ~ val_bc_mean - mu_obs,
        TRUE               ~ (val_bc_mean - mu_obs) / mu_obs
      ),
      
      sd_ratio = sd_obs / sd_mod,
      anomaly_scaled = anomaly * sd_ratio,
      
      value_corrected = case_when(
        var_type == "temp" ~ mu_obs + anomaly_scaled,
        TRUE               ~ mu_obs * (1 + anomaly_scaled)
      ),
      
      value_corrected = if_else(
        var_type != "temp" & value_corrected < 0, 
        0, value_corrected
      )
    ) %>%
    select(county_id, date, value = value_corrected)
}

#-------------------------------------------------------------------------------
# 5. PROCESS CLIMATE DATA BY MODEL
#-------------------------------------------------------------------------------

acc_data <- list(
  Historical = list(solar = NULL, temp = NULL, wind = NULL),
  `SSP1-2.6` = list(solar = NULL, temp = NULL, wind = NULL),
  `SSP2-4.5` = list(solar = NULL, temp = NULL, wind = NULL),
  `SSP5-8.5` = list(solar = NULL, temp = NULL, wind = NULL)
)

ensemble_counts <- list(Historical = 0, `SSP1-2.6` = 0, 
                        `SSP2-4.5` = 0, `SSP5-8.5` = 0)

for (model in cmip6_models) {
  
  mod_hist_stats <- list()
  valid_model <- TRUE
  
  for (v_nc in names(vars_map)) {
    v_type <- vars_map[[v_nc]]
    
    f_hist <- file.path(path_climate, "historical", 
                        paste0(model, "_historical_", v_nc, ".nc"))
    raw_hist <- process_nc_to_county(f_hist, v_nc, counties_sf)
    
    if (is.null(raw_hist)) {
      valid_model <- FALSE
      break
    }
    
    raw_hist_base <- raw_hist %>% 
      filter(year(date) >= 1981 & year(date) <= 2014)
    
    if (nrow(raw_hist_base) == 0) {
      valid_model <- FALSE
      break
    }
    
    mod_hist_stats[[v_type]] <- raw_hist_base %>%
      mutate(month = month(date)) %>%
      group_by(county_id, month) %>%
      summarise(
        mu_mod = mean(value, na.rm = TRUE),
        sd_mod = sd(value, na.rm = TRUE),
        .groups = "drop"
      )
    
    corrected_hist <- perform_bias_correction(
      raw_hist_base, mod_hist_stats[[v_type]], 
      obs_stats[[v_type]], v_type
    )
    
    if (is.null(acc_data[["Historical"]][[v_type]])) {
      acc_data[["Historical"]][[v_type]] <- corrected_hist
    } else {
      acc_data[["Historical"]][[v_type]] <- 
        bind_rows(acc_data[["Historical"]][[v_type]], corrected_hist) %>%
        group_by(county_id, date) %>%
        summarise(value = sum(value, na.rm = TRUE), .groups = "drop")
    }
    
    rm(raw_hist, raw_hist_base, corrected_hist); gc()
  }
  
  if (!valid_model) next
  
  ensemble_counts[["Historical"]] <- ensemble_counts[["Historical"]] + 1
  
  for (scen in scenarios) {
    for (v_nc in names(vars_map)) {
      v_type <- vars_map[[v_nc]]
      
      f_fut <- file.path(path_climate, scen, 
                         paste0(model, "_", scen, "_", v_nc, ".nc"))
      
      if (file.exists(f_fut) && !is.null(mod_hist_stats[[v_type]])) {
        
        raw_fut <- process_nc_to_county(f_fut, v_nc, counties_sf)
        if (is.null(raw_fut)) next
        
        raw_fut <- raw_fut %>% 
          filter(year(date) >= 2021 & year(date) <= 2065)
        
        corrected_fut <- perform_bias_correction(
          raw_fut, mod_hist_stats[[v_type]], 
          obs_stats[[v_type]], v_type
        )
        
        if (is.null(acc_data[[scen]][[v_type]])) {
          acc_data[[scen]][[v_type]] <- corrected_fut
        } else {
          acc_data[[scen]][[v_type]] <- 
            bind_rows(acc_data[[scen]][[v_type]], corrected_fut) %>%
            group_by(county_id, date) %>%
            summarise(value = sum(value, na.rm = TRUE), .groups = "drop")
        }
        
        rm(raw_fut, corrected_fut); gc()
      }
    }
    ensemble_counts[[scen]] <- ensemble_counts[[scen]] + 1
  }
  
  rm(mod_hist_stats); gc()
}

#-------------------------------------------------------------------------------
# 6. COMPUTE ENSEMBLE MEAN AND SAVE FINAL DATASETS
#-------------------------------------------------------------------------------

save_ensemble <- function(data_list, count, label) {
  if (count == 0) return(NULL)
  
  df_solar <- data_list$solar %>% mutate(I_t = value / count) %>% select(-value)
  df_temp  <- data_list$temp  %>% mutate(T_t = value / count) %>% select(-value)
  df_wind  <- data_list$wind  %>% mutate(v_t = value / count) %>% select(-value)
  
  final_df <- df_solar %>%
    left_join(df_temp, by = c("county_id", "date")) %>%
    left_join(df_wind, by = c("county_id", "date")) %>%
    rename(time = date)
  
  return(final_df)
}

cmip6_historical <- save_ensemble(
  acc_data[["Historical"]], 
  ensemble_counts[["Historical"]], 
  "Historical"
)

saveRDS(cmip6_historical, 
        file.path(path_output, "cmip6_historical_climate.RDS"))

for (scen in scenarios) {
  cmip6_future <- save_ensemble(
    acc_data[[scen]], 
    ensemble_counts[[scen]], 
    scen
  )
  
  if (!is.null(cmip6_future)) {
    saveRDS(cmip6_future, 
            file.path(path_output, paste0("cmip6_future_climate_", scen, ".RDS")))
    
    if (scen == "SSP2-4.5") {
      saveRDS(cmip6_future, 
              file.path(path_output, "cmip6_future_climate.RDS"))
    }
  }
}

#===============================================================================
# END OF SCRIPT
#===============================================================================
