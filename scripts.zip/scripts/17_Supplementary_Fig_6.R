#===============================================================================
# Supplementary Fig. 6: Temperature and Baidu search activity
#
# Description: 
# 1. Aggregate Baidu search data to weekly and monthly levels
# 2. Estimate temperature-search response model
# 3. Generate Supplementary Fig. 6 (panels a and b)
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(fixest)
library(ggplot2)
library(ggprism)
library(patchwork)
library(lubridate)
library(scales)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root  <- "D:/rooftop"
output_dir <- file.path(path_root, "Fig")

# Text size parameters
text_size_axis_text       <- 20
text_size_axis_title      <- 24
text_size_legend_text     <- 20
text_size_plot_tag        <- 26
text_size_x_axis_bar_plot <- 18

# Common plotting theme
common_plot_theme <- function() {
  theme_prism() +
    theme(
      axis.text        = element_text(size = text_size_axis_text,  face = "plain", color = "black"),
      axis.title       = element_text(size = text_size_axis_title, face = "plain", color = "black"),
      axis.ticks       = element_line(linewidth = 0.5, color = "black"),
      axis.line        = element_line(linewidth = 0.5, color = "black"),
      legend.position  = "top",
      legend.text      = element_text(size = text_size_legend_text, color = "black"),
      legend.title     = element_blank(),
      plot.title       = element_text(hjust = 0.5, size = text_size_axis_title),
      plot.tag.position = "topleft",
      plot.tag         = element_text(face = "bold", size = text_size_plot_tag)
    )
}

#-------------------------------------------------------------------------------
# 2. DATA PREPARATION (WEATHER AND SEARCH)
#-------------------------------------------------------------------------------

# Daily weather data (county level)
weather_daily <- readRDS(file.path(path_root, "weather_daily_county.RDS"))

weather_daily <- weather_daily %>%
  mutate(
    county_id = as.character(county_code),
    date      = as.Date(date)
  ) %>%
  filter(year(date) >= 2018 & year(date) <= 2022)

# National daily average temperature (for panel a)
national_daily_temp <- weather_daily %>%
  group_by(date) %>%
  summarise(
    temp_avg_celsius = mean(temp_avg_daily, na.rm = TRUE),
    .groups = "drop"
  )

# Baidu daily search data (county level)
baidu_daily <- read_csv(
  file.path(path_root, "search/baidu_search_index.csv"),
  show_col_types = FALSE
)

baidu_daily <- baidu_daily %>%
  mutate(
    county_id = as.character(county_code),
    date      = as.Date(date)
  ) %>%
  filter(year(date) >= 2018 & year(date) <= 2022)

#-------------------------------------------------------------------------------
# 2.1 WEEKLY AND MONTHLY SERIES FOR PANEL (a)
#-------------------------------------------------------------------------------

# Weekly temperature
weekly_data <- national_daily_temp %>%
  mutate(
    year = year(date),
    week = isoweek(date)
  ) %>%
  group_by(year, week) %>%
  summarise(
    week_start_date = min(date),
    temp_avg_weekly = mean(temp_avg_celsius, na.rm = TRUE),
    .groups = "drop"
  )

# Weekly national Baidu index (average across counties)
baidu_weekly <- baidu_daily %>%
  mutate(
    year = year(date),
    week = isoweek(date)
  ) %>%
  group_by(year, week) %>%
  summarise(
    baidu_index_weekly = mean(baidu_index, na.rm = TRUE),
    .groups = "drop"
  )

weekly_data <- weekly_data %>%
  left_join(baidu_weekly, by = c("year", "week"))

# Monthly national Baidu index (for smooth line in panel a)
baidu_monthly_nat <- baidu_daily %>%
  mutate(
    year  = year(date),
    month = month(date)
  ) %>%
  group_by(year, month) %>%
  summarise(
    baidu_index_monthly = mean(baidu_index, na.rm = TRUE),
    .groups = "drop"
  )

weekly_data <- weekly_data %>%
  mutate(
    year_month_start = floor_date(week_start_date, "month")
  ) %>%
  left_join(
    baidu_monthly_nat %>%
      mutate(year_month_start = as.Date(paste(year, month, "01", sep = "-"))),
    by = "year_month_start"
  )

#-------------------------------------------------------------------------------
# 3. DATA PREPARATION FOR REGRESSION MODEL (COUNTY–MONTH PANEL)
#-------------------------------------------------------------------------------

# Monthly Baidu index at county level (for regression)
baidu_monthly_full <- baidu_daily %>%
  mutate(
    year  = year(date),
    month = month(date)
  ) %>%
  group_by(county_id, year, month) %>%
  summarise(
    baidu_index     = mean(baidu_index, na.rm = TRUE),
    log_baidu_index = log(1 + mean(baidu_index, na.rm = TRUE)),
    .groups = "drop"
  )

# Monthly county-level weather with temperature bins
county_monthly_weather <- weather_daily %>%
  mutate(
    year     = year(date),
    month    = month(date),
    temp_bin = case_when(
      temp_avg_daily <= -5                        ~ "temp_below_neg5",
      temp_avg_daily > -5  & temp_avg_daily < 0   ~ "temp_neg5_to_0",
      temp_avg_daily >= 0 & temp_avg_daily < 5    ~ "temp_0_to_5",
      temp_avg_daily >= 5 & temp_avg_daily < 10   ~ "temp_5_to_10",
      temp_avg_daily >= 10 & temp_avg_daily < 15  ~ "temp_10_to_15",
      temp_avg_daily >= 15 & temp_avg_daily < 20  ~ "temp_15_to_20",
      temp_avg_daily >= 20 & temp_avg_daily < 25  ~ "temp_20_to_25",
      temp_avg_daily >= 25 & temp_avg_daily < 30  ~ "temp_25_to_30",
      temp_avg_daily >= 30                        ~ "temp_above_30",
      TRUE                                        ~ NA_character_
    )
  ) %>%
  group_by(county_id, year, month) %>%
  summarise(
    temp_below_neg5 = sum(temp_bin == "temp_below_neg5", na.rm = TRUE),
    temp_neg5_to_0  = sum(temp_bin == "temp_neg5_to_0",  na.rm = TRUE),
    temp_0_to_5     = sum(temp_bin == "temp_0_to_5",     na.rm = TRUE),
    temp_5_to_10    = sum(temp_bin == "temp_5_to_10",    na.rm = TRUE),
    temp_10_to_15   = sum(temp_bin == "temp_10_to_15",   na.rm = TRUE),
    temp_15_to_20   = sum(temp_bin == "temp_15_to_20",   na.rm = TRUE),
    temp_20_to_25   = sum(temp_bin == "temp_20_to_25",   na.rm = TRUE),
    temp_25_to_30   = sum(temp_bin == "temp_25_to_30",   na.rm = TRUE),
    temp_above_30   = sum(temp_bin == "temp_above_30",   na.rm = TRUE),
    
    sunshine_hours_daily_avg = mean(sunshine_duration,  na.rm = TRUE),
    rainfall_mm_daily_avg    = mean(precipitation,      na.rm = TRUE),
    humidity_pct_daily_avg   = mean(relative_humidity,  na.rm = TRUE),
    windspeed_ms_daily_avg   = mean(wind_speed,         na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    sunshine_hours_daily_avg_sq = sunshine_hours_daily_avg^2,
    rainfall_mm_daily_avg_sq    = rainfall_mm_daily_avg^2,
    humidity_pct_daily_avg_sq   = humidity_pct_daily_avg^2,
    windspeed_ms_daily_avg_sq   = windspeed_ms_daily_avg^2
  )

# Monthly county-level PM2.5
pm25_monthly <- readRDS(file.path(path_root, "pm25_monthly.RDS"))

county_monthly_pm25 <- pm25_monthly %>%
  mutate(
    county_id = as.character(county_code),
    date      = as.Date(date),
    year      = year(date),
    month     = month(date)
  ) %>%
  group_by(county_id, year, month) %>%
  summarise(
    pm25_concentration = mean(pm25_concentration, na.rm = TRUE),
    .groups = "drop"
  )

# Regression dataset: county–month panel
regression_data <- baidu_monthly_full %>%
  left_join(county_monthly_weather, by = c("county_id", "year", "month")) %>%
  left_join(county_monthly_pm25,    by = c("county_id", "year", "month")) %>%
  filter(!is.na(baidu_index))

#-------------------------------------------------------------------------------
# 4. MODEL ESTIMATION AND COEFFICIENT PREPARATION
#-------------------------------------------------------------------------------

temp_bins_vars <- c(
  "temp_below_neg5",
  "temp_neg5_to_0",
  "temp_0_to_5",
  "temp_5_to_10",
  "temp_10_to_15",
  "temp_20_to_25",
  "temp_25_to_30",
  "temp_above_30"
)

eq_supp_baidu <- feols(
  log_baidu_index ~ 
    temp_below_neg5 + temp_neg5_to_0 + temp_0_to_5 + temp_5_to_10 +
    temp_10_to_15 + temp_20_to_25 + temp_25_to_30 + temp_above_30 +
    sunshine_hours_daily_avg + sunshine_hours_daily_avg_sq +
    rainfall_mm_daily_avg    + rainfall_mm_daily_avg_sq +
    humidity_pct_daily_avg   + humidity_pct_daily_avg_sq +
    windspeed_ms_daily_avg   + windspeed_ms_daily_avg_sq +
    pm25_concentration |
    county_id + year^month,
  data    = regression_data,
  cluster = ~county_id
)

extract_coef_ci <- function(model, vars) {
  coefs <- coef(model)[vars]
  ci    <- confint(model, level = 0.95)[vars, ]
  data.frame(
    variable = vars,
    coef     = coefs,
    lower_ci = ci[, 1],
    upper_ci = ci[, 2],
    row.names = NULL
  )
}

fig6b_coefs <- extract_coef_ci(eq_supp_baidu, temp_bins_vars) %>%
  add_row(
    variable = "temp_15_to_20",
    coef     = 0,
    lower_ci = 0,
    upper_ci = 0,
    .before  = 6
  )

# Temperature distribution (summing over county–month)
temp_dist <- county_monthly_weather %>%
  summarise(
    across(
      .cols = all_of(c(temp_bins_vars, "temp_15_to_20")),
      .fns  = ~sum(.x, na.rm = TRUE)
    )
  ) %>%
  pivot_longer(
    cols      = everything(),
    names_to  = "variable",
    values_to = "days_in_bins"
  )

data_6b <- fig6b_coefs %>%
  left_join(temp_dist, by = "variable")

#-------------------------------------------------------------------------------
# 5. VISUALIZATION
#-------------------------------------------------------------------------------

Sys.setlocale("LC_TIME", "C")

# Panel (a): Time series of temperature and Baidu search

min_date <- min(weekly_data$week_start_date, na.rm = TRUE)
max_date <- max(weekly_data$week_start_date, na.rm = TRUE)

temp_max  <- max(weekly_data$temp_avg_weekly, na.rm = TRUE)
baidu_max <- max(
  c(weekly_data$baidu_index_weekly, weekly_data$baidu_index_monthly),
  na.rm = TRUE
)
scale_factor <- baidu_max / temp_max

p_6a <- ggplot(weekly_data) +
  geom_line(
    aes(x = week_start_date, y = baidu_index_monthly, color = "Baidu search (monthly)"),
    linewidth = 1
  ) +
  geom_point(
    aes(x = week_start_date, y = baidu_index_weekly, color = "Baidu search (weekly)"),
    size  = 2,
    shape = 1,
    alpha = 0.6
  ) +
  geom_line(
    aes(x = week_start_date, y = temp_avg_weekly * scale_factor, color = "Avg temperature"),
    linewidth = 0.5,
    alpha     = 0.8
  ) +
  scale_x_date(
    date_labels = "%b %Y",
    date_breaks = "4 months",
    limits      = c(min_date, max_date),
    expand      = c(0.02, 0)
  ) +
  scale_y_continuous(
    name   = "Baidu search index",
    guide  = "prism_offset",
    sec.axis = sec_axis(
      ~ . / scale_factor,
      name  = "Temperature (°C)",
      guide = "prism_offset"
    )
  ) +
  scale_color_manual(values = c(
    "Baidu search (monthly)" = "red",
    "Baidu search (weekly)"  = "blue",
    "Avg temperature"        = "#00CED1"
  )) +
  common_plot_theme() +
  theme(
    axis.text.x      = element_text(angle = 45, hjust = 1, vjust = 1),
    legend.direction = "horizontal",
    plot.margin      = unit(c(0.5, 0.5, 0.5, 0.5), "cm")
  ) +
  labs(tag = "a")

# Panel (b): Coefficients and temperature distribution

temperature_bins_labels <- c(
  "≤-5°C", "-5–0°C", "0–5°C", "5–10°C", "10–15°C",
  "15–20°C", "20–25°C", "25–30°C", "≥30°C"
)

data_6b$temperature_bins <- factor(
  temperature_bins_labels,
  levels = temperature_bins_labels
)

line_plot_6b <- ggplot(data_6b, aes(x = temperature_bins, y = coef, group = 1)) +
  geom_ribbon(
    aes(ymin = lower_ci, ymax = upper_ci, fill = "95% CI"),
    alpha = 0.5
  ) +
  geom_line(
    aes(color = "Estimated coefficients"),
    linewidth = 1
  ) +
  geom_point(
    aes(color = "Estimated coefficients"),
    size = 3
  ) +
  geom_hline(
    yintercept = 0,
    linetype   = "dashed",
    color      = "black"
  ) +
  scale_x_discrete(expand = expansion(mult = c(0.06, 0.06))) +
  scale_y_continuous(
    name  = "Estimated coefficients",
    guide = "prism_offset"
  ) +
  scale_color_manual(
    name   = NULL,
    values = c("Estimated coefficients" = "deepskyblue4")
  ) +
  scale_fill_manual(
    name   = NULL,
    values = c("95% CI" = "lightblue")
  ) +
  common_plot_theme() +
  theme(
    axis.text.x      = element_blank(),
    axis.title.x     = element_blank(),
    axis.ticks.x     = element_blank(),
    axis.line.x      = element_blank(),
    plot.margin      = unit(c(0.5, 0.5, 0, 0.5), "cm"),
    legend.direction = "horizontal"
  ) +
  labs(tag = "b")

bar_plot_6b <- ggplot(data_6b, aes(x = temperature_bins, y = days_in_bins)) +
  geom_bar(stat = "identity", fill = "grey70", width = 0.5) +
  scale_x_discrete(
    name   = "Temperature bins",
    expand = expansion(mult = c(0.06, 0.06))
  ) +
  scale_y_continuous(expand = c(0, 0)) +
  theme_classic() +
  theme(
    axis.line.y   = element_blank(),
    axis.ticks.y  = element_blank(),
    axis.text.y   = element_blank(),
    axis.title.y  = element_blank(),
    axis.line.x   = element_line(linewidth = 0.5, color = "black"),
    axis.ticks.x  = element_line(linewidth = 0.5, color = "black"),
    axis.text.x   = element_text(
      size  = text_size_x_axis_bar_plot,
      angle = 0,
      hjust = 0.5,
      color = "black"
    ),
    axis.title.x  = element_text(size = text_size_axis_title, color = "black"),
    panel.border  = element_blank(),
    panel.grid    = element_blank(),
    plot.margin   = unit(c(0, 0.5, 0.5, 0.5), "cm")
  )

p_6b <- line_plot_6b / bar_plot_6b + plot_layout(heights = c(3, 1))

#-------------------------------------------------------------------------------
# 6. COMBINE AND SAVE
#-------------------------------------------------------------------------------

supp_fig6 <- p_6a | p_6b

# PNG
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_6.png"),
  plot = supp_fig6,
  width = 16, height = 6, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)

# PDF
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_6.pdf"),
  plot = supp_fig6,
  width = 16, height = 6, units = "in",
  device = cairo_pdf
)



#===============================================================================
# END OF SCRIPT
#===============================================================================
