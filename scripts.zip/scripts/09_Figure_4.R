#===============================================================================
# Figure 4: Post-Adoption Electricity Consumption Changes (load-shifting and solar rebound)
#
# Description: This script extracts results from Equation (8) distributed lag 
# models and generates Figure 4, which illustrates load-shifting behavior and 
# solar rebound effects across RRPV and RRPV-BS adopters, including income 
# heterogeneity analysis.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(fixest)
library(lmtest)
library(ggplot2)
library(ggprism)
library(patchwork)

# --- Paths ---
path_root     <- "D:/rooftop"
path_models   <- file.path(path_root, "models")
path_plotting <- file.path(path_root, "plotting_data")
output_dir    <- "D:/rooftop/Fig"

# --- Plot Settings ---
text_size_axis_text_y <- 18
text_size_axis_text_x <- 12
text_size_axis_title  <- 20
text_size_legend_text <- 18
text_size_plot_tag    <- 22
text_size_annotation  <- 6

common_plot_theme_base <- function() {
  theme_prism() +
    theme(
      axis.text.y   = element_text(size = text_size_axis_text_y, face = "plain", color = "black"),
      axis.title    = element_text(size = text_size_axis_title,  face = "plain", color = "black"),
      axis.ticks    = element_line(linewidth = 0.5, color = "black"),
      axis.line     = element_line(linewidth = 0.5, color = "black"),
      legend.position = "top",
      legend.text     = element_text(size = text_size_legend_text, color = "black"),
      legend.title    = element_blank(),
      plot.title      = element_text(hjust = 0.5, size = text_size_axis_title),
      plot.tag.position = "topleft",
      plot.tag        = element_text(face = "bold", size = text_size_plot_tag)
    )
}

#===============================================================================
# HELPER FUNCTIONS
#===============================================================================

# --- Add Confidence Intervals ---
add_ci_from_se <- function(df, est_col = "coef", se_col = "se", level = 0.95) {
  alpha <- 1 - level
  crit  <- qnorm(1 - alpha / 2)
  
  df$lower_ci <- df[[est_col]] - crit * df[[se_col]]
  df$upper_ci <- df[[est_col]] + crit * df[[se_col]]
  df
}

# --- Calculate Total Effect ---
# This function computes a linear combination of the specified coefficients and 
# its cluster-robust standard error using the 
# household-level clustered variance-covariance matrix.
get_total_effect_fixed <- function(model, vars_to_sum, level = 0.95) {
  # Check if all required variables exist in the model
  model_coefs <- names(coef(model))
  if (!all(vars_to_sum %in% model_coefs)) {
    stop("Error: One or more required variables are missing in the model object.")
  }
  
  coef_vec   <- coef(model)[vars_to_sum]
  total_coef <- sum(coef_vec)
  
  vcov_matrix <- vcov(model, cluster = "household_id")
  V_sub       <- vcov_matrix[vars_to_sum, vars_to_sum, drop = FALSE]
  
  # For a sum of coefficients, the weight vector is a = (1, 1, ..., 1)',
  # so Var(a'β̂) = a' V a = sum of all elements in the submatrix.
  se_total <- sqrt(sum(V_sub))
  
  df    <- data.frame(coef = total_coef, se = se_total)
  df_ci <- add_ci_from_se(df, level = level)
  return(df_ci)
}

# --- Extract Data for Plotting (Panels a & b) ---
extract_lag_data <- function(model_path, level = 0.95) {
  model <- readRDS(model_path)
  lag_vars <- c(
    "total_generation_kwh", 
    "l(total_generation_kwh, 1)", 
    "l(total_generation_kwh, 2)", 
    "l(total_generation_kwh, 3)"
  )
  
  coef_summary <- coeftest(model, vcov. = vcov(model, cluster = "household_id"))
  
  lag_df <- data.frame(
    Lag_Group = c("Current", "Lag 1", "Lag 2", "Lag 3"),
    coef      = coef_summary[lag_vars, "Estimate"],
    se        = coef_summary[lag_vars, "Std. Error"]
  )
  
  lag_df_ci <- add_ci_from_se(lag_df, level = level)
  lag_df_ci <- lag_df_ci[, c("Lag_Group", "coef", "lower_ci", "upper_ci")]
  
  total_effect_df <- get_total_effect_fixed(model, vars_to_sum = lag_vars, level = level)
  total_effect_df$Lag_Group <- "Total Effect"
  
  bind_rows(total_effect_df[, names(lag_df_ci)], lag_df_ci)
}

#===============================================================================
# DATA EXTRACTION
#===============================================================================

# --- Panels a & b: Lag Structures ---
data_4a <- extract_lag_data(file.path(path_models, "eq8a_rrpv_dlm.RDS"))
saveRDS(data_4a, file.path(path_plotting, "fig4a_data.RDS"))

data_4b <- extract_lag_data(file.path(path_models, "eq8b_rrpv_bs_dlm.RDS"))
saveRDS(data_4b, file.path(path_plotting, "fig4b_data.RDS"))

# --- Panel c: RRPV Income Heterogeneity ---
# We use the contemporaneous effect of PV generation
# (total_generation_kwh) only, because lagged coefficients are not statistically
# different from zero in the estimated models.
baseline_model_rrpv <- readRDS(file.path(path_models, "eq8a_rrpv_dlm.RDS"))

baseline_data_rrpv <- get_total_effect_fixed(
  baseline_model_rrpv, 
  vars_to_sum = c("total_generation_kwh")
) %>%
  mutate(Income_Group = "baseline")

decile_data_rrpv <- map_dfr(1:10, function(i) {
  model_path <- file.path(path_models, paste0("eq8_hetero_rrpv_decile", i, ".RDS"))
  if (file.exists(model_path)) {
    model <- readRDS(model_path)
    get_total_effect_fixed(
      model, 
      vars_to_sum = c("total_generation_kwh")
    ) %>%
      mutate(Income_Group = case_when(
        i == 1  ~ "≤10%",
        i == 10 ~ "≥90%",
        TRUE    ~ paste0((i - 1) * 10, "-", i * 10, "%")
      ))
  }
})

data_4c <- bind_rows(baseline_data_rrpv, decile_data_rrpv)
saveRDS(data_4c, file.path(path_plotting, "fig4c_data.RDS"))

# --- Panel d: RRPV-BS Income Heterogeneity ---
# Analogous income-heterogeneous contemporaneous effects for RRPV-BS adopters.
baseline_model_rrpv_bs <- readRDS(file.path(path_models, "eq8b_rrpv_bs_dlm.RDS"))

baseline_data_rrpv_bs <- get_total_effect_fixed(
  baseline_model_rrpv_bs, 
  vars_to_sum = c("total_generation_kwh")
) %>%
  mutate(Income_Group = "baseline")

decile_data_rrpv_bs <- map_dfr(1:10, function(i) {
  model_path <- file.path(path_models, paste0("eq8_hetero_rrpv_bs_decile", i, ".RDS"))
  if (file.exists(model_path)) {
    model <- readRDS(model_path)
    get_total_effect_fixed(
      model, 
      vars_to_sum = c("total_generation_kwh")
    ) %>%
      mutate(Income_Group = case_when(
        i == 1  ~ "≤10%",
        i == 10 ~ "≥90%",
        TRUE    ~ paste0((i - 1) * 10, "-", i * 10, "%")
      ))
  }
})

data_4d <- bind_rows(baseline_data_rrpv_bs, decile_data_rrpv_bs)
saveRDS(data_4d, file.path(path_plotting, "fig4d_data.RDS"))

#===============================================================================
# PLOTTING
#===============================================================================

data_4a <- readRDS(file.path(path_plotting, "fig4a_data.RDS"))
data_4b <- readRDS(file.path(path_plotting, "fig4b_data.RDS"))
data_4c <- readRDS(file.path(path_plotting, "fig4c_data.RDS"))
data_4d <- readRDS(file.path(path_plotting, "fig4d_data.RDS"))

# --- Plot 4a ---
Lag_Group_order <- c("Total Effect", "Current", "Lag 1", "Lag 2", "Lag 3")
data_4a$Lag_Group <- factor(data_4a$Lag_Group, levels = Lag_Group_order)

p1 <- ggplot(data_4a, aes(x = Lag_Group, y = coef)) +
  geom_errorbar(aes(ymin = lower_ci, ymax = upper_ci, color = "95% CI"), width = 0.2, linewidth = 0.5) +
  geom_point(aes(color = "Coefficients"), size = 3) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", linewidth = 0.5) +
  scale_y_continuous(
    name   = expression(paste("Estimated Coefficients (", beta[k], ")")),
    breaks = seq(-0.06, 0.12, by = 0.06),
    limits = c(-0.06, 0.12),
    guide  = "prism_offset"
  ) +
  xlab("Lagged variables (RRPV-only adopter)") +
  scale_color_manual(values = c("Coefficients" = "darkcyan", "95% CI" = "black")) +
  common_plot_theme_base() +
  labs(tag = "a") +
  theme(
    axis.text.x = element_text(size = text_size_axis_text_x, hjust = 0.5),
    plot.margin = unit(c(0.5, 0.5, 0.5, 0.5), "cm")
  )

# --- Plot 4b ---
data_4b$Lag_Group <- factor(data_4b$Lag_Group, levels = Lag_Group_order)

p2 <- ggplot(data_4b, aes(x = Lag_Group, y = coef)) +
  geom_errorbar(aes(ymin = lower_ci, ymax = upper_ci, color = "95% CI"), width = 0.2, linewidth = 0.5) +
  geom_point(aes(color = "Coefficients"), size = 3) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", linewidth = 0.5) +
  scale_y_continuous(
    name   = expression(paste("Estimated Coefficients (", beta[k], ")")),
    breaks = seq(-0.06, 0.12, by = 0.06),
    limits = c(-0.06, 0.12),
    guide  = "prism_offset"
  ) +
  xlab("Lagged variables (RRPV-BS adopter)") +
  scale_color_manual(values = c("Coefficients" = "darkcyan", "95% CI" = "black")) +
  common_plot_theme_base() +
  labs(tag = "b") +
  theme(
    axis.text.x = element_text(size = text_size_axis_text_x, hjust = 0.5),
    plot.margin = unit(c(0.5, 0.5, 0.5, 0.5), "cm")
  )

# --- Plot 4c ---
Income_Group_order <- c("baseline", "≤10%", "10-20%", "20-30%", "30-40%", "40-50%", 
                        "50-60%", "60-70%", "70-80%", "80-90%", "≥90%")
data_4c$Income_Group <- factor(data_4c$Income_Group, levels = Income_Group_order)
baseline_val_rrpv <- data_4c$coef[data_4c$Income_Group == "baseline"]

p3 <- ggplot(data_4c, aes(x = Income_Group, y = coef)) +
  geom_errorbar(aes(ymin = lower_ci, ymax = upper_ci, color = "95% CI"), width = 0.2, linewidth = 0.5) +
  geom_point(aes(color = "Coefficients"), size = 3) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", linewidth = 0.5) +
  annotate("text", x = 2.2, y = baseline_val_rrpv, 
           label = paste0("All samples (", round(baseline_val_rrpv, 4), ")"), 
           size  = text_size_annotation, hjust = 0, color = "black") +
  annotate("segment", x = 2.1, xend = 1.3, y = baseline_val_rrpv, yend = baseline_val_rrpv,
           arrow = arrow(length = unit(0.2, "cm"), type = "closed"), color = "red", linewidth = 0.8) +
  scale_y_continuous(
    name   = "Estimated Coefficients",
    breaks = seq(-0.05, 0.2, by = 0.05),
    limits = c(-0.05, 0.2),
    guide  = "prism_offset"
  ) +
  scale_x_discrete(
    name = "Income level (RRPV-only adopter)",
    labels = c("baseline", expression(phantom(.) <= 10 * "%"), "10-20%", "20-30%", "30-40%", "40-50%",
               "50-60%", "60-70%", "70-80%", "80-90%", expression(phantom(.) >= 90 * "%"))
  ) +
  scale_color_manual(values = c("Coefficients" = "darkcyan", "95% CI" = "black")) +
  common_plot_theme_base() +
  labs(tag = "c") +
  theme(
    axis.text.x = element_text(size = text_size_axis_text_x, hjust = 0.5),
    plot.margin = unit(c(0.5, 0.5, 0.5, 0.5), "cm")
  )

# --- Plot 4d ---
data_4d$Income_Group <- factor(data_4d$Income_Group, levels = Income_Group_order)
baseline_val_rrpv_bs <- data_4d$coef[data_4d$Income_Group == "baseline"]

p4 <- ggplot(data_4d, aes(x = Income_Group, y = coef)) +
  geom_errorbar(aes(ymin = lower_ci, ymax = upper_ci, color = "95% CI"), width = 0.2, linewidth = 0.5) +
  geom_point(aes(color = "Coefficients"), size = 3) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", linewidth = 0.5) +
  annotate("text", x = 2.2, y = baseline_val_rrpv_bs, 
           label = paste0("All samples (", round(baseline_val_rrpv_bs, 4), ")"), 
           size  = text_size_annotation, hjust = 0, color = "black") +
  annotate("segment", x = 2.1, xend = 1.3, y = baseline_val_rrpv_bs, yend = baseline_val_rrpv_bs,
           arrow = arrow(length = unit(0.2, "cm"), type = "closed"), color = "red", linewidth = 0.8) +
  scale_y_continuous(
    name   = "Estimated Coefficients",
    breaks = seq(-0.05, 0.2, by = 0.05),
    limits = c(-0.05, 0.2),
    guide  = "prism_offset"
  ) +
  scale_x_discrete(
    name = "Income level (RRPV-BS adopter)",
    labels = c("baseline", expression(phantom(.) <= 10 * "%"), "10-20%", "20-30%", "30-40%", "40-50%",
               "50-60%", "60-70%", "70-80%", "80-90%", expression(phantom(.) >= 90 * "%"))
  ) +
  scale_color_manual(values = c("Coefficients" = "darkcyan", "95% CI" = "black")) +
  common_plot_theme_base() +
  labs(tag = "d") +
  theme(
    axis.text.x = element_text(size = text_size_axis_text_x, hjust = 0.5),
    plot.margin = unit(c(0.5, 0.5, 0.5, 0.5), "cm")
  )

#===============================================================================
# COMBINE AND SAVE FIGURE 4
#===============================================================================

final_combined_plot_4 <- (p1 | p2) / (p3 | p4)

# PDF
ggsave(
  filename = file.path(output_dir, "Figure_4.pdf"),
  plot = final_combined_plot_4,
  width = 18, height = 14, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Figure_4.png"),
  plot = final_combined_plot_4,
  width = 18, height = 14, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white",
)

#===============================================================================
# END OF SCRIPT
#===============================================================================
