#===============================================================================
# Supplementary Table 13: Parameter values used in PV generation prediction model
#
# Description:
# This script generates a formatted table of parameter values used in the
# household-level PV generation prediction model as described in Supplementary
# Note 20. The parameters include standard test conditions (STC) values,
# temperature coefficients, and cell temperature model coefficients.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(officer)
library(flextable)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root <- "D:/rooftop"
path_output <- file.path(path_root, "tables")

#-------------------------------------------------------------------------------
# 2. CREATE PARAMETER TABLE
#-------------------------------------------------------------------------------

pv_parameters <- tribble(
  ~Parameter, ~Description, ~Value, ~Units,
  "I_STC", "Reference irradiance under STC", "1000", "W/m²",
  "T_STC", "Reference cell temperature under STC", "25", "°C",
  "γ", "Temperature coefficient of module efficiency", "0.005", "°C⁻¹",
  "a₁", "Baseline term in cell temperature model", "4.3", "°C",
  "a₂", "Effect of irradiance on cell temperature", "0.943", "—",
  "a₃", "Effect of air temperature on cell temperature", "0.028", "°C/(W/m²)",
  "a₄", "Effect of wind speed on cell temperature", "1.528", "°C·s/m",
  "δ", "Degradation rate", "0.015", "—"
)

#-------------------------------------------------------------------------------
# 3. EXPORT INTERMEDIATE DATA
#-------------------------------------------------------------------------------

write_csv(
  pv_parameters,
  file.path(path_output, "Supplementary_Table_13_data.csv")
)

saveRDS(
  pv_parameters,
  file.path(path_output, "supp_table_13_data.RDS")
)

#-------------------------------------------------------------------------------
# 4. CREATE FLEXTABLE
#-------------------------------------------------------------------------------

ft <- flextable(pv_parameters) %>%
  set_header_labels(
    Parameter = "Parameter",
    Description = "Description",
    Value = "Value",
    Units = "Units"
  ) %>%
  width(j = 1, width = 1.2) %>%
  width(j = 2, width = 4.0) %>%
  width(j = 3, width = 1.0) %>%
  width(j = 4, width = 1.5) %>%
  align(j = c(1, 3, 4), align = "center", part = "all") %>%
  align(j = 2, align = "left", part = "all") %>%
  bold(part = "header") %>%
  hline_top(border = fp_border(width = 2), part = "header") %>%
  hline_bottom(border = fp_border(width = 2), part = "header") %>%
  hline_bottom(border = fp_border(width = 2), part = "body") %>%
  fontsize(size = 10, part = "all") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  set_caption(
    caption = as_paragraph(
      as_b("Supplementary Table 13. "),
      "Parameter values used in the PV generation prediction model"
    ),
    align_with_table = FALSE
  )

#-------------------------------------------------------------------------------
# 5. EXPORT TO WORD
#-------------------------------------------------------------------------------

doc <- read_docx() %>%
  body_add_flextable(value = ft)

output_path <- file.path(path_output, "Supplementary_Table_13.docx")
print(doc, target = output_path)

#===============================================================================
# END OF SCRIPT
#===============================================================================
