#===============================================================================
# Supplementary Fig. 12: Optimal rooftop PV system capacity
#
# This script computes household-level optimal PV capacity by equating 
# marginal LCOE with marginal benefit under province-specific tiered tariffs.
# Panels (a-c): marginal curves for three representative households
# Panel (d): distribution of optimal-actual capacity gap
#
# Authors: Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang, Shiqiu Zhang
# Date: 20/11/2025
#===============================================================================

library(tidyverse)
library(ggplot2)
library(patchwork)
library(lubridate)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root  <- "D:/rooftop"
output_dir <- file.path(path_root, "Fig")

THETA <- 0.40          # Engineering lower bound 
r <- 0.05              # Discount rate 
LT <- 25               # System lifetime in years 
CRF <- r * (1 + r)^LT / ((1 + r)^LT - 1)  # Capital recovery factor
DAYS_PER_YEAR <- 365
C_MAX_MULTIPLIER <- 2.5
C_STEP <- 0.5          # Capacity grid step size (kW)

#-------------------------------------------------------------------------------
# 2. ESTIMATION OF DEGRADATION PARAMETERS (EQUATION 23)
#-------------------------------------------------------------------------------
# Estimate α and β from Equation (22): G_avg,i(K) = μ_c(i)(1 - α/2·K - β/3·K²)
# via nonlinear least squares with county fixed effects

rrpv_data_raw <- readRDS(file.path(path_root, "electricity/rrpv_electricity_panel.RDS"))

estimation_data <- rrpv_data_raw %>%
  mutate(
    time = as.Date(time),
    county_id = as.character(county_id)
  ) %>%
  group_by(household_id, county_id) %>%
  summarise(
    K_i = mean(install_capacity_kwp, na.rm = TRUE),
    G_bar_i = mean(total_generation_kwh / install_capacity_kwp, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  filter(K_i > 0 & is.finite(G_bar_i))

# Compute initial county-level μ_c estimates
county_mu_init <- estimation_data %>%
  group_by(county_id) %>%
  summarise(
    mu_c = mean(G_bar_i / pmax(1 - 0.05/2 * K_i - 0.0008/3 * K_i^2, THETA)),
    .groups = "drop"
  )

estimation_data <- estimation_data %>%
  left_join(county_mu_init, by = "county_id")

# Solve Equation (23): minimize sum of squared residuals
global_nls <- tryCatch(
  nls(G_bar_i ~ mu_c * (1 - alpha/2 * K_i - beta/3 * K_i^2),
      data = estimation_data,
      start = list(alpha = 0.05, beta = 0.0008)),
  error = function(e) {
    warning("NLS convergence failed; using prior calibration values.")
    list(coefficients = c(alpha = 0.05, beta = 0.0008))
  }
)

ALPHA <- coef(global_nls)["alpha"]   # Linear degradation parameter α
ALPHA2 <- coef(global_nls)["beta"]   # Quadratic degradation parameter β

# Re-estimate county-level μ_c with fitted α and β
mu_county <- estimation_data %>%
  group_by(county_id) %>%
  summarise(
    mu_c = mean(G_bar_i / pmax(1 - ALPHA/2 * K_i - ALPHA2/3 * K_i^2, THETA)),
    .groups = "drop"
  )

#-------------------------------------------------------------------------------
# 3. PREPARE HOUSEHOLD-LEVEL ANNUAL DATA
#-------------------------------------------------------------------------------
# Recover household-specific μ_i and annualize daily generation

rrpv_data <- readRDS(file.path(path_root, "electricity/rrpv_electricity_panel.RDS"))

yearly_avg <- rrpv_data %>%
  mutate(
    time = as.Date(time),
    province_code = as.integer(substr(as.character(county_id), 1, 2)),
    county_id = as.character(county_id)
  ) %>%
  group_by(household_id) %>%
  summarise(
    province_code   = first(province_code),
    county_id       = first(county_id),
    capacity_now    = mean(install_capacity_kwp, na.rm = TRUE),
    EC_year_avg     = mean(total_consumption_kwh, na.rm = TRUE) * DAYS_PER_YEAR,
    EG_year_avg     = mean(total_generation_kwh, na.rm = TRUE) * DAYS_PER_YEAR,
    Import_year_avg = mean(grid_import_kwh, na.rm = TRUE) * DAYS_PER_YEAR,
    Export_year_avg = mean(grid_export_kwh, na.rm = TRUE) * DAYS_PER_YEAR,
    FIT_mean        = mean(feedin_tariff_yuan_kwh, na.rm = TRUE),
    G_bar_daily     = mean(total_generation_kwh / install_capacity_kwp, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  left_join(mu_county, by = "county_id") %>%
  mutate(
    # Recover household-specific μ_i
    decay_obs = pmax(1 - ALPHA/2 * capacity_now - ALPHA2/3 * capacity_now^2, THETA),
    mu_daily = if_else(
      is.finite(G_bar_daily) & decay_obs > 1e-6,
      G_bar_daily / decay_obs,
      coalesce(mu_c, 3.3) # 3.3 is a fallback empirical value for daily generation intensity (kWh/kW/day)
      # used when both household-specific and county-average data are unavailable.
    )
  ) %>%
  select(-mu_c, -G_bar_daily, -decay_obs, -county_id)

# Merge household installation costs (C_i in Equation 24)
household_costs <- read_csv(file.path(path_root, "household_costs.csv"), 
                            show_col_types = FALSE) %>%
  mutate(household_id = as.character(household_id))

yearly_avg <- yearly_avg %>%
  left_join(household_costs %>% select(household_id, upfront_cost), 
            by = "household_id") %>%
  mutate(CAPEX_per_kW = upfront_cost / pmax(capacity_now, 1))

median_capex <- median(yearly_avg$CAPEX_per_kW, na.rm = TRUE)
if (!is.finite(median_capex)) median_capex <- 6150

yearly_avg <- yearly_avg %>%
  mutate(CAPEX_per_kW = if_else(is.na(CAPEX_per_kW), median_capex, CAPEX_per_kW))

#-------------------------------------------------------------------------------
# 4. PROVINCE-SPECIFIC TARIFF PARAMETERS
#-------------------------------------------------------------------------------
# Feed-in tariffs and tiered pricing thresholds for marginal benefit curve

get_province_fit <- function(pro_code) {
  case_when(
    pro_code == 32 ~ 0.391,   # Jiangsu FIT (RMB/kWh)
    pro_code == 42 ~ 0.4161,  # Hubei FIT (RMB/kWh)
    pro_code == 21 ~ 0.3749,  # Liaoning FIT (RMB/kWh)
    TRUE           ~ 0.40
  )
}

get_province_thresholds <- function(pro_code) {
  # Annual grid import thresholds (kWh/year): [Inf, tier1_min, tier2_min, 0]
  case_when(
    pro_code == 32 ~ c(Inf, 4800, 2760, 0),  # Jiangsu
    pro_code == 42 ~ c(Inf, 4800, 2160, 0),  # Hubei
    pro_code == 21 ~ c(Inf, 3720, 2640, 0),  # Liaoning
    TRUE           ~ c(Inf, 4800, 2400, 0)
  )
}

get_province_prices <- function(pro_code) {
  # Tier prices (RMB/kWh): [tier1, tier2, tier3]
  case_when(
    pro_code == 32 ~ c(0.8283, 0.5783, 0.5283),  # Jiangsu
    pro_code == 42 ~ c(0.858, 0.608, 0.558),     # Hubei
    pro_code == 21 ~ c(0.80, 0.55, 0.50),        # Liaoning
    TRUE           ~ c(0.80, 0.60, 0.50)
  )
}

#-------------------------------------------------------------------------------
# 5. OPTIMAL CAPACITY SOLVER
#-------------------------------------------------------------------------------
# Compute marginal LCOE (Equation 24) and marginal benefit curves,
# find optimal capacity where LCOE_marg = MB via grid search

solve_optimal_improved <- function(row_data) {
  
  pro_code <- row_data$province_code
  EC_year_avg <- row_data$EC_year_avg
  mu_daily <- row_data$mu_daily
  FIT_mean <- row_data$FIT_mean
  CAPEX_kw <- row_data$CAPEX_per_kW
  capacity_now <- row_data$capacity_now
  
  # Define capacity search grid
  c_max <- max(capacity_now * C_MAX_MULTIPLIER, 25)
  caps <- seq(0, c_max, by = C_STEP)
  
  # Equation (21): Marginal generation intensity g_i(k)
  decay_function <- 1 - ALPHA * caps - ALPHA2 * caps^2
  g_marg_daily <- mu_daily * pmax(decay_function, THETA)
  g_marg_annual <- g_marg_daily * DAYS_PER_YEAR  # G_i^ann(k) in Equation (24)
  
  # Equation (24): Marginal LCOE curve
  lcoe_marg <- (CRF * CAPEX_kw) / pmax(g_marg_annual, 1e-6)
  
  # Marginal benefit curve: stepped function from tiered pricing
  ths <- get_province_thresholds(pro_code)
  prs <- get_province_prices(pro_code)
  
  # Start from counterfactual baseline (no PV): all consumption from grid
  import_remaining <- EC_year_avg
  delta_c <- c(caps[1], diff(caps))
  delta_gen <- g_marg_annual * delta_c
  mb_per_kwh <- numeric(length(caps))
  
  for (i in seq_along(caps)) {
    if (import_remaining > 0) {
      # Determine current tier based on remaining grid import
      if (import_remaining > ths[2]) {
        price_now <- prs[1]
      } else if (import_remaining > ths[3]) {
        price_now <- prs[2]
      } else {
        price_now <- prs[3]
      }
      mb_per_kwh[i] <- price_now
      import_remaining <- max(import_remaining - delta_gen[i], 0)
    } else {
      # Surplus generation compensated at feed-in tariff
      fit_val <- if_else(is.finite(FIT_mean), FIT_mean, get_province_fit(pro_code))
      mb_per_kwh[i] <- fit_val
    }
  }
  
  # Find optimal capacity where LCOE_marg first exceeds MB
  diff_lcoe_mb <- lcoe_marg - mb_per_kwh
  idx <- which(diff_lcoe_mb > 0)[1]
  
  if (is.na(idx)) {
    c_star <- tail(caps, 1)
  } else if (idx == 1) {
    c_star <- caps[1]
  } else {
    # Linear interpolation between adjacent grid points
    x1 <- caps[idx - 1]; x2 <- caps[idx]
    y1 <- diff_lcoe_mb[idx - 1]; y2 <- diff_lcoe_mb[idx]
    c_star <- x1 + (x2 - x1) * (0 - y1) / (y2 - y1)
  }
  
  list(
    caps       = caps,
    lcoe_marg  = lcoe_marg,
    mb_per_kwh = mb_per_kwh,
    c_star     = c_star
  )
}

# Run optimization for all households
results <- yearly_avg %>%
  rowwise() %>%
  mutate(opt_result = list(solve_optimal_improved(cur_data()))) %>%
  ungroup()

# Extract optimal capacities
opt_table <- results %>%
  mutate(c_star = map_dbl(opt_result, "c_star")) %>%
  select(household_id, province_code, capacity_now, c_star, EC_year_avg)

#-------------------------------------------------------------------------------
# 6. SELECT REPRESENTATIVE HOUSEHOLDS
#-------------------------------------------------------------------------------
# Choose one household from each consumption tertile for Panels (a-c)

opt_table <- opt_table %>%
  mutate(
    consumption_bin = cut(
      EC_year_avg,
      breaks = quantile(EC_year_avg, c(0, 0.33, 0.67, 1), na.rm = TRUE),
      labels = c("Low", "Medium", "High"),
      include.lowest = TRUE
    )
  )

set.seed(456)
plot_ids <- opt_table %>%
  group_by(consumption_bin) %>%
  slice_sample(n = 1) %>%
  pull(household_id)

plot_dat <- results %>%
  filter(household_id %in% plot_ids) %>%
  arrange(EC_year_avg)

#-------------------------------------------------------------------------------
# 7. VISUALIZATION
#-------------------------------------------------------------------------------

# Define large academic theme as requested
theme_large_academic <- theme(
  panel.background = element_rect(fill = "white", colour = NA),
  plot.background  = element_rect(fill = "white", colour = NA),
  panel.grid.major = element_blank(),
  panel.grid.minor = element_blank(),
  axis.line        = element_line(colour = "black", linewidth = 0.6),
  axis.ticks       = element_line(colour = "black", linewidth = 0.6),
  
  # Axis text and titles
  axis.text        = element_text(color = "black", size = 12, face = "plain"), 
  axis.title       = element_text(color = "black", size = 14, face = "plain"),
  
  # Legend settings
  legend.position  = "top",
  legend.text      = element_text(size = 12),
  legend.title     = element_blank(),
  
  # Title and Tag settings: Centered plain title, Bold top-left tag
  plot.title       = element_text(size = 16, face = "plain", hjust = 0.5),
  plot.tag         = element_text(size = 22, face = "bold", hjust = 0),
  plot.tag.position = c(0, 1) # Force tag to top-left
)

# --- Function to plot Panels a-c ---
plot_one_panel <- function(row_dat, panel_label, bin_label) {
  
  res <- row_dat$opt_result[[1]]
  df <- tibble(
    caps = res$caps,
    LCOE = res$lcoe_marg,
    MB   = res$mb_per_kwh
  )
  
  v_now  <- row_dat$capacity_now
  v_star <- res$c_star
  
  offset_star <- if_else(panel_label == "a", 0.3, 0)
  ymax <- quantile(df$LCOE, 0.95, na.rm = TRUE) * 1.5
  
  # Title Case for labels
  title_text <- paste(bin_label, "Consumption")
  
  ggplot(df, aes(x = caps)) +
    geom_step(aes(y = MB, color = "Marginal Benefit"), 
              direction = "hv", linewidth = 1.0) +
    geom_line(aes(y = LCOE, color = "Marginal LCOE"), linewidth = 1.1) +
    geom_vline(xintercept = v_now, linetype = "dashed", 
               color = "#1f77b4", linewidth = 0.8) +
    geom_vline(xintercept = v_star, linetype = "dotted", 
               color = "#d62728", linewidth = 0.8) +
    annotate("text", x = v_now, y = ymax * 0.6,
             label = sprintf("Actual: %.1f kW", v_now), 
             color = "#1f77b4", size = 4, fontface = "bold") +
    annotate("text", x = v_star + offset_star, y = ymax * 0.5,
             label = sprintf("Optimal: %.1f kW", v_star), 
             color = "#d62728", size = 4, fontface = "bold",
             hjust = if_else(panel_label == "a", 0, 0.5)) +
    scale_color_manual(
      values = c("Marginal Benefit" = "#2ca02c", "Marginal LCOE" = "#ff7f0e")
    ) +
    labs(
      title = title_text,
      tag = panel_label,
      x = "System Capacity (kWp)",  
      y = "Value/Cost (¥/kWh)"      
    ) +
    coord_cartesian(ylim = c(0, ymax)) +
    theme_large_academic
}

# Generate Panels a, b, c
p_a <- plot_one_panel(plot_dat[1, ], "a", "Low")
p_b <- plot_one_panel(plot_dat[2, ], "b", "Medium")
p_c <- plot_one_panel(plot_dat[3, ], "c", "High")


# --- Panel D: Absolute Capacity Gap Distribution ---
opt_table <- opt_table %>%
  mutate(diff = c_star - capacity_now)

q01 <- quantile(opt_table$diff, 0.01, na.rm = TRUE)
q99 <- quantile(opt_table$diff, 0.99, na.rm = TRUE)
opt_filtered <- opt_table %>%
  filter(diff >= q01 & diff <= q99)

x_range <- range(opt_filtered$diff, na.rm = TRUE)
x_margin <- diff(x_range) * 0.05
xlim_use <- c(x_range[1] - x_margin, x_range[2] + x_margin)

if (xlim_use[1] > 0) xlim_use[1] <- min(xlim_use[1], -1)
if (xlim_use[2] < 0) xlim_use[2] <- max(xlim_use[2], 1)

p_d <- ggplot(opt_filtered, aes(x = diff)) +
  geom_histogram(bins = 60, fill = "lightblue", color = "black", alpha = 0.7, size = 0.3) +
  geom_vline(xintercept = 0, linetype = "dashed", 
             color = "#d62728", linewidth = 1) +
  annotate("text", x = 0, y = Inf, vjust = 1.5, hjust = 1.1,
           label = "Actual = Optimal", 
           color = "#d62728", size = 4.5, fontface = "bold") +
  scale_x_continuous(limits = xlim_use, breaks = scales::pretty_breaks(n = 8)) +
  labs(
    title = "Absolute Capacity Gap Distribution", 
    tag = "d",
    x = "Gap: Optimal Minus Actual Capacity (kWp)", 
    y = "Number of Households"                    
  ) +
  theme_large_academic +
  theme(legend.position = "none")


# --- Panel E: Configuration Status (Relative Deviation) ---
RELATIVE_TOLERANCE <- 0.10

# Calculate status
opt_table_e <- opt_table %>%
  mutate(
    relative_diff = abs(c_star - capacity_now) / pmax(c_star, 0.1),
    config_type = case_when(
      relative_diff <= RELATIVE_TOLERANCE ~ "Optimal\n(within 10% deviation)",
      c_star > capacity_now & relative_diff > RELATIVE_TOLERANCE ~ "Under-configured\n(Actual < Optimal)",
      c_star < capacity_now & relative_diff > RELATIVE_TOLERANCE ~ "Over-configured\n(Actual > Optimal)",
      TRUE ~ "Other"
    )
  )

# Aggregate stats
stats_summary <- opt_table_e %>%
  count(config_type, name = "Count") %>%
  mutate(
    Percentage = Count / sum(Count),
    Pct_Label = sprintf("%.2f%%", Percentage * 100),
    Count_Label = paste0("N=", Count)
  )

# Set factor levels for correct ordering in horizontal bar chart (Bottom -> Top)
level_order <- c("Over-configured\n(Actual > Optimal)", 
                 "Optimal\n(within 10% deviation)", 
                 "Under-configured\n(Actual < Optimal)")
stats_summary$config_type <- factor(stats_summary$config_type, levels = level_order)

p_e <- ggplot(stats_summary, aes(x = config_type, y = Percentage, fill = config_type)) +
  geom_bar(stat = "identity", width = 0.65, color = "black", size = 0.3, alpha = 0.85) +
  coord_flip() +
  geom_text(aes(label = paste0(Pct_Label, "\n(", Count_Label, ")")), 
            hjust = -0.1, size = 4.5, fontface = "plain", lineheight = 0.9) +
  scale_fill_manual(values = c(
    "Over-configured\n(Actual > Optimal)" = "#4E84C4", # Blue
    "Optimal\n(within 10% deviation)" = "#529E3F",     # Green
    "Under-configured\n(Actual < Optimal)" = "#D16103"  # Orange
  )) +
  scale_y_continuous(labels = scales::percent, limits = c(0, 0.75)) +
  labs(
    title = "Configuration Status (Relative Deviation > 10%)", # Title Case
    tag = "e",
    x = NULL, 
    y = "Percentage of Households"
  ) +
  theme_large_academic +
  theme(
    legend.position = "none",
    axis.text.y = element_text(size = 12, face = "plain", color = "black"), # Plain font for y-axis text
    panel.grid.major.x = element_line(color = "grey90", linewidth = 0.5)
  )


#-------------------------------------------------------------------------------
# 8. COMBINE AND SAVE
#-------------------------------------------------------------------------------

# Combine plots: 3 on top, 2 on bottom
combined_plot <- (p_a | p_b | p_c) / (p_d | p_e) +
  plot_layout(heights = c(1, 1), guides = "collect") &
  theme(
    legend.position = "top",
    plot.margin = margin(15, 15, 15, 15)
  )

# PDF
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_12_Revised.pdf"),
  plot = combined_plot,
  width = 16, height = 10, units = "in", # W:16, H:10 for 5 panels
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_12_Revised.png"),
  plot = combined_plot,
  width = 16, height = 10, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)

# Save data for reproducibility
saveRDS(yearly_avg, file.path(path_root, "electricity/yearly_avg_with_pro.RDS"))
saveRDS(opt_table_e, file.path(path_root, "electricity/optimal_capacities_revised.RDS"))

#===============================================================================
# END OF SCRIPT
#===============================================================================