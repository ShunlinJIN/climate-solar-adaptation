#===============================================================================
# Supplementary Table 8: Balance test for treatment and control counties
#
# Description:
# This script constructs county-level balance statistics from source data,
# calculates pre-treatment (2018-2020) means for key covariates, and performs
# t-tests comparing treatment counties (Liaoning) vs control counties (Jiangsu,
# Hubei, Fujian). The table reports means with standard deviations, and 
# differences with standard errors to assess baseline balance.
#
#===============================================================================

library(tidyverse)
library(broom)
library(officer)
library(flextable)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root    <- "D:/rooftop"
path_balance <- file.path(path_root, "balance")
path_output  <- file.path(path_root, "tables")

#-------------------------------------------------------------------------------
# 2. LOAD AND PREPARE COUNTY-LEVEL BALANCE DATASET
#-------------------------------------------------------------------------------

balance_raw <- readRDS(file.path(path_balance, "county_balance.RDS"))

balance <- balance_raw %>%
  filter(province_id %in% c(21, 32, 42, 35)) %>%
  mutate(
    treat = if_else(province_id == 21, 1L, 0L),
    province_name = case_when(
      province_id == 21 ~ "Liaoning",
      province_id == 32 ~ "Jiangsu",
      province_id == 42 ~ "Hubei",
      province_id == 35 ~ "Fujian",
      TRUE ~ NA_character_
    )
  )

#-------------------------------------------------------------------------------
# 3. CALCULATE PRE-TREATMENT COUNTY MEANS (2018-2020)
#-------------------------------------------------------------------------------

balance_pre <- balance %>%
  filter(year >= 2018 & year <= 2020)

county_means <- balance_pre %>%
  group_by(county_id, province_id, treat, province_name) %>%
  summarise(
    rural_income         = mean(log(rural_income + 1), na.rm = TRUE),
    elec_consumption     = mean(log(elec_consumption + 1), na.rm = TRUE),
    num_pv_firms         = mean(num_pv_firms, na.rm = TRUE),
    extreme_heat_days    = mean(log(extreme_heat_days + 1), na.rm = TRUE),
    .groups = "drop"
  )

#-------------------------------------------------------------------------------
# 4. PERFORM BALANCE TESTS (T-TESTS)
#-------------------------------------------------------------------------------

vars <- c(
  "rural_income", "elec_consumption",
  "num_pv_firms", "extreme_heat_days"
)

balance_table <- map_dfr(vars, function(v) {
  d <- county_means[, c("treat", v)]
  names(d)[2] <- "x"
  
  t_res <- t.test(x ~ treat, data = d)
  
  # Treated group statistics
  treat_vals <- d$x[d$treat == 1]
  m_treat    <- mean(treat_vals, na.rm = TRUE)
  sd_treat   <- sd(treat_vals, na.rm = TRUE)
  
  # Control group statistics
  control_vals <- d$x[d$treat == 0]
  m_control    <- mean(control_vals, na.rm = TRUE)
  sd_control   <- sd(control_vals, na.rm = TRUE)
  
  # Difference statistics
  diff_val  <- m_treat - m_control
  std_error <- t_res$stderr
  
  tibble(
    Variable      = v,
    Treated_Mean  = m_treat,
    Treated_SD    = sd_treat,
    Control_Mean  = m_control,
    Control_SD    = sd_control,
    Difference    = diff_val,
    Std_Error     = std_error,
    P_Value       = t_res$p.value
  )
})

balance_table_formatted <- balance_table %>%
  mutate(
    Variable = case_when(
      Variable == "rural_income"      ~ "Rural per capita income (RMB)",
      Variable == "elec_consumption"  ~ "Per capita electricity consumption (kWh)",
      Variable == "num_pv_firms"      ~ "Number of PV firms (per capita)",
      Variable == "extreme_heat_days" ~ "Extreme heat days per year",
      TRUE ~ Variable
    ),
    Significance = case_when(
      P_Value < 0.001 ~ "***",
      P_Value < 0.01  ~ "**",
      P_Value < 0.05  ~ "*",
      TRUE            ~ ""
    ),
    # Format: Mean with SD in parentheses
    Treated_Display = paste0(
      format(round(Treated_Mean, 3), nsmall = 3),
      "\n(",
      format(round(Treated_SD, 3), nsmall = 3),
      ")"
    ),
    Control_Display = paste0(
      format(round(Control_Mean, 3), nsmall = 3),
      "\n(",
      format(round(Control_SD, 3), nsmall = 3),
      ")"
    ),
    # Format: Difference with SE in parentheses
    Diff_Display = paste0(
      format(round(Difference, 3), nsmall = 3),
      Significance,
      "\n(",
      format(round(Std_Error, 3), nsmall = 3),
      ")"
    )
  ) %>%
  select(
    Variable,
    `Treated mean` = Treated_Display,
    `Control mean` = Control_Display,
    Difference     = Diff_Display
  )

#-------------------------------------------------------------------------------
# 5. EXPORT RESULTS
#-------------------------------------------------------------------------------

write_csv(
  balance_table_formatted,
  file.path(path_output, "balance_test_results.csv")
)

saveRDS(
  balance_table_formatted,
  file.path(path_output, "balance_test_results.RDS")
)

#-------------------------------------------------------------------------------
# 6. CREATE FLEXTABLE AND EXPORT TO WORD
#-------------------------------------------------------------------------------

ft <- flextable(balance_table_formatted) %>%
  set_header_labels(
    Variable       = "Variable",
    `Treated mean` = "Treated mean",
    `Control mean` = "Control mean",
    Difference     = "Difference"
  ) %>%
  width(j = 1, width = 3.0) %>%
  width(j = 2:4, width = 1.5) %>%
  align(j = 2:4, align = "center", part = "all") %>%
  align(j = 1, align = "left", part = "all") %>%
  bold(part = "header") %>%
  hline_top(border = fp_border(width = 2), part = "header") %>%
  hline_bottom(border = fp_border(width = 2), part = "header") %>%
  hline_bottom(border = fp_border(width = 2), part = "body") %>%
  fontsize(size = 10, part = "all") %>%
  font(fontname = "Times New Roman", part = "all") %>%
  add_footer_lines(
    values = "Notes: Rural per capita income, per capita electricity consumption, and extreme heat days per year are log-transformed using log(x+1). Number of PV firms (per capita) is not log-transformed. Columns 'Treated mean' and 'Control mean' report means with their respective standard deviations in parentheses. The 'Difference' column reports the difference in means with standard errors in parentheses. Asterisks indicate statistical significance: *** p < 0.001, ** p < 0.01, * p < 0.05."
  ) %>%
  set_caption(
    caption = as_paragraph(
      as_b("Supplementary Table 8. "),
      "Pre-treatment covariate balance between treated and control groups"
    ),
    align_with_table = FALSE
  )

doc <- read_docx() %>%
  body_add_flextable(value = ft) %>%
  body_end_section_landscape()

output_path <- file.path(path_output, "Supplementary_Table_8.docx")
print(doc, target = output_path)

#===============================================================================
# END OF SCRIPT
#===============================================================================
