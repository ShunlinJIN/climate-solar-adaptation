#===============================================================================
# Supplementary Fig. 13: Distribution of annual grid consumption by province
#
# Description:
# This script visualizes the distribution of annual household grid electricity
# consumption across three provinces (Liaoning, Jiangsu, Hubei), with vertical
# lines marking the Tier 2 and Tier 3 thresholds of the province-specific
# inclining-block tariff structures.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(ggplot2)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root  <- "D:/rooftop"
output_dir <- file.path(path_root, "Fig")

#-------------------------------------------------------------------------------
# 2. LOAD DATA
#-------------------------------------------------------------------------------

yearly_avg <- readRDS(file.path(path_root, "electricity/yearly_avg_with_pro.RDS"))

#-------------------------------------------------------------------------------
# 3. ADD PROVINCE MAPPING
#-------------------------------------------------------------------------------

province_names <- tibble(
  province_code = c(21, 32, 42),
  province = c("Liaoning", "Jiangsu", "Hubei"),
)

yearly_avg <- yearly_avg %>%
  left_join(province_names, by = "province_code")

#-------------------------------------------------------------------------------
# 4. PREPARE THRESHOLD DATA
#-------------------------------------------------------------------------------

threshold_data <- tibble(
  province_code = c(21, 21, 32, 32, 42, 42),
  province = rep(c("Liaoning", "Jiangsu", "Hubei"), each = 2),
  threshold_type = rep(c("Tier 2", "Tier 3"), 3),
  value = c(2640, 3720, 2760, 4800, 2160, 4800)
)

#-------------------------------------------------------------------------------
# 5. CALCULATE TIER DISTRIBUTION (for reference)
#-------------------------------------------------------------------------------

tier_counts <- yearly_avg %>%
  group_by(province) %>%
  summarise(
    tier1 = sum(case_when(
      province_code == 32 ~ Import_year_avg <= 2760,
      province_code == 42 ~ Import_year_avg <= 2160,
      province_code == 21 ~ Import_year_avg <= 2640,
      TRUE ~ FALSE
    ), na.rm = TRUE),
    tier2 = sum(case_when(
      province_code == 32 ~ Import_year_avg > 2760 & Import_year_avg <= 4800,
      province_code == 42 ~ Import_year_avg > 2160 & Import_year_avg <= 4800,
      province_code == 21 ~ Import_year_avg > 2640 & Import_year_avg <= 3720,
      TRUE ~ FALSE
    ), na.rm = TRUE),
    tier3 = sum(case_when(
      province_code == 32 ~ Import_year_avg > 4800,
      province_code == 42 ~ Import_year_avg > 4800,
      province_code == 21 ~ Import_year_avg > 3720,
      TRUE ~ FALSE
    ), na.rm = TRUE),
    .groups = "drop"
  )

#-------------------------------------------------------------------------------
# 6. VISUALIZATION
#-------------------------------------------------------------------------------

p_13 <- ggplot(yearly_avg, aes(x = Import_year_avg)) +
  geom_histogram(aes(fill = province), bins = 50, alpha = 0.7, 
                 color = "white", linewidth = 0.3) +
  
  geom_vline(data = threshold_data %>% filter(threshold_type == "Tier 2"),
             aes(xintercept = value, color = "Tier 2 threshold"),
             linetype = "dashed", linewidth = 0.8) +
  
  geom_vline(data = threshold_data %>% filter(threshold_type == "Tier 3"),
             aes(xintercept = value, color = "Tier 3 threshold"),
             linetype = "dashed", linewidth = 0.8) +
  
  facet_wrap(~province, scales = "free_y", ncol = 1) +
  
  scale_fill_manual(
    values = c("Liaoning" = "#1f77b4", "Jiangsu" = "#ff7f0e", "Hubei" = "#2ca02c"),
    name = NULL
  ) +
  scale_color_manual(
    values = c("Tier 2 threshold" = "orange", "Tier 3 threshold" = "red"),
    name = NULL
  ) +
  
  labs(
    title = "Distribution of Annual Grid Electricity Consumption by Province",
    x = "Annual grid electricity consumption (kWh)",
    y = "Number of households"
  ) +
  
  theme_bw() +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position = "bottom",
    legend.box = "horizontal",
    legend.title = element_blank(),
    legend.text = element_text(size = 9),
    strip.text = element_text(size = 11, face = "bold"),
    strip.background = element_rect(fill = "white", color = "black"),
    axis.title = element_text(size = 10),
    axis.text = element_text(size = 9),
    plot.title = element_text(size = 12, face = "bold", hjust = 0.5)
  )

#-------------------------------------------------------------------------------
# 7. SAVE FIGURE
#-------------------------------------------------------------------------------

# PNG
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_13.png"), 
  plot = p_13, 
  width = 8, height = 10, units = "in", 
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)

# PDF
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_13.pdf"), 
  plot = p_13, 
  width = 8, height = 10, units = "in", 
  device = cairo_pdf
)

#===============================================================================
# END OF SCRIPT
#===============================================================================
