#===============================================================================
# Supplementary Table 5: Income distribution of RRPV adopters in the survey
#
# Description:
# This script creates a table showing the distribution of RRPV adopters across
# income quintiles. Income quintiles (Q1-Q5) are defined based on per capita
# household income in the full survey sample. The table reports the percentage
# of adopters in each quintile to illustrate the income composition of the
# adopter cohort.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidou Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(gt)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root  <- "D:/rooftop"
path_data  <- file.path(path_root, "survey")
output_dir <- file.path(path_root, "tables")

#-------------------------------------------------------------------------------
# 2. LOAD SURVEY DATA
#-------------------------------------------------------------------------------

survey_data <- readRDS(file.path(path_data, "survey_panel_data.RDS"))

#-------------------------------------------------------------------------------
# 3. AGGREGATE TO HOUSEHOLD LEVEL
#-------------------------------------------------------------------------------

household_level <- survey_data %>%
  group_by(household_id) %>%
  summarise(
    rrpv_adopter = max(if_else(treated == 1 & !is.na(pv_capacity_kW), 1, 0), na.rm = TRUE),
    per_capita_income = mean(Monthly_Per_Capita_Household_Income, na.rm = TRUE),
    .groups = "drop"
  )

#-------------------------------------------------------------------------------
# 4. CREATE INCOME QUINTILES BASED ON FULL SAMPLE
#-------------------------------------------------------------------------------

household_level <- household_level %>%
  mutate(
    income_quintile = cut(
      per_capita_income,
      breaks = quantile(per_capita_income, probs = seq(0, 1, 0.2), na.rm = TRUE),
      labels = c("Q1 (Lowest)", "Q2", "Q3", "Q4", "Q5 (Highest)"),
      include.lowest = TRUE
    )
  )

#-------------------------------------------------------------------------------
# 5. CALCULATE DISTRIBUTION OF ADOPTERS BY INCOME QUINTILE
#-------------------------------------------------------------------------------

adopters_only <- household_level %>% filter(rrpv_adopter == 1)

table5_data <- adopters_only %>%
  group_by(income_quintile) %>%
  summarise(n = n(), .groups = "drop") %>%
  mutate(Share = n / sum(n) * 100) %>%
  select(income_quintile, Share) %>%
  rename(`Per capita household income quintile` = income_quintile) %>%
  add_row(
    `Per capita household income quintile` = "Total",
    Share = 100
  )

#-------------------------------------------------------------------------------
# 6. FORMAT TABLE WITH GT
#-------------------------------------------------------------------------------

gt_table5 <- table5_data %>%
  gt() %>%
  fmt_number(columns = Share, decimals = 1, pattern = "{x}%") %>%
  cols_label(
    `Per capita household income quintile` = "Per capita household income quintile",
    Share = "Share"
  ) %>%
  tab_style(
    style = list(
      cell_text(weight = "bold"),
      cell_fill(color = "#f7f7f7")
    ),
    locations = cells_body(
      rows = `Per capita household income quintile` == "Total"
    )
  ) %>%
  tab_header(
    title = md("**Supplementary Table 5:** Income distribution of RRPV adopters in the survey")
  ) %>%
  tab_footnote(
    footnote = md("**Notes:** This table illustrates the income composition of the adopter cohort. The \"Per capita household income quintile\" (Q1-Q5) is defined based on the income distribution of the full survey sample (N=2,857, including both adopters and non-adopters). Q1 represents the bottom 20% of households by income in the full sample, and Q5 represents the top 20%. The \"Share\" column reports the percentage of the adopter subsample (N=1,175) that falls into each of these income quintiles.")
  ) %>%
  tab_options(
    table.font.size = px(12),
    heading.title.font.size = px(14),
    column_labels.font.weight = "bold",
    table.border.top.style = "solid",
    table.border.top.width = px(2),
    table.border.top.color = "black",
    table.border.bottom.style = "solid",
    table.border.bottom.width = px(2),
    table.border.bottom.color = "black",
    column_labels.border.bottom.style = "solid",
    column_labels.border.bottom.width = px(2),
    column_labels.border.bottom.color = "black",
    data_row.padding = px(4)
  ) %>%
  opt_horizontal_padding(scale = 2)

print(gt_table5)

#-------------------------------------------------------------------------------
# 7. SAVE OUTPUTS
#-------------------------------------------------------------------------------

gtsave(gt_table5, filename = file.path(output_dir, "Supplementary_Table_5.docx"))

write_csv(
  table5_data,
  file.path(output_dir, "Supplementary_Table_5_data.csv")
)

saveRDS(
  table5_data,
  file.path(output_dir, "supp_table_5_data.RDS")
)

#===============================================================================
# END OF SCRIPT
#===============================================================================
