#===============================================================================
# Figure 2: Climate-Induced Solar Adoption - Heterogeneity Analysis
#
# Description: Examines how temperature-adoption relationship varies by county
# characteristics (Equation 1 subgroup analysis) and loan program effects 
# (Equation 6).
#
# Panels:
# a) Historical temperature average heterogeneity (long-term vs short-term)
# b) Temperature fluctuation heterogeneity
# c) Solar radiation potential heterogeneity
# d) Land slope feasibility heterogeneity
# e) Income level heterogeneity
# f) PV loan program event study in low-income areas (Eq. 6)
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)
library(fixest)
library(ggplot2)
library(ggprism)
library(patchwork)

# --- Paths ---
path_root     <- "D:/rooftop"
path_models   <- file.path(path_root, "models")
path_plotting <- file.path(path_root, "plotting_data")
output_dir    <- file.path(path_root, "Fig")

# --- Plot Parameters ---
text_size_axis_text      <- 14
text_size_axis_title     <- 16
text_size_legend_text    <- 14
text_size_annotate_text  <- 5
text_size_plot_tag       <- 18

# --- Theme Function ---
common_plot_theme <- function() {
  theme_prism() +
    theme(
      axis.text = element_text(size = text_size_axis_text, color = "black"),
      axis.title = element_text(size = text_size_axis_title, color = "black"),
      axis.ticks = element_line(linewidth = 0.5),
      axis.line = element_line(linewidth = 0.5),
      axis.text.x = element_text(angle = 0, hjust = 0.5),
      legend.position = "top",
      legend.text = element_text(size = text_size_legend_text),
      legend.title = element_blank(),
      panel.spacing = unit(1.5, "cm"),
      plot.margin = unit(c(0.5, 0.5, 0.5, 0.5), "cm")
    )
}

# --- Significance Bracket Function ---
add_sig_bracket <- function(x1, x2, y_bar, y_base, y_label, label,
                            color = "darkgreen") {
  list(
    annotate("segment", x = x1, xend = x1 + 0.1, y = y_bar, yend = y_bar,
             linetype = "solid", color = color, size = 0.5),
    annotate("segment", x = x1 + 0.1, xend = x2 - 0.1, y = y_bar, yend = y_bar,
             linetype = "dashed", color = color, size = 0.5),
    annotate("segment", x = x2 - 0.1, xend = x2, y = y_bar, yend = y_bar,
             linetype = "solid", color = color, size = 0.5),
    annotate("segment", x = x1, xend = x1, y = y_base, yend = y_bar,
             linetype = "solid", color = color, size = 0.5),
    annotate("segment", x = x2, xend = x2, y = y_base, yend = y_bar,
             linetype = "solid", color = color, size = 0.5),
    annotate("text", x = (x1 + x2) / 2, y = y_label, label = label,
             size = text_size_annotate_text)
  )
}


#===============================================================================
# DATA EXTRACTION FUNCTIONS
#===============================================================================

extract_coef_ci <- function(model, vars) {
  coefs <- coef(model)[vars]
  ci <- confint(model, level = 0.95)[vars, ]
  data.frame(
    variable = vars,
    coef = coefs,
    lower_ci = ci[, 1],
    upper_ci = ci[, 2],
    row.names = NULL
  )
}

extract_extreme_temp_effect <- function(model_name) {
  model <- readRDS(file.path(path_models, paste0("hetero_", model_name, ".RDS")))
  coef_extreme <- coef(model)["temp_above_30"]
  ci_extreme <- confint(model, level = 0.95)["temp_above_30", ]
  data.frame(
    Impact = coef_extreme * 100,
    CI_lower = ci_extreme[1] * 100,
    CI_upper = ci_extreme[2] * 100
  )
}


#===============================================================================
# PANELS a-e: HETEROGENEITY ANALYSIS (Eq. 1 subgroups)
#===============================================================================

# Panel a: Temperature Average Heterogeneity
fig2a_data <- map_dfr(
  c("temp_long_high", "temp_long_low", "temp_short_high", "temp_short_low"),
  ~ extract_extreme_temp_effect(.x) %>%
    mutate(Category = case_when(
      .x == "temp_long_high"  ~ "Long-H",
      .x == "temp_long_low"   ~ "Long-L",
      .x == "temp_short_high" ~ "Short-H",
      .x == "temp_short_low"  ~ "Short-L"
    ))
) %>% select(Category, Impact, CI_lower, CI_upper)

saveRDS(fig2a_data, file.path(path_plotting, "fig2a_data.RDS"))

# Panel b: Temperature Fluctuation Heterogeneity
fig2b_data <- map_dfr(
  c("fluct_long_high", "fluct_long_low", "fluct_short_high", "fluct_short_low"),
  ~ extract_extreme_temp_effect(.x) %>%
    mutate(Category = case_when(
      .x == "fluct_long_high"  ~ "Long-H",
      .x == "fluct_long_low"   ~ "Long-L",
      .x == "fluct_short_high" ~ "Short-H",
      .x == "fluct_short_low"  ~ "Short-L"
    ))
) %>% select(Category, Impact, CI_lower, CI_upper)

saveRDS(fig2b_data, file.path(path_plotting, "fig2b_data.RDS"))

# Panel c: Solar Radiation Heterogeneity
fig2c_data <- map_dfr(
  c("solar_high", "solar_medium", "solar_low"),
  ~ extract_extreme_temp_effect(.x) %>%
    mutate(Category = str_replace(.x, "solar_", "") %>% str_to_title())
) %>% select(Category, Impact, CI_lower, CI_upper)

saveRDS(fig2c_data, file.path(path_plotting, "fig2c_data.RDS"))

# Panel d: Land Slope Heterogeneity
fig2d_data <- map_dfr(
  c("slope_high", "slope_medium", "slope_low"),
  ~ extract_extreme_temp_effect(.x) %>%
    mutate(Category = str_replace(.x, "slope_", "") %>% str_to_title())
) %>% select(Category, Impact, CI_lower, CI_upper)

saveRDS(fig2d_data, file.path(path_plotting, "fig2d_data.RDS"))

# Panel e: Income Level Heterogeneity
fig2e_data <- map_dfr(
  c("income_high", "income_medium", "income_low"),
  ~ extract_extreme_temp_effect(.x) %>%
    mutate(Category = str_replace(.x, "income_", "") %>% str_to_title())
) %>% select(Category, Impact, CI_lower, CI_upper)

saveRDS(fig2e_data, file.path(path_plotting, "fig2e_data.RDS"))

# Panel f: Loan Program Event Study (Eq. 6)
eq6 <- readRDS(file.path(path_models, "eq6_loan_event.RDS"))
loan_event_vars <- paste0("event_loan_", c(-8:-2, 0:8))

fig2f_data <- extract_coef_ci(eq6, loan_event_vars) %>%
  add_row(variable = "event_loan_-1", coef = 0, lower_ci = 0, upper_ci = 0, .before = 8)

saveRDS(fig2f_data, file.path(path_plotting, "fig2f_data.RDS"))


#===============================================================================
# PLOTTING
#===============================================================================

data_2a <- readRDS(file.path(path_plotting, "fig2a_data.RDS"))
data_2b <- readRDS(file.path(path_plotting, "fig2b_data.RDS"))
data_2c <- readRDS(file.path(path_plotting, "fig2c_data.RDS"))
data_2d <- readRDS(file.path(path_plotting, "fig2d_data.RDS"))
data_2e <- readRDS(file.path(path_plotting, "fig2e_data.RDS"))
data_2f <- readRDS(file.path(path_plotting, "fig2f_data.RDS"))


#===============================================================================
# PANEL A: Temperature Average Heterogeneity
#===============================================================================

data_2a$Category <- factor(data_2a$Category, levels = c("Long-H", "Long-L", "Short-H", "Short-L"))

p_2a <- ggplot(data_2a, aes(x = Category, y = Impact)) +
  geom_bar(aes(fill = "Estimated Impacts"), stat = "identity", width = 0.6, alpha = 0.8) +
  geom_errorbar(aes(ymin = CI_lower, ymax = CI_upper, color = "95% CI"), width = 0.1, linewidth = 0.5) +
  scale_y_continuous(name = "Estimated Impacts (%)", breaks = seq(0, 15, 3), limits = c(0, 15), guide = "prism_offset") +
  scale_x_discrete(name = "Different historical average temperature") +
  scale_fill_manual(name = NULL, values = c("Estimated Impacts" = "cyan4")) +
  scale_color_manual(name = NULL, values = c("95% CI" = "black")) +
  common_plot_theme() +
  add_sig_bracket(1, 2, 12, 11, 13, "p < 0.01") +
  add_sig_bracket(3, 4, 12, 11, 13, "p < 0.01")


#===============================================================================
# PANEL B: Temperature Fluctuation Heterogeneity
#===============================================================================

data_2b$Category <- factor(data_2b$Category, levels = c("Long-H", "Long-L", "Short-H", "Short-L"))

p_2b <- ggplot(data_2b, aes(x = Category, y = Impact)) +
  geom_bar(aes(fill = "Estimated Impacts"), stat = "identity", width = 0.6, alpha = 0.8) +
  geom_errorbar(aes(ymin = CI_lower, ymax = CI_upper, color = "95% CI"), width = 0.1, linewidth = 0.5) +
  scale_y_continuous(name = "Estimated Impacts (%)", breaks = seq(0, 15, 3), limits = c(0, 15), guide = "prism_offset") +
  scale_x_discrete(name = "Different historical temperature fluctuation") +
  scale_fill_manual(name = NULL, values = c("Estimated Impacts" = "cyan4")) +
  scale_color_manual(name = NULL, values = c("95% CI" = "black")) +
  common_plot_theme() +
  add_sig_bracket(1, 2, 12, 11, 13, "p < 0.01") +
  add_sig_bracket(3, 4, 12, 11, 13, "p > 0.1")


#===============================================================================
# PANEL C: Solar Radiation Heterogeneity
#===============================================================================

data_2c$Category <- factor(data_2c$Category, levels = c("High", "Medium", "Low"))

p_2c <- ggplot(data_2c, aes(x = Category, y = Impact)) +
  geom_bar(aes(fill = "Estimated Impacts"), stat = "identity", width = 0.6, alpha = 0.8) +
  geom_errorbar(aes(ymin = CI_lower, ymax = CI_upper, color = "95% CI"), width = 0.1, linewidth = 0.5) +
  scale_y_continuous(name = "Estimated Impacts (%)", breaks = seq(0, 15, 3), limits = c(0, 15), guide = "prism_offset") +
  scale_x_discrete(name = "Solar radiation") +
  scale_fill_manual(name = NULL, values = c("Estimated Impacts" = "cyan4")) +
  scale_color_manual(name = NULL, values = c("95% CI" = "black")) +
  common_plot_theme() +
  add_sig_bracket(1, 2, 12, 11, 13, "p < 0.01") +
  add_sig_bracket(1, 3, 14, 13, 15, "p < 0.01")


#===============================================================================
# PANEL D: Land Slope Heterogeneity
#===============================================================================

data_2d$Category <- factor(data_2d$Category, levels = c("High", "Medium", "Low"))

p_2d <- ggplot(data_2d, aes(x = Category, y = Impact)) +
  geom_bar(aes(fill = "Estimated Impacts"), stat = "identity", width = 0.6, alpha = 0.8) +
  geom_errorbar(aes(ymin = CI_lower, ymax = CI_upper, color = "95% CI"), width = 0.1, linewidth = 0.5) +
  scale_y_continuous(name = "Estimated Impacts (%)", breaks = seq(0, 15, 3), limits = c(0, 15), guide = "prism_offset") +
  scale_x_discrete(name = "Land slope") +
  scale_fill_manual(name = NULL, values = c("Estimated Impacts" = "cyan4")) +
  scale_color_manual(name = NULL, values = c("95% CI" = "black")) +
  common_plot_theme() +
  add_sig_bracket(1, 2, 12, 11, 13, "p > 0.1") +
  add_sig_bracket(1, 3, 14, 13, 15, "p < 0.01")


#===============================================================================
# PANEL E: Income Level Heterogeneity
#===============================================================================

data_2e$Category <- factor(data_2e$Category, levels = c("High", "Medium", "Low"))

p_2e <- ggplot(data_2e, aes(x = Category, y = Impact)) +
  geom_bar(aes(fill = "Estimated Impacts"), stat = "identity", width = 0.6, alpha = 0.8) +
  geom_errorbar(aes(ymin = CI_lower, ymax = CI_upper, color = "95% CI"), width = 0.1, linewidth = 0.5) +
  scale_y_continuous(name = "Estimated Impacts (%)", breaks = seq(0, 15, 3), limits = c(0, 15), guide = "prism_offset") +
  scale_x_discrete(name = "Income level") +
  scale_fill_manual(name = NULL, values = c("Estimated Impacts" = "cyan4")) +
  scale_color_manual(name = NULL, values = c("95% CI" = "black")) +
  common_plot_theme() +
  add_sig_bracket(1, 2, 12, 11, 13, "p < 0.01") +
  add_sig_bracket(1, 3, 14, 13, 15, "p < 0.01")


#===============================================================================
# PANEL F: Loan Program Event Study
#===============================================================================

Pilot_month_labels <- c("≤-8", "-7", "-6", "-5", "-4", "-3", "-2", "-1", 
                        "0", "1", "2", "3", "4", "5", "6", "7", "≥8")
data_2f$Pilot_month <- factor(Pilot_month_labels, levels = Pilot_month_labels)

p_2f <- ggplot(data_2f, aes(x = Pilot_month, y = coef, group = 1)) +
  geom_ribbon(aes(ymin = lower_ci, ymax = upper_ci, fill = "95% CI"), alpha = 0.8) +
  geom_line(aes(color = "Estimated Coefficients"), linewidth = 1) +
  geom_point(aes(color = "Estimated Coefficients"), size = 3) +
  geom_vline(xintercept = 8, linetype = "dashed", color = "black", linewidth = 0.5) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", linewidth = 0.5) +
  scale_y_continuous(
    name = "Estimated Coefficients",
    breaks = c(-0.025, 0, 0.025, 0.05, 0.075),
    limits = c(-0.025, 0.075),
    guide = "prism_offset"
  ) +
  xlab("Months before and after PV loans rollout") +
  scale_color_manual(name = NULL, values = c("Estimated Coefficients" = "azure4")) +
  scale_fill_manual(name = NULL, values = c("95% CI" = "cyan4")) +
  common_plot_theme()


#===============================================================================
# COMBINE AND SAVE FIGURE 2
#===============================================================================

combined_plot <- (p_2a + p_2b + p_2c) / (p_2d + p_2e + p_2f) +
  plot_annotation(tag_levels = 'a') &
  theme(
    plot.tag.position = 'topleft',
    plot.tag = element_text(face = 'bold', size = text_size_plot_tag)
  )

# PDF
ggsave(
  filename = file.path(output_dir, "Figure_2.pdf"),
  plot = combined_plot,
  width = 18, height = 12, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Figure_2.png"),
  plot = combined_plot,
  width = 18, height = 12, units = "in",
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)


#===============================================================================
# END OF SCRIPT
#===============================================================================
