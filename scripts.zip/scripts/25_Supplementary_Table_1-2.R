#===============================================================================
# Supplementary Tables 1 & 2: Descriptive statistics for RRPV adopters
#
# Description:
# This script calculates household-level descriptive statistics for RRPV and
# RRPV-BS adopters. Table 1 reports installed capacity, daily generation,
# consumption, self-consumption, and grid transactions for RRPV households.
# Table 2 adds battery capacity and battery-related electricity flows for
# RRPV-BS households.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        20/11/2025
#===============================================================================

library(tidyverse)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root   <- "D:/rooftop"
path_output <- file.path(path_root, "tables")

#-------------------------------------------------------------------------------
# 2. LOAD DATA
#-------------------------------------------------------------------------------

rrpv_panel    <- readRDS(file.path(path_root, "electricity/rrpv_electricity_panel.RDS"))
rrpv_bs_panel <- readRDS(file.path(path_root, "electricity/rrpv_bs_electricity_panel.RDS"))

#-------------------------------------------------------------------------------
# 3. SUPPLEMENTARY TABLE 1: RRPV-ONLY ADOPTERS
#-------------------------------------------------------------------------------

supp_table1 <- rrpv_panel %>%
  summarise(
    `Installed PV capacity (kW)_Mean`               = mean(install_capacity_kwp,   na.rm = TRUE),
    `Installed PV capacity (kW)_SD`                 = sd(install_capacity_kwp,     na.rm = TRUE),
    
    `Daily PV generation (kWh)_Mean`                = mean(total_generation_kwh,   na.rm = TRUE),
    `Daily PV generation (kWh)_SD`                  = sd(total_generation_kwh,     na.rm = TRUE),
    
    `Daily electricity consumption (kWh)_Mean`      = mean(total_consumption_kwh,  na.rm = TRUE),
    `Daily electricity consumption (kWh)_SD`        = sd(total_consumption_kwh,    na.rm = TRUE),
    
    `Daily self-consumed PV electricity (kWh)_Mean` = mean(self_consumption_kwh,   na.rm = TRUE),
    `Daily self-consumed PV electricity (kWh)_SD`   = sd(self_consumption_kwh,     na.rm = TRUE),
    
    `Daily grid-imported electricity (kWh)_Mean`    = mean(grid_import_kwh,        na.rm = TRUE),
    `Daily grid-imported electricity (kWh)_SD`      = sd(grid_import_kwh,          na.rm = TRUE),
    
    `Daily grid-exported electricity (kWh)_Mean`    = mean(grid_export_kwh,        na.rm = TRUE),
    `Daily grid-exported electricity (kWh)_SD`      = sd(grid_export_kwh,          na.rm = TRUE)
  ) %>%
  pivot_longer(
    cols      = everything(),
    names_to  = c("Variable", "Statistic"),
    names_sep = "_"
  ) %>%
  pivot_wider(
    names_from  = Statistic,
    values_from = value
  ) %>%
  arrange(factor(
    Variable,
    levels = c(
      "Installed PV capacity (kW)",
      "Daily PV generation (kWh)",
      "Daily electricity consumption (kWh)",
      "Daily self-consumed PV electricity (kWh)",
      "Daily grid-imported electricity (kWh)",
      "Daily grid-exported electricity (kWh)"
    )
  )) %>%
  mutate(
    Mean = round(Mean, 2),
    SD   = round(SD,   2)
  )

#-------------------------------------------------------------------------------
# 4. SUPPLEMENTARY TABLE 2: RRPV-BS ADOPTERS
#-------------------------------------------------------------------------------

supp_table2 <- rrpv_bs_panel %>%
  summarise(
    `Installed PV capacity (kW)_Mean`               = mean(install_capacity_kwp,     na.rm = TRUE),
    `Installed PV capacity (kW)_SD`                 = sd(install_capacity_kwp,       na.rm = TRUE),
    
    `Battery capacity (kWh)_Mean`                   = mean(battery_capacity_kwh,     na.rm = TRUE),
    `Battery capacity (kWh)_SD`                     = sd(battery_capacity_kwh,       na.rm = TRUE),
    
    `Daily PV generation (kWh)_Mean`                = mean(total_generation_kwh,     na.rm = TRUE),
    `Daily PV generation (kWh)_SD`                  = sd(total_generation_kwh,       na.rm = TRUE),
    
    `Daily electricity consumption (kWh)_Mean`      = mean(total_consumption_kwh,    na.rm = TRUE),
    `Daily electricity consumption (kWh)_SD`        = sd(total_consumption_kwh,      na.rm = TRUE),
    
    `Daily self-consumed PV electricity (kWh)_Mean` = mean(consumption_from_pv_kwh,  na.rm = TRUE),
    `Daily self-consumed PV electricity (kWh)_SD`   = sd(consumption_from_pv_kwh,    na.rm = TRUE),
    
    `Daily grid-imported electricity (kWh)_Mean`    = mean(consumption_from_grid_kwh,   na.rm = TRUE),
    `Daily grid-imported electricity (kWh)_SD`      = sd(consumption_from_grid_kwh,     na.rm = TRUE),
    
    `Battery-sourced electricity (kWh)_Mean`        = mean(consumption_from_battery_kwh, na.rm = TRUE),
    `Battery-sourced electricity (kWh)_SD`          = sd(consumption_from_battery_kwh,   na.rm = TRUE),
    
    `Battery charging (kWh)_Mean`                   = mean(battery_charge_kwh,       na.rm = TRUE),
    `Battery charging (kWh)_SD`                     = sd(battery_charge_kwh,         na.rm = TRUE),
    
    `Daily grid-exported electricity (kWh)_Mean`    = mean(grid_export_kwh,          na.rm = TRUE),
    `Daily grid-exported electricity (kWh)_SD`      = sd(grid_export_kwh,            na.rm = TRUE)
  ) %>%
  pivot_longer(
    cols      = everything(),
    names_to  = c("Variable", "Statistic"),
    names_sep = "_"
  ) %>%
  pivot_wider(
    names_from  = Statistic,
    values_from = value
  ) %>%
  arrange(factor(
    Variable,
    levels = c(
      "Installed PV capacity (kW)",
      "Battery capacity (kWh)",
      "Daily PV generation (kWh)",
      "Daily electricity consumption (kWh)",
      "Daily self-consumed PV electricity (kWh)",
      "Daily grid-imported electricity (kWh)",
      "Battery-sourced electricity (kWh)",
      "Battery charging (kWh)",
      "Daily grid-exported electricity (kWh)"
    )
  )) %>%
  mutate(
    Mean = round(Mean, 2),
    SD   = round(SD,   2)
  )

#-------------------------------------------------------------------------------
# 5. SAVE TABLES
#-------------------------------------------------------------------------------

write_csv(supp_table1, file.path(path_output, "supplementary_table1_rrpv_descriptives.csv"))
write_csv(supp_table2, file.path(path_output, "supplementary_table2_rrpv_bs_descriptives.csv"))

saveRDS(supp_table1, file.path(path_output, "supplementary_table1_rrpv_descriptives.RDS"))
saveRDS(supp_table2, file.path(path_output, "supplementary_table2_rrpv_bs_descriptives.RDS"))

#===============================================================================
# END OF SCRIPT
#===============================================================================
