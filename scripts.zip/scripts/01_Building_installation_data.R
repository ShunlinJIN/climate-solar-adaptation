#===============================================================================
# Data Integration Script for RRPV and RRPV-BS Adoption
#
# Description: This script constructs a county-month panel dataset for regression.
#              It integrates RRPV-only and RRPV-BS installations, weather, economic,  
#              environmental, and policy data.
#              The final output is a clean dataset saved as an .RDS file, suitable
#              for estimating models (Equations 1-7) described in the manuscript.
#
# Authors:      Shunlin Jin, Yana Jin, Xianling Long, Weidong Wang & Shiqiu Zhang
# Date:        15/11/2025
#===============================================================================


library(tidyverse)
library(lubridate)

# --- Paths ---
path_root   <- "D:/rooftop"
path_output <- file.path(path_root, "adoption")

#-------------------------------------------------------------------------------
# 1. LOAD RAW DATA
#-------------------------------------------------------------------------------

install_raw    <- readRDS(file.path(path_root, "rrpv_installations.RDS"))
install_bs_raw <- readRDS(file.path(path_root, "rrpv_bs_installations.RDS"))
weather_daily  <- readRDS(file.path(path_root, "weather_daily_county.RDS"))
pm25_monthly   <- readRDS(file.path(path_root, "pm25_monthly.RDS"))
income_annual  <- readRDS(file.path(path_root, "income_annual.RDS"))
firms_monthly  <- readRDS(file.path(path_root, "pv_firms_monthly.RDS"))
pilot_policy   <- read_csv(file.path(path_root, "pilot_policy.csv"))
loan_policy    <- read_csv(file.path(path_root, "loan_policy.csv"))
power_outages  <- read_csv(file.path(path_root, "power_outages.csv"))
solar_radiation <- readRDS(file.path(path_root, "county_solar_radiation.RDS"))
land_slope      <- readRDS(file.path(path_root, "county_land_slope.RDS"))

#-------------------------------------------------------------------------------
# 2. PROCESS INSTALLATION DATA
#-------------------------------------------------------------------------------

install_monthly <- install_raw %>%
  mutate(
    county_id = as.character(county_code),
    date = as.Date(install_date),
    year = year(date),
    month = month(date)
  ) %>%
  filter(year >= 2018 & year <= 2022) %>%
  group_by(county_id, year, month) %>%
  summarise(
    installations = n(),
    total_capacity_kw = sum(capacity_kw, na.rm = TRUE),
    .groups = "drop"
  )

install_bs_monthly <- install_bs_raw %>%
  mutate(
    county_id = as.character(county_code),
    date = as.Date(install_date),
    year = year(date),
    month = month(date)
  ) %>%
  filter(year >= 2018 & year <= 2022) %>%
  group_by(county_id, year, month) %>%
  summarise(
    installations_bs = n(),
    .groups = "drop"
  )

#-------------------------------------------------------------------------------
# 3. PROCESS WEATHER DATA & CREATE TEMPERATURE BINS
#-------------------------------------------------------------------------------

assign_temp_bin <- function(temp) {
  case_when(
    temp <= -5              ~ "temp_below_neg5",
    temp > -5 & temp < 0    ~ "temp_neg5_to_0",
    temp >= 0 & temp < 5    ~ "temp_0_to_5",
    temp >= 5 & temp < 10   ~ "temp_5_to_10",
    temp >= 10 & temp < 15  ~ "temp_10_to_15",
    temp >= 15 & temp < 20  ~ "temp_15_to_20",
    temp >= 20 & temp < 25  ~ "temp_20_to_25",
    temp >= 25 & temp < 30  ~ "temp_25_to_30",
    temp >= 30              ~ "temp_above_30",
    TRUE                    ~ NA_character_
  )
}

weather_monthly <- weather_daily %>%
  mutate(
    county_id = as.character(county_code),
    date = as.Date(date),
    year = year(date),
    month = month(date),
    temp_bin = assign_temp_bin(temp_avg_daily),
    temp_max_bin = assign_temp_bin(temp_max_daily)
  ) %>%
  filter(year >= 2018 & year <= 2022) %>%
  group_by(county_id, year, month) %>%
  summarise(
    temp_below_neg5 = sum(temp_bin == "temp_below_neg5", na.rm = TRUE),
    temp_neg5_to_0  = sum(temp_bin == "temp_neg5_to_0", na.rm = TRUE),
    temp_0_to_5     = sum(temp_bin == "temp_0_to_5", na.rm = TRUE),
    temp_5_to_10    = sum(temp_bin == "temp_5_to_10", na.rm = TRUE),
    temp_10_to_15   = sum(temp_bin == "temp_10_to_15", na.rm = TRUE),
    temp_15_to_20   = sum(temp_bin == "temp_15_to_20", na.rm = TRUE),
    temp_20_to_25   = sum(temp_bin == "temp_20_to_25", na.rm = TRUE),
    temp_25_to_30   = sum(temp_bin == "temp_25_to_30", na.rm = TRUE),
    temp_above_30   = sum(temp_bin == "temp_above_30", na.rm = TRUE),
    
    temp_max_below_neg5 = sum(temp_max_bin == "temp_below_neg5", na.rm = TRUE),
    temp_max_neg5_to_0  = sum(temp_max_bin == "temp_neg5_to_0", na.rm = TRUE),
    temp_max_0_to_5     = sum(temp_max_bin == "temp_0_to_5", na.rm = TRUE),
    temp_max_5_to_10    = sum(temp_max_bin == "temp_5_to_10", na.rm = TRUE),
    temp_max_10_to_15   = sum(temp_max_bin == "temp_10_to_15", na.rm = TRUE),
    temp_max_15_to_20   = sum(temp_max_bin == "temp_15_to_20", na.rm = TRUE),
    temp_max_20_to_25   = sum(temp_max_bin == "temp_20_to_25", na.rm = TRUE),
    temp_max_25_to_30   = sum(temp_max_bin == "temp_25_to_30", na.rm = TRUE),
    temp_max_above_30   = sum(temp_max_bin == "temp_above_30", na.rm = TRUE),
    
    sunshine_hours_daily_avg = mean(sunshine_duration, na.rm = TRUE),
    rainfall_mm_daily_avg    = mean(precipitation, na.rm = TRUE),
    humidity_pct_daily_avg   = mean(relative_humidity, na.rm = TRUE),
    windspeed_ms_daily_avg   = mean(wind_speed, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    sunshine_hours_daily_avg_sq = sunshine_hours_daily_avg^2,
    rainfall_mm_daily_avg_sq    = rainfall_mm_daily_avg^2,
    humidity_pct_daily_avg_sq   = humidity_pct_daily_avg^2,
    windspeed_ms_daily_avg_sq   = windspeed_ms_daily_avg^2
  )

#-------------------------------------------------------------------------------
# 4. CALCULATE TEMPERATURE CHARACTERISTICS
#-------------------------------------------------------------------------------

temp_characteristics <- weather_daily %>%
  mutate(
    county_id = as.character(county_code),
    date = as.Date(date),
    year = year(date)
  ) %>%
  group_by(county_id) %>%
  summarise(
    temp_avg_longterm = mean(temp_avg_daily[year >= 1998 & year <= 2017], na.rm = TRUE),
    temp_avg_shortterm = mean(temp_avg_daily[year >= 2013 & year <= 2017], na.rm = TRUE),
    temp_fluctuation_longterm = sd(tapply(temp_avg_daily[year >= 1998 & year <= 2017], 
                                          year[year >= 1998 & year <= 2017], 
                                          mean, na.rm = TRUE), na.rm = TRUE),
    temp_fluctuation_shortterm = sd(temp_avg_daily[year >= 2013 & year <= 2017], na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    temp_avg_longterm_high = if_else(temp_avg_longterm > median(temp_avg_longterm, na.rm = TRUE), 1, 0),
    temp_avg_shortterm_high = if_else(temp_avg_shortterm > median(temp_avg_shortterm, na.rm = TRUE), 1, 0),
    temp_fluctuation_longterm_high = if_else(temp_fluctuation_longterm > median(temp_fluctuation_longterm, na.rm = TRUE), 1, 0),
    temp_fluctuation_shortterm_high = if_else(temp_fluctuation_shortterm > median(temp_fluctuation_shortterm, na.rm = TRUE), 1, 0)
  )

#-------------------------------------------------------------------------------
# 5. PROCESS ENVIRONMENTAL AND ECONOMIC DATA
#-------------------------------------------------------------------------------

pm25_clean <- pm25_monthly %>%
  mutate(
    county_id = as.character(county_code),
    year = year(date),
    month = month(date)
  ) %>%
  select(county_id, year, month, pm25_concentration)

income_clean <- income_annual %>%
  mutate(county_id = as.character(county_code)) %>%
  select(county_id, year, income_per_capita) %>%
  crossing(month = 1:12)

firms_clean <- firms_monthly %>%
  mutate(
    county_id = as.character(county_code),
    year = year(date),
    month = month(date)
  ) %>%
  select(county_id, year, month, num_pv_firms)

#-------------------------------------------------------------------------------
# 6. PROCESS SOLAR RADIATION AND LAND SLOPE DATA
#-------------------------------------------------------------------------------

solar_clean <- solar_radiation %>%
  mutate(
    county_id = as.character(county_code),
    solar_radiation_kwh_m2 = annual_solar_radiation
  ) %>%
  select(county_id, solar_radiation_kwh_m2) %>%
  mutate(
    solar_radiation_group = case_when(
      solar_radiation_kwh_m2 >= quantile(solar_radiation_kwh_m2, 2/3, na.rm = TRUE) ~ "High",
      solar_radiation_kwh_m2 >= quantile(solar_radiation_kwh_m2, 1/3, na.rm = TRUE) ~ "Medium",
      TRUE ~ "Low"
    )
  )

slope_clean <- land_slope %>%
  mutate(
    county_id = as.character(county_code),
    land_slope_degrees = avg_slope
  ) %>%
  select(county_id, land_slope_degrees) %>%
  mutate(
    land_slope_group = case_when(
      land_slope_degrees >= quantile(land_slope_degrees, 2/3, na.rm = TRUE) ~ "High",
      land_slope_degrees >= quantile(land_slope_degrees, 1/3, na.rm = TRUE) ~ "Medium",
      TRUE ~ "Low"
    )
  )

#-------------------------------------------------------------------------------
# 7. CREATE INCOME GROUP VARIABLE
#-------------------------------------------------------------------------------

income_groups <- income_annual %>%
  filter(year >= 2015 & year <= 2017) %>%
  mutate(county_id = as.character(county_code)) %>%
  group_by(county_id) %>%
  summarise(avg_income_pre_study = mean(income_per_capita, na.rm = TRUE), .groups = "drop") %>%
  mutate(
    income_group = case_when(
      avg_income_pre_study >= quantile(avg_income_pre_study, 2/3, na.rm = TRUE) ~ "High",
      avg_income_pre_study >= quantile(avg_income_pre_study, 1/3, na.rm = TRUE) ~ "Medium",
      TRUE ~ "Low"
    )
  ) %>%
  select(county_id, income_group)

#-------------------------------------------------------------------------------
# 8. PROCESS POLICY VARIABLES
#-------------------------------------------------------------------------------

pilot_clean <- pilot_policy %>%
  mutate(county_id = as.character(county_id)) %>%
  select(county_id, year, month, pilot_dummy)

loan_clean <- loan_policy %>%
  mutate(county_id = as.character(county_id)) %>%
  select(county_id, year, month, loan_dummy)

outage_clean <- power_outages %>%
  mutate(county_id = as.character(county_id)) %>%
  select(county_id, year, month, outage_dummy)

#-------------------------------------------------------------------------------
# 9. CREATE COMPLETE PANEL AND MERGE ALL DATA
#-------------------------------------------------------------------------------

all_counties <- unique(c(install_monthly$county_id, install_bs_monthly$county_id))

panel_base <- expand.grid(
  county_id = all_counties,
  year = 2018:2022,
  month = 1:12,
  stringsAsFactors = FALSE
) %>%
  as_tibble() %>%
  arrange(county_id, year, month) %>%
  mutate(time = as.Date(paste(year, month, "01", sep = "-")))

final_data <- panel_base %>%
  left_join(install_monthly, by = c("county_id", "year", "month")) %>%
  left_join(install_bs_monthly, by = c("county_id", "year", "month")) %>%
  left_join(weather_monthly, by = c("county_id", "year", "month")) %>%
  left_join(pm25_clean, by = c("county_id", "year", "month")) %>%
  left_join(income_clean, by = c("county_id", "year", "month")) %>%
  left_join(firms_clean, by = c("county_id", "year", "month")) %>%
  left_join(pilot_clean, by = c("county_id", "year", "month")) %>%
  left_join(loan_clean, by = c("county_id", "year", "month")) %>%
  left_join(outage_clean, by = c("county_id", "year", "month")) %>%
  left_join(temp_characteristics, by = "county_id") %>%
  left_join(solar_clean, by = "county_id") %>%
  left_join(slope_clean, by = "county_id") %>%
  left_join(income_groups, by = "county_id")

#-------------------------------------------------------------------------------
# 10. FINAL DATA CLEANING
#-------------------------------------------------------------------------------

final_data_clean <- final_data %>%
  mutate(
    province_id = substr(county_id, 1, 2),
    log_install = log(1 + installations),
    log_install_bs = log(1 + installations_bs),
    across(starts_with("temp_"), ~replace_na(., 0)),
    pilot_dummy = replace_na(pilot_dummy, 0),
    loan_dummy = replace_na(loan_dummy, 0),
    outage_dummy = replace_na(outage_dummy, 0)
  ) %>%
  select(
    county_id, province_id, time, year, month, # Added province_id here
    installations, log_install, installations_bs, log_install_bs,
    temp_below_neg5, temp_neg5_to_0, temp_0_to_5, temp_5_to_10, temp_10_to_15,
    temp_15_to_20, temp_20_to_25, temp_25_to_30, temp_above_30,
    temp_max_below_neg5, temp_max_neg5_to_0, temp_max_0_to_5, temp_max_5_to_10, temp_max_10_to_15,
    temp_max_15_to_20, temp_max_20_to_25, temp_max_25_to_30, temp_max_above_30,
    sunshine_hours_daily_avg, sunshine_hours_daily_avg_sq,
    rainfall_mm_daily_avg, rainfall_mm_daily_avg_sq,
    humidity_pct_daily_avg, humidity_pct_daily_avg_sq,
    windspeed_ms_daily_avg, windspeed_ms_daily_avg_sq,
    pm25_concentration, income_per_capita, num_pv_firms,
    pilot_dummy, loan_dummy, outage_dummy,
    temp_avg_longterm_high, temp_avg_shortterm_high,
    temp_fluctuation_longterm_high, temp_fluctuation_shortterm_high,
    solar_radiation_group, land_slope_group, income_group
  )

#-------------------------------------------------------------------------------
# 11. SAVE FINAL DATASETS
#-------------------------------------------------------------------------------

saveRDS(final_data_clean, file.path(path_output, "rrpv_analysis_panel.RDS"))

#===============================================================================
# END OF SCRIPT
#===============================================================================
