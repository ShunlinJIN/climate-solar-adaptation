#===============================================================================
# Supplementary Figs. 8–9: Climate-Driven Adoption Projection
#
# Description:
#   This script projects the impact of future climate change (2055–2065) on
#   RRPV and RRPV-BS adoption growth under three SSP scenarios (SSP1-2.6, 
#   SSP2-4.5, SSP5-8.5) using bias-corrected CMIP6 climate projections.
#   Growth rates are calculated relative to 2022 baseline with bootstrap
#   confidence intervals
#   - Supplementary Fig. 8: National average impacts by SSP scenario
#   - Supplementary Fig. 9: Heterogeneous impacts by temperature zone
#
#===============================================================================

library(tidyverse)
library(fixest)
library(lubridate)
library(ggprism)
library(cowplot)

#-------------------------------------------------------------------------------
# 1. SETUP AND PATHS
#-------------------------------------------------------------------------------

path_root     <- "D:/rooftop"
path_adoption <- file.path(path_root, "adoption")
path_models   <- file.path(path_root, "models")
path_return   <- file.path(path_root, "return")
path_plotting <- file.path(path_root, "plotting_data")
output_dir    <- file.path(path_root, "Fig")

#-------------------------------------------------------------------------------
# 2. LOAD INPUT DATA
#-------------------------------------------------------------------------------

# CMIP6 future climate projections (bias-corrected, 2055–2065 average)
cmip6_ssp126   <- readRDS(file.path(path_return, "cmip6_future_climate_SSP1-2.6.RDS"))
cmip6_ssp245   <- readRDS(file.path(path_return, "cmip6_future_climate_SSP2-4.5.RDS"))
cmip6_ssp585   <- readRDS(file.path(path_return, "cmip6_future_climate_SSP5-8.5.RDS"))

# Historical adoption data (includes 2022 baseline temperature bins)
data_adoption  <- readRDS(file.path(path_adoption, "rrpv_analysis_panel.RDS"))

# Estimated regression models (Equation 1)
eq1_baseline   <- readRDS(file.path(path_models, "eq1_baseline.RDS"))      # RRPV model
eq_rrpv_bs     <- readRDS(file.path(path_models, "rrpv_bs_temp_response.RDS")) # RRPV-BS model

# Historical weather data for temperature zone classification
weather_daily  <- readRDS(file.path(path_root, "weather_daily_county.RDS"))

#-------------------------------------------------------------------------------
# 3. CONSTRUCT TEMPERATURE ZONES 
#-------------------------------------------------------------------------------

weather_historical <- weather_daily %>%
  mutate(
    county_id = as.character(county_code),
    date      = as.Date(date),
    year      = year(date)
  ) %>%
  filter(year >= 1981 & year <= 2010)

county_temp_zones <- weather_historical %>%
  group_by(county_id) %>%
  summarise(
    avg_temp_30yr = mean(temp_avg_daily, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    temp_zone = case_when(
      avg_temp_30yr >= quantile(avg_temp_30yr, 0.7, na.rm = TRUE) ~ "Hot",
      avg_temp_30yr >= quantile(avg_temp_30yr, 0.3, na.rm = TRUE) ~ "Mild",
      TRUE                                                         ~ "Cold"
    ),
    temp_zone = factor(temp_zone, levels = c("Cold", "Mild", "Hot"))
  )

#-------------------------------------------------------------------------------
# 4. FUTURE TEMPERATURE BINS (MID-CENTURY: 2055–2065)
#-------------------------------------------------------------------------------

assign_temp_bin <- function(temp) {
  case_when(
    temp <= -5                        ~ "temp_below_neg5",
    temp > -5  & temp < 0             ~ "temp_neg5_to_0",
    temp >= 0  & temp < 5             ~ "temp_0_to_5",
    temp >= 5  & temp < 10            ~ "temp_5_to_10",
    temp >= 10 & temp < 15            ~ "temp_10_to_15",
    temp >= 15 & temp < 20            ~ "temp_15_to_20",
    temp >= 20 & temp < 25            ~ "temp_20_to_25",
    temp >= 25 & temp < 30            ~ "temp_25_to_30",
    temp >= 30                        ~ "temp_above_30",
    TRUE                              ~ NA_character_
  )
}

process_future_climate <- function(cmip6_data) {
  future_midcentury <- cmip6_data %>%
    mutate(
      county_id = as.character(county_id),
      year      = year(time),
      month     = month(time)
    ) %>%
    filter(year >= 2055 & year <= 2065) %>%
    mutate(temp_bin = assign_temp_bin(T_t))
  
  future_monthly <- future_midcentury %>%
    group_by(county_id, year, month) %>%
    summarise(
      temp_below_neg5 = sum(temp_bin == "temp_below_neg5", na.rm = TRUE),
      temp_neg5_to_0  = sum(temp_bin == "temp_neg5_to_0",  na.rm = TRUE),
      temp_0_to_5     = sum(temp_bin == "temp_0_to_5",     na.rm = TRUE),
      temp_5_to_10    = sum(temp_bin == "temp_5_to_10",    na.rm = TRUE),
      temp_10_to_15   = sum(temp_bin == "temp_10_to_15",   na.rm = TRUE),
      temp_15_to_20   = sum(temp_bin == "temp_15_to_20",   na.rm = TRUE),
      temp_20_to_25   = sum(temp_bin == "temp_20_to_25",   na.rm = TRUE),
      temp_25_to_30   = sum(temp_bin == "temp_25_to_30",   na.rm = TRUE),
      temp_above_30   = sum(temp_bin == "temp_above_30",   na.rm = TRUE),
      .groups = "drop"
    )
  
  future_avg <- future_monthly %>%
    group_by(county_id) %>%
    summarise(
      across(starts_with("temp_"), ~mean(.x, na.rm = TRUE)),
      .groups = "drop"
    )
  
  return(future_avg)
}

future_ssp126 <- process_future_climate(cmip6_ssp126)
future_ssp245 <- process_future_climate(cmip6_ssp245)
future_ssp585 <- process_future_climate(cmip6_ssp585)

#-------------------------------------------------------------------------------
# 5. BASELINE (2022) TEMPERATURE BINS
#-------------------------------------------------------------------------------

baseline_2022 <- data_adoption %>%
  filter(year == 2022) %>%
  group_by(county_id) %>%
  summarise(
    across(starts_with("temp_"), ~mean(.x, na.rm = TRUE)),
    .groups = "drop"
  )

#-------------------------------------------------------------------------------
# 6. EXTRACT TEMPERATURE-RESPONSE COEFFICIENTS FROM REGRESSION MODELS
#-------------------------------------------------------------------------------

temp_bins_vars <- c(
  "temp_below_neg5",
  "temp_neg5_to_0",
  "temp_0_to_5",
  "temp_5_to_10",
  "temp_10_to_15",
  # "temp_15_to_20",  # Omitted reference category
  "temp_20_to_25",
  "temp_25_to_30",
  "temp_above_30"
)

coef_rrpv    <- coef(eq1_baseline)[temp_bins_vars]
coef_rrpv_bs <- coef(eq_rrpv_bs)[temp_bins_vars]

#-------------------------------------------------------------------------------
# 7. CALCULATE ADOPTION IMPACTS WITH BOOTSTRAP CONFIDENCE INTERVALS
#-------------------------------------------------------------------------------

calculate_impact_with_bootstrap <- function(future_bins, baseline_bins, 
                                            coef_vec, temp_zones, 
                                            n_boot = 1000) {
  
  # Step 1: Calculate change in temperature bin exposure
  delta_bins <- future_bins %>%
    left_join(baseline_bins, by = "county_id", suffix = c("_future", "_baseline")) %>%
    mutate(
      delta_temp_below_neg5 = temp_below_neg5_future - temp_below_neg5_baseline,
      delta_temp_neg5_to_0  = temp_neg5_to_0_future  - temp_neg5_to_0_baseline,
      delta_temp_0_to_5     = temp_0_to_5_future     - temp_0_to_5_baseline,
      delta_temp_5_to_10    = temp_5_to_10_future    - temp_5_to_10_baseline,
      delta_temp_10_to_15   = temp_10_to_15_future   - temp_10_to_15_baseline,
      delta_temp_20_to_25   = temp_20_to_25_future   - temp_20_to_25_baseline,
      delta_temp_25_to_30   = temp_25_to_30_future   - temp_25_to_30_baseline,
      delta_temp_above_30   = temp_above_30_future   - temp_above_30_baseline
    )
  
  # Step 2: County-level point estimates
  impact_county <- delta_bins %>%
    rowwise() %>%
    mutate(
      log_change = sum(c(
        delta_temp_below_neg5, delta_temp_neg5_to_0, delta_temp_0_to_5,
        delta_temp_5_to_10, delta_temp_10_to_15, delta_temp_20_to_25,
        delta_temp_25_to_30, delta_temp_above_30
      ) * coef_vec),
      pct_change = exp(log_change) - 1  # Growth rate
    ) %>%
    ungroup() %>%
    select(county_id, pct_change) %>%
    left_join(temp_zones, by = "county_id")
  
  # Step 3: Bootstrap confidence intervals (county-level resampling)
  counties   <- unique(impact_county$county_id)
  n_counties <- length(counties)
  
  # National average
  boot_national <- replicate(n_boot, {
    boot_counties <- sample(counties, size = n_counties, replace = TRUE)
    boot_sample <- map_dfr(boot_counties, ~filter(impact_county, county_id == .x))
    mean(boot_sample$pct_change, na.rm = TRUE)
  })
  
  national_result <- data.frame(
    Category = "Average",
    Impact   = mean(impact_county$pct_change, na.rm = TRUE),
    CI_lower = quantile(boot_national, 0.025, na.rm = TRUE),
    CI_upper = quantile(boot_national, 0.975, na.rm = TRUE)
  )
  
  # By temperature zone
  zone_results <- map_dfr(c("Cold", "Mild", "Hot"), function(zone) {
    zone_data <- impact_county %>% filter(temp_zone == zone)
    
    if (nrow(zone_data) == 0) {
      return(data.frame(
        Category = zone,
        Impact = NA,
        CI_lower = NA,
        CI_upper = NA
      ))
    }
    
    boot_zone <- replicate(n_boot, {
      zone_counties <- unique(zone_data$county_id)
      boot_counties <- sample(zone_counties, size = length(zone_counties), replace = TRUE)
      boot_sample <- map_dfr(boot_counties, ~filter(zone_data, county_id == .x))
      mean(boot_sample$pct_change, na.rm = TRUE)
    })
    
    data.frame(
      Category = zone,
      Impact   = mean(zone_data$pct_change, na.rm = TRUE),
      CI_lower = quantile(boot_zone, 0.025, na.rm = TRUE),
      CI_upper = quantile(boot_zone, 0.975, na.rm = TRUE)
    )
  })
  
  bind_rows(national_result, zone_results)
}

#-------------------------------------------------------------------------------
# 8. COMPUTE IMPACTS FOR ALL SSP × SYSTEM COMBINATIONS
#-------------------------------------------------------------------------------

# SSP1-2.6
impact_ssp126_rrpv <- calculate_impact_with_bootstrap(
  future_ssp126, baseline_2022, coef_rrpv, county_temp_zones
) %>% mutate(SSP = "SSP1", System = "RRPV")

impact_ssp126_rrpv_bs <- calculate_impact_with_bootstrap(
  future_ssp126, baseline_2022, coef_rrpv_bs, county_temp_zones
) %>% mutate(SSP = "SSP1", System = "RRPV-BS")

# SSP2-4.5
impact_ssp245_rrpv <- calculate_impact_with_bootstrap(
  future_ssp245, baseline_2022, coef_rrpv, county_temp_zones
) %>% mutate(SSP = "SSP2", System = "RRPV")

impact_ssp245_rrpv_bs <- calculate_impact_with_bootstrap(
  future_ssp245, baseline_2022, coef_rrpv_bs, county_temp_zones
) %>% mutate(SSP = "SSP2", System = "RRPV-BS")

# SSP5-8.5
impact_ssp585_rrpv <- calculate_impact_with_bootstrap(
  future_ssp585, baseline_2022, coef_rrpv, county_temp_zones
) %>% mutate(SSP = "SSP5", System = "RRPV")

impact_ssp585_rrpv_bs <- calculate_impact_with_bootstrap(
  future_ssp585, baseline_2022, coef_rrpv_bs, county_temp_zones
) %>% mutate(SSP = "SSP5", System = "RRPV-BS")

# Combine all results
all_impacts <- bind_rows(
  impact_ssp126_rrpv, impact_ssp126_rrpv_bs,
  impact_ssp245_rrpv, impact_ssp245_rrpv_bs,
  impact_ssp585_rrpv, impact_ssp585_rrpv_bs
)

#-------------------------------------------------------------------------------
# 9. PREPARE DATA FOR SUPPLEMENTARY FIG. 8 (NATIONAL AVERAGE BY SSP)
#-------------------------------------------------------------------------------

fig8_data <- all_impacts %>%
  filter(Category == "Average") %>%
  mutate(
    SSP = factor(SSP, levels = c("SSP1", "SSP2", "SSP5"))
  ) %>%
  select(SSP, System, Impact, CI_lower, CI_upper)

saveRDS(fig8_data, file.path(path_plotting, "supp_fig8_data.RDS"))

#-------------------------------------------------------------------------------
# 10. PREPARE DATA FOR SUPPLEMENTARY FIG. 9 (BY TEMPERATURE ZONE)
#-------------------------------------------------------------------------------

fig9_data <- all_impacts %>%
  mutate(
    Category = factor(Category, levels = c("Average", "Cold", "Mild", "Hot")),
    SSP = factor(SSP, levels = c("SSP1", "SSP2", "SSP5"))
  )

saveRDS(fig9_data, file.path(path_plotting, "supp_fig9_data.RDS"))

#===============================================================================
# PLOTTING: SUPPLEMENTARY FIG. 8
#===============================================================================

data_8a <- fig8_data %>% filter(System == "RRPV")
data_8b <- fig8_data %>% filter(System == "RRPV-BS")

p_8a <- ggplot(data_8a, aes(x = SSP, y = Impact)) +
  geom_bar(aes(fill = "Estimated Impacts"), stat = "identity", width = 0.6, alpha = 0.8) +
  geom_errorbar(aes(ymin = CI_lower, ymax = CI_upper, color = "95% CI"), 
                width = 0.2, linewidth = 0.5) +
  geom_text(aes(label = sprintf("%.4f", Impact)), 
            position = position_stack(vjust = 0.5),
            size = 3.5, color = "deepskyblue4") +
  scale_y_continuous(
    limits = c(-0.02, 0.48),
    breaks = seq(0, 0.48, 0.08),
    expand = c(0, 0),
    guide = "prism_offset"
  ) +
  scale_fill_manual(values = "lightblue") +
  scale_color_manual(values = "black") +
  theme_prism() +
  theme(
    axis.text = element_text(size = 10, face = "plain"),
    axis.title = element_text(size = 12, color = "black", face = "plain"),
    legend.position = "top",
    legend.title = element_blank()
  ) +
  ylab("Estimated Impacts") +
  xlab("Climate Categories (RRPV-only Adoption)") +
  labs(tag = "a")

p_8b <- ggplot(data_8b, aes(x = SSP, y = Impact)) +
  geom_bar(aes(fill = "Estimated Impacts"), stat = "identity", width = 0.6, alpha = 0.8) +
  geom_errorbar(aes(ymin = CI_lower, ymax = CI_upper, color = "95% CI"), 
                width = 0.2, linewidth = 0.5) +
  geom_text(aes(label = sprintf("%.4f", Impact)), 
            position = position_stack(vjust = 0.5),
            size = 3.5, color = "deepskyblue4") +
  scale_y_continuous(
    limits = c(-0.02, 0.48),
    breaks = seq(0, 0.48, 0.08),
    expand = c(0, 0),
    guide = "prism_offset"
  ) +
  scale_fill_manual(values = "lightblue") +
  scale_color_manual(values = "black") +
  theme_prism() +
  theme(
    axis.text = element_text(size = 10, face = "plain"),
    axis.title = element_text(size = 12, color = "black", face = "plain"),
    legend.position = "top",
    legend.title = element_blank()
  ) +
  ylab("Estimated Impacts") +
  xlab("Climate Categories (RRPV-BS Adoption)") +
  labs(tag = "b")

supp_fig8 <- plot_grid(p_8a, p_8b, ncol = 2, align = "hv", axis = "tb")

ggsave(
  file.path(output_dir, "Supplementary_Fig_8.pdf"),
  supp_fig8, width = 12, height = 6
)

ggsave(
  file.path(output_dir, "Supplementary_Fig_8.png"),
  supp_fig8, width = 12, height = 6, dpi = 1200
)

#===============================================================================
# PLOTTING: SUPPLEMENTARY FIG. 9
#===============================================================================
create_panel <- function(data_subset, ssp_name, system_name, fill_color, panel_tag) {
  ggplot(data_subset, aes(x = Category, y = Impact)) +
    geom_bar(aes(fill = "Estimated Impacts"), stat = "identity", width = 0.6, alpha = 0.8) +
    geom_errorbar(aes(ymin = CI_lower, ymax = CI_upper, color = "95% CI"), 
                  width = 0.2, linewidth = 0.5) +
    geom_text(aes(label = sprintf("%.4f", Impact)), 
              position = position_stack(vjust = 0.5), 
              size = 3.5, color = "white") +
    scale_y_continuous(
      name = "Estimated Impacts", 
      breaks = seq(0, 0.5, 0.05), 
      limits = c(0, 0.5), 
      guide = "prism_offset"
    ) +
    scale_x_discrete(name = paste0("Climate categories (", ssp_name, ", ", system_name, ")")) +
    scale_fill_manual(values = fill_color) +
    scale_color_manual(values = "black") +
    theme_prism() +
    theme(
      axis.text = element_text(size = 10, face = "plain"),
      axis.title = element_text(size = 11, face = "plain"),
      legend.position = "top",
      legend.title = element_blank()
    ) +
    labs(tag = panel_tag)
}

p_9a <- create_panel(fig9_data %>% filter(SSP == "SSP1", System == "RRPV"), 
                     "SSP1", "RRPV-only", "cyan4", "a")
p_9b <- create_panel(fig9_data %>% filter(SSP == "SSP2", System == "RRPV"), 
                     "SSP2", "RRPV-only", "cyan4", "b")
p_9c <- create_panel(fig9_data %>% filter(SSP == "SSP5", System == "RRPV"), 
                     "SSP5", "RRPV-only", "cyan4", "c")
p_9d <- create_panel(fig9_data %>% filter(SSP == "SSP1", System == "RRPV-BS"), 
                     "SSP1", "RRPV-BS", "coral3", "d")
p_9e <- create_panel(fig9_data %>% filter(SSP == "SSP2", System == "RRPV-BS"), 
                     "SSP2", "RRPV-BS", "coral3", "e")
p_9f <- create_panel(fig9_data %>% filter(SSP == "SSP5", System == "RRPV-BS"), 
                     "SSP5", "RRPV-BS", "coral3", "f")

supp_fig9 <- plot_grid(
  p_9a, p_9b, p_9c,
  p_9d, p_9e, p_9f,
  ncol = 3, nrow = 2,
  align = "hv", axis = "tb"
)

# PDF
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_9.pdf"),
  plot = supp_fig9, 
  width = 18, height = 12, units = "in",
  device = cairo_pdf
)

# PNG
ggsave(
  filename = file.path(output_dir, "Supplementary_Fig_9.png"),
  plot = supp_fig9, 
  width = 18, height = 12, units = "in", 
  dpi = 1200,
  device = "png",
  type = "cairo",
  bg = "white"
)



#===============================================================================
# END OF SCRIPT
#===============================================================================
